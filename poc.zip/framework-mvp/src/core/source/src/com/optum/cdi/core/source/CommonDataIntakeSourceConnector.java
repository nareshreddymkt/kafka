package com.optum.cdi.core.source;

import com.optum.cdi.core.shared.CommonValues;
import org.apache.kafka.common.config.ConfigDef;
import org.apache.kafka.common.config.ConfigException;
import org.apache.kafka.connect.connector.Task;
import org.apache.kafka.connect.errors.ConnectException;
import org.apache.kafka.connect.source.SourceConnector;
import org.apache.log4j.Logger;

import java.util.List;
import java.util.Map;

public abstract class CommonDataIntakeSourceConnector<TConfig extends CommonDataIntakeSourceConnectorConfig> extends SourceConnector {
	protected CommonDataIntakeSourceConnector() {
		getLogger().info("source::.ctor()");
	}

	private static final Logger logger = Logger.getLogger(CommonDataIntakeSourceConnector.class);
	private TConfig sourceConnectorConfig;

	protected static Logger getLogger() {
		return logger;
	}

	protected static void printConsole(String format, Object... args) {
		System.out.printf(format, args);
	}

	protected abstract TConfig getSourceConnectorConfigInstance(Map<?, ?> properties);

	protected abstract ConfigDef getSourceConnectorConfigTemplate();

	protected abstract Class<? extends Task> getSourceConnectorTaskClass();

	protected abstract void onSourceConnectorInitialize();

	protected abstract void onSourceConnectorTerminate();

	protected abstract List<Map<String, String>> getSourceTaskConfigs(int maxTasks);

	@Override
	public final String version() {
		getLogger().info("source::version()");
		return CommonValues.CDI_FRAMEWORK_VERSION;
	}

	@Override
	public final void start(Map<String, String> properties) {
		if (properties == null)
			throw new IllegalArgumentException("properties");

		getLogger().info("source::start()");

		try {
			this.setSourceConnectorConfig(this.getSourceConnectorConfigInstance(properties));
		}
		catch (ConfigException ce) {
			throw new ConnectException("Couldn't start source connector configuration error.", ce);
		}
		catch (Exception e) {
			throw new ConnectException("An error has occurred when starting source connector." + e);
		}

		this.onSourceConnectorInitialize();
	}

	@Override
	public final Class<? extends Task> taskClass() {
		getLogger().info("source::taskClass()");
		return this.getSourceConnectorTaskClass();
	}

	@Override
	public final List<Map<String, String>> taskConfigs(int maxTasks) {
		getLogger().info("source::taskConfigs(" + Integer.toString(maxTasks) + ")");

		if (this.getSourceConnectorConfig() == null)
			throw new ConnectException("Connector config has not been initialized.");

		return this.getSourceTaskConfigs(maxTasks);
	}

	@Override
	public final void stop() {
		getLogger().info("source::stop()");
		this.onSourceConnectorTerminate();
	}

	@Override
	public final ConfigDef config() {
		getLogger().info("source::config()");
		return this.getSourceConnectorConfigTemplate();
	}

	protected final TConfig getSourceConnectorConfig() {
		return sourceConnectorConfig;
	}

	private void setSourceConnectorConfig(TConfig sourceConnectorConfig) {
		this.sourceConnectorConfig = sourceConnectorConfig;
	}
}
