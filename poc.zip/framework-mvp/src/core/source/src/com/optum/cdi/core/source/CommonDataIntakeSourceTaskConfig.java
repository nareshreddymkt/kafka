package com.optum.cdi.core.source;

import org.apache.kafka.common.config.ConfigDef;

import java.util.Map;

public abstract class CommonDataIntakeSourceTaskConfig extends CommonDataIntakeAbstractSourceConfig {
	protected CommonDataIntakeSourceTaskConfig(ConfigDef config, Map<?, ?> parsedConfig) {
		super(config, parsedConfig);
	}
}
