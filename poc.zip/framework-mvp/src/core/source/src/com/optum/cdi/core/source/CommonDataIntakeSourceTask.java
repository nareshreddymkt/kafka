package com.optum.cdi.core.source;

import com.optum.cdi.core.shared.CommonValues;
import com.optum.cdi.core.shared.telemetry.BasicLifecycleTelemetry;
import org.apache.kafka.common.config.ConfigException;
import org.apache.kafka.connect.errors.ConnectException;
import org.apache.kafka.connect.source.SourceRecord;
import org.apache.kafka.connect.source.SourceTask;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

public abstract class CommonDataIntakeSourceTask<TConfig extends CommonDataIntakeSourceTaskConfig> extends SourceTask {
	protected CommonDataIntakeSourceTask(long sourceBatchMaxRecordCount, int sourceBatchWaitTimeoutMillis) {
		getLogger().info("sourceTask::.ctor()");

		this.sourceBatchMaxRecordCount = sourceBatchMaxRecordCount;
		this.sourceBatchWaitTimeoutMillis = sourceBatchWaitTimeoutMillis;

		this.sourceTaskStop = new AtomicBoolean(false);
	}

	private static final Logger logger = Logger.getLogger(CommonDataIntakeSourceTask.class);
	private final AtomicBoolean sourceTaskStop;
	private final long sourceBatchMaxRecordCount;
	private final int sourceBatchWaitTimeoutMillis;
	private TConfig sourceTaskConfig;

	protected static Logger getLogger() {
		return logger;
	}

	protected static void printConsole(String format, Object... args) {
		System.out.printf(format, args);
	}

	protected abstract TConfig getSourceTaskConfigInstance(Map<?, ?> properties);

	protected abstract void onSourceTaskInitialize();

	protected abstract void onSourceTaskTerminate();

	@Override
	public final String version() {
		return CommonValues.CDI_FRAMEWORK_VERSION;
	}

	@Override
	public final void start(Map<String, String> properties) {
		if (properties == null)
			throw new IllegalArgumentException("properties");

		getLogger().info("sourceTask::start()");

		try {
			this.setSourceTaskConfig(this.getSourceTaskConfigInstance(properties));
		}
		catch (ConfigException ce) {
			throw new ConnectException("Couldn't start source connector configuration error.", ce);
		}
		catch (Exception e) {
			throw new ConnectException("An error has occurred when starting source connector." + e);
		}

		this.onSourceTaskInitialize();
	}

	@Override
	public final List<SourceRecord> poll() throws InterruptedException {
		boolean stillYielding;
		List<SourceRecord> sourceRecords;

		getLogger().info("sourceTask::poll()");

		final Iterator<SourceRecord> sourceRecordIterator = this.aquireSourceRecordIterator();
		final BasicLifecycleTelemetry basicLifecycleTelemetry = this.aquireSourceBasicLifecycleTelemetry();

		sourceRecords = new ArrayList<SourceRecord>();

		// all this chicanery is designed to prevent heap overflow of JVM when the iterator can return a bunch of records
		if (this.getSourceTaskStop() != null &&
			!this.getSourceTaskStop().get() &&
			sourceRecordIterator != null && /* implied but still good to check to prevent possible NPE */
			basicLifecycleTelemetry != null &&
			this.canSourceYieldBatchRecord()) {

			while ((stillYielding = sourceRecordIterator.hasNext()) &&
					sourceRecords.size() < this.getSourceBatchMaxRecordCount()) {
				SourceRecord sourceRecord;

				sourceRecord = sourceRecordIterator.next();
				basicLifecycleTelemetry.incrementTotalRecordCount();
				sourceRecords.add(sourceRecord);
			}

			basicLifecycleTelemetry.incrementTotalBatchCount();

			if (!stillYielding) {
				this.getSourceTaskStop().set(true);

				this.onSourceYieldComplete();

				// we are done, report some stats explicitly to console
				printConsole("Yield complete... batches: %s | records: %s | duration: %s | throughput: %s." + System.lineSeparator(),
					basicLifecycleTelemetry.getTotalBatchCount(),
					basicLifecycleTelemetry.getTotalRecordCount(),
					basicLifecycleTelemetry.getTotalLifecycleSeconds(),
					basicLifecycleTelemetry.calcRecordThroughput());
			}
		}
		else {
			sourceRecords = null;

			// do nothing at this point, explicitly print dots to console
			printConsole(".");
			synchronized (this) {
				this.wait(getSourceBatchWaitTimeoutMillis());
			}
		}

		return sourceRecords;
	}

	protected abstract BasicLifecycleTelemetry aquireSourceBasicLifecycleTelemetry();

	protected abstract void onSourceYieldComplete();

	protected abstract boolean canSourceYieldBatchRecord();

	protected abstract Iterator<SourceRecord> aquireSourceRecordIterator();

	@Override
	public final void stop() {
		getLogger().info("sourceTask::stop()");

		this.getSourceTaskStop().set(true);

		synchronized (this) {
			this.onSourceTaskTerminate();
		}
	}

	protected final TConfig getSourceTaskConfig() {
		return sourceTaskConfig;
	}

	private void setSourceTaskConfig(TConfig sourceTaskConfig) {
		this.sourceTaskConfig = sourceTaskConfig;
	}

	protected final AtomicBoolean getSourceTaskStop() {
		return this.sourceTaskStop;
	}

	protected long getSourceBatchMaxRecordCount() {
		return sourceBatchMaxRecordCount;
	}

	protected int getSourceBatchWaitTimeoutMillis() {
		return sourceBatchWaitTimeoutMillis;
	}
}
