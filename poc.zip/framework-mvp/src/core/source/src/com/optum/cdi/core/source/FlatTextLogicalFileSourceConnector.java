package com.optum.cdi.core.source;

import org.apache.kafka.common.config.ConfigDef;
import org.apache.kafka.connect.connector.Task;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class FlatTextLogicalFileSourceConnector extends CommonDataIntakeSourceConnector<FlatTextLogicalFileSourceConnectorConfig> {
	public FlatTextLogicalFileSourceConnector() {
	}

	@Override
	protected FlatTextLogicalFileSourceConnectorConfig getSourceConnectorConfigInstance(Map<?, ?> properties) {
		return new FlatTextLogicalFileSourceConnectorConfig(properties);
	}

	@Override
	protected ConfigDef getSourceConnectorConfigTemplate() {
		return FlatTextLogicalFileSourceConnectorConfig.conf();
	}

	@Override
	protected Class<? extends Task> getSourceConnectorTaskClass() {
		return FlatTextLogicalFileSourceTask.class;
	}

	@Override
	protected void onSourceConnectorInitialize() {
		// do nothing
	}

	@Override
	protected void onSourceConnectorTerminate() {
		// do nothing
	}

	@Override
	protected List<Map<String, String>> getSourceTaskConfigs(int maxTasks) {
		ArrayList<Map<String, String>> configs;
		Map<String, String> config;

		configs = new ArrayList<>();

		// only one input stream makes sense right now; think "MVP" ;)
		maxTasks = 1;

		for (int i = 0; i < maxTasks; i++) {
			config = this.getSourceConnectorConfig().originalsStrings();
			configs.add(config);
		}

		return configs;
	}
}