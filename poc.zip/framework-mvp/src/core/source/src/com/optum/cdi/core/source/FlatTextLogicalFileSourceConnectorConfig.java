package com.optum.cdi.core.source;

import org.apache.kafka.common.config.ConfigDef;

import java.util.Map;

import static com.optum.cdi.core.shared.CommonValues.*;

public class FlatTextLogicalFileSourceConnectorConfig extends CommonDataIntakeSourceConnectorConfig {

	public FlatTextLogicalFileSourceConnectorConfig(Map<?, ?> parsedConfig) {
		super(conf(), parsedConfig);
	}

	private static final ConfigDef CONFIG_DEF = new ConfigDef()
			.define(LFS_TAG_CONFIG, ConfigDef.Type.STRING, ConfigDef.Importance.HIGH, "Logical file system tag used to interpret the source data and metadata URIs.")
			.define(FTF_TAG_CONFIG, ConfigDef.Type.STRING, ConfigDef.Importance.HIGH, "Flat text format tag used to load the metadata and determine reader/parser.")
			.define(SOURCE_DATA_FILE_URI_CONFIG, ConfigDef.Type.STRING, ConfigDef.Importance.HIGH, "Source data logical file URI.")
			.define(SOURCE_METADATA_FILE_URI_CONFIG, ConfigDef.Type.STRING, ConfigDef.Importance.HIGH, "Source metadata logical file URI.")
			.define(TARGET_TOPIC_CONFIG, ConfigDef.Type.STRING, ConfigDef.Importance.HIGH, "The target topic on which source data records will be written.");

	public static ConfigDef conf() {
		return CONFIG_DEF;
	}

	protected String getSourceDataFileUri() {
		return this.getString(SOURCE_DATA_FILE_URI_CONFIG);
	}

	protected String getSourceMetadataFileUri() {
		return this.getString(SOURCE_METADATA_FILE_URI_CONFIG);
	}

	protected String getTargetTopic() {
		return this.getString(TARGET_TOPIC_CONFIG);
	}

	protected String getLogicalFileSystemTag() {
		return this.getString(LFS_TAG_CONFIG);
	}

	protected String getFlatTextFormatTag() {
		return this.getString(FTF_TAG_CONFIG);
	}
}
