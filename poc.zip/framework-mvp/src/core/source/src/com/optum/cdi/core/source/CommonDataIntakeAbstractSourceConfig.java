package com.optum.cdi.core.source;

import org.apache.kafka.common.config.AbstractConfig;
import org.apache.kafka.common.config.ConfigDef;

import java.util.Map;

public class CommonDataIntakeAbstractSourceConfig extends AbstractConfig {
	protected CommonDataIntakeAbstractSourceConfig(ConfigDef config, Map<?, ?> parsedConfig) {
		super(config, parsedConfig);
	}
}
