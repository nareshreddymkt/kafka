package com.optum.cdi.core.source;

import org.apache.kafka.common.config.ConfigDef;

import java.util.Map;

public abstract class CommonDataIntakeSourceConnectorConfig extends CommonDataIntakeAbstractSourceConfig {
	protected CommonDataIntakeSourceConnectorConfig(ConfigDef config, Map<?, ?> parsedConfig) {
		super(config, parsedConfig);
	}
}
