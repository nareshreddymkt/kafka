package com.optum.cdi.core.source;

import com.optum.cdi.core.shared.IteratorProjector;
import com.optum.cdi.core.shared.abstractions.FlatTextRecord;
import com.optum.cdi.core.shared.lifecycle.FlatTextSourceLifecycle;
import com.optum.cdi.core.shared.telemetry.BasicLifecycleTelemetry;
import org.apache.kafka.connect.data.Schema;
import org.apache.kafka.connect.data.SchemaBuilder;
import org.apache.kafka.connect.source.SourceRecord;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

public class FlatTextLogicalFileSourceTask extends CommonDataIntakeSourceTask<FlatTextLogicalFileSourceTaskConfig> {
	public FlatTextLogicalFileSourceTask() {
		super(MAX_BATCH_SIZE, SLEEP_TIMEOUT_MS);
	}

	private static final long MAX_BATCH_SIZE = 1000;
	private static final int SLEEP_TIMEOUT_MS = 2500;
	private static final Schema PARSED_RECORD_MAP_STRING_STRING_SCHEMA = SchemaBuilder.map(Schema.STRING_SCHEMA, Schema.OPTIONAL_STRING_SCHEMA);
	private static final Schema RAW_RECORD_STRING_SCHEMA = Schema.STRING_SCHEMA;

	private FlatTextSourceLifecycle flatTextSourceLifecycle;

	private FlatTextSourceLifecycle getFlatTextSourceLifecycle() {
		return flatTextSourceLifecycle;
	}

	private void setFlatTextSourceLifecycle(FlatTextSourceLifecycle flatTextSourceLifecycle) {
		this.flatTextSourceLifecycle = flatTextSourceLifecycle;
	}

	@Override
	protected FlatTextLogicalFileSourceTaskConfig getSourceTaskConfigInstance(Map<?, ?> properties) {
		return new FlatTextLogicalFileSourceTaskConfig(properties);
	}

	@Override
	protected void onSourceTaskInitialize() {
		final long SOURCE_OFFSET = 0;

		this.setFlatTextSourceLifecycle(FlatTextSourceLifecycle.create(
				this.getSourceTaskConfig().getLogicalFileSystemTag(),
				this.getSourceTaskConfig().getFlatTextFormatTag(),
				this.getSourceTaskConfig().getSourceMetadataFileUri(),
				this.getSourceTaskConfig().getSourceDataFileUri(),
				SOURCE_OFFSET));
	}

	@Override
	protected void onSourceTaskTerminate() {
		this.ensureLifecycleDisposed();
	}

	@Override
	protected BasicLifecycleTelemetry aquireSourceBasicLifecycleTelemetry() {
		return this.getFlatTextSourceLifecycle();
	}

	@Override
	protected void onSourceYieldComplete() {
		this.ensureLifecycleDisposed();
	}

	private void ensureLifecycleDisposed() {
		synchronized (this) {
			try {
				if (this.getFlatTextSourceLifecycle() != null) {
					this.getFlatTextSourceLifecycle().close();
				}
			}
			catch (IOException ioex) {
				getLogger().warn(ioex);
			}
		}
	}

	@Override
	protected boolean canSourceYieldBatchRecord() {
		// check for valid lifecycle/reader/iterator
		return this.getFlatTextSourceLifecycle() != null &&
				this.getFlatTextSourceLifecycle().getFlatTextReader() != null;
	}

	@Override
	protected Iterator<SourceRecord> aquireSourceRecordIterator() {
		if (!this.canSourceYieldBatchRecord())
			return null;

		// NOTE: each time this method is called from the base connector, the iterator represents the current iterated state of the SAME flat text reader iterator (e.g. intentionally reentrant)
		// This allows us to keep the underlying IO stream open while we artificially batch the projected iterator to prevent JVM heap overflow for large files and prevent need to constantly re-open IO stream
		return new IteratorProjector<FlatTextRecord, SourceRecord>(this.getFlatTextSourceLifecycle().getFlatTextReader().read(), (ftr) -> {
			SourceRecord sourceRecord = null;

			if (ftr != null) {
				if (ftr.isRawRecord()) // this is raw record (string) / TODO {sha1_hash + line_no} for key
					sourceRecord = new SourceRecord(null, null, this.getSourceTaskConfig().getTargetTopic(), RAW_RECORD_STRING_SCHEMA, ftr.getRawRecordKey(), RAW_RECORD_STRING_SCHEMA, ftr.getRawRecordValue());
				else // if using the connector to emit parsed records, lets just emit the untyped key/value for now
					sourceRecord = new SourceRecord(null, null, this.getSourceTaskConfig().getTargetTopic(), PARSED_RECORD_MAP_STRING_STRING_SCHEMA, ftr.getUntypedKey(), PARSED_RECORD_MAP_STRING_STRING_SCHEMA, ftr.getUntypedValue());
			}

			return sourceRecord;
		});
	}
}
