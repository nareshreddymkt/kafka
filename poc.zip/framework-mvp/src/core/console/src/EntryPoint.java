public class EntryPoint {
	public static void main(String[] args) {
		System.out.println("Hello World!");
		// code moved into integration test suite.
		System.out.println("Goodbye World!");
	}
}
