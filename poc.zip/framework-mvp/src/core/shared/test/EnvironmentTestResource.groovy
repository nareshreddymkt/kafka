def newValue = processorRecord.modifiedValue = ['aKey' : 'aValue']
newValue.putAll(processorRecord.originalValue)
return processorRecord