def tmp_val = [:]

def sourceMain() {
    tmp_val.putAll(processorRecord.originalValue)
    calculateEmploymentStatus()

    processorRecord.modifiedValue = tmp_val
    return processorRecord
}

def calculateEmploymentStatus() {
    def result = ""
    if (tmp_val.RETIREE_IND ?: 'Y') {
        result = 'RETIRED'
    }
    else if (tmp_val.EMPLOYEE_STS ?: 'I') {
        result = 'INACTIVE'
    }
    else if (tmp_val.EMPLOYEE_STS ?: 'A') {
        result = 'ACTIVE'
    }
    tmp_val.put("EMPMT_STS_TYP_ID", result)
}

sourceMain()