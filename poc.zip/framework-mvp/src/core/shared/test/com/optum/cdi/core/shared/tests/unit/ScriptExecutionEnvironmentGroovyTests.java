package com.optum.cdi.core.shared.tests.unit;

import com.google.common.io.Files;
import com.google.common.base.Charsets;
import com.optum.cdi.core.shared.ProcessorRecordImpl;
import com.optum.cdi.core.shared.ScriptExecutionEnvironmentGroovy;
import com.optum.cdi.core.shared.abstractions.ProcessorRecord;
import com.optum.cdi.core.shared.abstractions.ScriptExecutionEnvironment;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeAll;
import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.nio.charset.Charset;

import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;




public class ScriptExecutionEnvironmentGroovyTests {
    private static ProcessorRecord processorRecord;
    private static ScriptExecutionEnvironment executionEnvironment;

    @BeforeAll
    static void initProcessorRecord() {
        Map<String,Object> key = new HashMap<>();
        Map<String,Object> value = new HashMap<>();
        value.put("RETIREE_ID", "N");
        value.put("EMPLOYEE_STS", "A");
        processorRecord = new ProcessorRecordImpl(key,value);
    }

    @BeforeAll
    static void initExecutionEnvironmentGroovy() throws IOException {
        String scriptText = "processorRecord.modifiedValue = ['aKey' : 'aValue']";
        //String scriptText = Files.toString(Paths.get("C:/Users/wcharlto/IdeaProjects/framework-mvp/src/core/shared/test/EnvironmentTestResource.groovy").toFile(), Charsets.UTF_8);

        executionEnvironment = new ScriptExecutionEnvironmentGroovy(scriptText);
    }

    @Test
    public void Execute_checkScriptCanSeeProcessorRecordPassedThroughBinding() {
        ProcessorRecord result = executionEnvironment.evaluate(processorRecord);

        assertAll("result record",
                () -> assertNotNull(result.getOriginalKey()),
                () -> assertNotNull(result.getOriginalValue()));
    }

    @Test
    public void Execute_checkScriptsSetProcessorRecordModifiedValue() {
        ProcessorRecord result = executionEnvironment.evaluate(processorRecord);
        String actual = result.getModifiedValue().get("EMPMT_STS_TYP_ID").toString();

        assertEquals("ACTIVE", actual);
    }


}
