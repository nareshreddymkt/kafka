package com.optum.cdi.core.shared.tests.integration.lifecycle;

import com.optum.cdi.core.shared.abstractions.CommonDataIntakeException;
import com.optum.cdi.core.shared.abstractions.FlatTextReader;
import com.optum.cdi.core.shared.abstractions.FlatTextRecord;
import com.optum.cdi.core.shared.lifecycle.FlatTextSourceLifecycle;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class FlatTextSourceLifecycleTests {
	@BeforeEach
	void setUp() {
	}

	@AfterEach
	void tearDown() {
	}

	private static void sourceLifecycleIntegrate(final String logicalFileSystemTag, final String flatTextFormatTag, final String sourceMetadataFileUri, final String sourceDataFileUri, final long sourceInputOffset) throws CommonDataIntakeException {
		FlatTextSourceLifecycle flatTextSourceLifecycle;
		FlatTextReader flatTextReader;

		// DO NOT CHECK NULL ARGUMENTS HERE, LET THE CODE UNDER TEST THROW INSTEAD :)

		flatTextSourceLifecycle = new FlatTextSourceLifecycle(logicalFileSystemTag, flatTextFormatTag, sourceMetadataFileUri, sourceDataFileUri, sourceInputOffset);

		if (flatTextSourceLifecycle == null)
			throw new CommonDataIntakeException("null lifecycle");

		try {
			flatTextReader = flatTextSourceLifecycle.getFlatTextReader();

			if (flatTextReader == null)
				throw new CommonDataIntakeException("null reader");

			while (flatTextReader.hasNext()) {
				FlatTextRecord flatTextRecord;

				flatTextRecord = flatTextReader.next();

				if (flatTextRecord != null) {
					if (flatTextRecord.isRawRecord())
						System.out.println(flatTextRecord.getRawRecordValue());
					else
						System.out.println(flatTextRecord.toString());
				} else {
					System.out.println("<null>");
					//break;
				}

				flatTextSourceLifecycle.incrementTotalRecordCount();
			}

			flatTextSourceLifecycle.incrementTotalBatchCount();
		}
		finally {
			try {
				if (flatTextSourceLifecycle != null)
					flatTextSourceLifecycle.close();
			}
			catch (IOException ioex) {
				System.out.println(ioex);
				return;
			}
		}

		System.out.printf("Test complete... TotalCycleCount: %s | TotalRecordCount: %s | TotalLifecycleSeconds %s.\n", flatTextSourceLifecycle.getTotalBatchCount(), flatTextSourceLifecycle.getTotalRecordCount(), flatTextSourceLifecycle.getTotalLifecycleSeconds());
	}

	@Test
	void shouldPerformSourceLifecycleUsingLocalFixedNullMetaFakeZeroTest() throws CommonDataIntakeException {
		final String logicalFileSystemTag = "local";
		final String flatTextFormatTag = "fixed";
		final String sourceMetadataFileUri = "c:\\NUL";
		final String sourceDataFileUri = "C:\\kio\\bcbs-la-1010\\in\\Fake.txt";
		final long sourceInputOffset = 0;

		sourceLifecycleIntegrate(logicalFileSystemTag, flatTextFormatTag, sourceMetadataFileUri, sourceDataFileUri, sourceInputOffset);
	}

	@Test
	void shouldPerformSourceLifecycleUsingLocalFixedJsonMetaClaimZeroTest() throws CommonDataIntakeException {
		final String logicalFileSystemTag = "local";
		final String flatTextFormatTag = "fixed";
		final String sourceMetadataFileUri = "C:\\kio\\bcbs-la-1010\\meta\\claim_metadata.json";
		final String sourceDataFileUri = "C:\\kio\\bcbs-la-1010\\in\\Claims.txt";
		final long sourceInputOffset = 0;

		sourceLifecycleIntegrate(logicalFileSystemTag, flatTextFormatTag, sourceMetadataFileUri, sourceDataFileUri, sourceInputOffset);
	}

	@Test
	void shouldPerformSourceLifecycleUsingLocalFixedJsonMetaClaimNetworkIDCodeZeroTest() throws CommonDataIntakeException {
		final String logicalFileSystemTag = "local";
		final String flatTextFormatTag = "fixed";
		final String sourceMetadataFileUri = "C:\\kio\\bcbs-la-1010\\meta\\claim_network_id_cd_metadata.json";
		final String sourceDataFileUri = "C:\\kio\\bcbs-la-1010\\in\\ClaimNetworkIDCode.txt";
		final long sourceInputOffset = 0;

		sourceLifecycleIntegrate(logicalFileSystemTag, flatTextFormatTag, sourceMetadataFileUri, sourceDataFileUri, sourceInputOffset);
	}

	@Test
	void shouldPerformSourceLifecycleUsingLocalFixedJsonMetaEligibilityZeroTest() throws CommonDataIntakeException {
		final String logicalFileSystemTag = "local";
		final String flatTextFormatTag = "fixed";
		final String sourceMetadataFileUri = "C:\\kio\\bcbs-la-1010\\meta\\eligibility_metadata.json";
		final String sourceDataFileUri = "C:\\kio\\bcbs-la-1010\\in\\Eligibility.txt";
		final long sourceInputOffset = 0;

		sourceLifecycleIntegrate(logicalFileSystemTag, flatTextFormatTag, sourceMetadataFileUri, sourceDataFileUri, sourceInputOffset);
	}

	@Test
	void shouldPerformSourceLifecycleUsingLocalFixedJsonMetaERPProductCodeZeroTest() throws CommonDataIntakeException {
		final String logicalFileSystemTag = "local";
		final String flatTextFormatTag = "fixed";
		final String sourceMetadataFileUri = "C:\\kio\\bcbs-la-1010\\meta\\erp_product_cd_metadata.json";
		final String sourceDataFileUri = "C:\\kio\\bcbs-la-1010\\in\\ERPProductCode.txt";
		final long sourceInputOffset = 0;

		sourceLifecycleIntegrate(logicalFileSystemTag, flatTextFormatTag, sourceMetadataFileUri, sourceDataFileUri, sourceInputOffset);
	}

	@Test
	void shouldPerformSourceLifecycleUsingLocalFixedJsonMetaLineOfBusinessCodeZeroTest() throws CommonDataIntakeException {
		final String logicalFileSystemTag = "local";
		final String flatTextFormatTag = "fixed";
		final String sourceMetadataFileUri = "C:\\kio\\bcbs-la-1010\\meta\\lob_cd_metadata.json";
		final String sourceDataFileUri = "C:\\kio\\bcbs-la-1010\\in\\LineOfBusinessCode.txt";
		final long sourceInputOffset = 0;

		sourceLifecycleIntegrate(logicalFileSystemTag, flatTextFormatTag, sourceMetadataFileUri, sourceDataFileUri, sourceInputOffset);
	}

	@Test
	void shouldPerformSourceLifecycleUsingLocalFixedJsonMetaNetworkIDCodeZeroTest() throws CommonDataIntakeException {
		final String logicalFileSystemTag = "local";
		final String flatTextFormatTag = "fixed";
		final String sourceMetadataFileUri = "C:\\kio\\bcbs-la-1010\\meta\\network_id_cd_metadata.json";
		final String sourceDataFileUri = "C:\\kio\\bcbs-la-1010\\in\\NetworkIDCode.txt";
		final long sourceInputOffset = 0;

		sourceLifecycleIntegrate(logicalFileSystemTag, flatTextFormatTag, sourceMetadataFileUri, sourceDataFileUri, sourceInputOffset);
	}

	@Test
	void shouldPerformSourceLifecycleUsingLocalFixedJsonMetaPlanDetailCodeZeroTest() throws CommonDataIntakeException {
		final String logicalFileSystemTag = "local";
		final String flatTextFormatTag = "fixed";
		final String sourceMetadataFileUri = "C:\\kio\\bcbs-la-1010\\meta\\plan_detail_cd_metadata.json";
		//final String sourceMetadataFileUri = "..\\..\\..\\tools\\flat_text_metadata\\bcbs-la-1010\\plan_detail_cd_metadata.json";
		final String sourceDataFileUri = "C:\\kio\\bcbs-la-1010\\in\\PlanDetailCode.txt";
		final long sourceInputOffset = 0;
		sourceLifecycleIntegrate(logicalFileSystemTag, flatTextFormatTag, sourceMetadataFileUri, sourceDataFileUri, sourceInputOffset);
	}

	@Test
	void shouldPerformSourceLifecycleUsingLocalFixedJsonMetaProviderCategoryCodeZeroTest() throws CommonDataIntakeException {
		final String logicalFileSystemTag = "local";
		final String flatTextFormatTag = "fixed";
		final String sourceMetadataFileUri = "C:\\kio\\bcbs-la-1010\\meta\\prov_category_cd_metadata.json";
		final String sourceDataFileUri = "C:\\kio\\bcbs-la-1010\\in\\ProviderCategoryCode.txt";
		final long sourceInputOffset = 0;

		sourceLifecycleIntegrate(logicalFileSystemTag, flatTextFormatTag, sourceMetadataFileUri, sourceDataFileUri, sourceInputOffset);
	}

	@Test
	void shouldPerformSourceLifecycleUsingLocalFixedJsonMetaProvidersZeroTest() throws CommonDataIntakeException {
		final String logicalFileSystemTag = "local";
		final String flatTextFormatTag = "fixed";
		final String sourceMetadataFileUri = "C:\\kio\\bcbs-la-1010\\meta\\provider_metadata.json";
		final String sourceDataFileUri = "C:\\kio\\bcbs-la-1010\\in\\Providers.txt";
		final long sourceInputOffset = 0;

		sourceLifecycleIntegrate(logicalFileSystemTag, flatTextFormatTag, sourceMetadataFileUri, sourceDataFileUri, sourceInputOffset);
	}

	@Test
	void shouldPerformSourceLifecycleUsingLocalFixedJsonMetaProviderSpecialtyCodeZeroTest() throws CommonDataIntakeException {
		final String logicalFileSystemTag = "local";
		final String flatTextFormatTag = "fixed";
		final String sourceMetadataFileUri = "C:\\kio\\bcbs-la-1010\\meta\\prov_specialty_cd_metadata.json";
		final String sourceDataFileUri = "C:\\kio\\bcbs-la-1010\\in\\ProviderSpecialtyCode.txt";
		final long sourceInputOffset = 0;

		sourceLifecycleIntegrate(logicalFileSystemTag, flatTextFormatTag, sourceMetadataFileUri, sourceDataFileUri, sourceInputOffset);
	}

	@Test
	void shouldPerformSourceLifecycleUsingLocalFixedJsonMetaProviderTypeCodeZeroTest() throws CommonDataIntakeException {
		final String logicalFileSystemTag = "local";
		final String flatTextFormatTag = "fixed";
		final String sourceMetadataFileUri = "C:\\kio\\bcbs-la-1010\\meta\\prov_type_cd_metadata.json";
		final String sourceDataFileUri = "C:\\kio\\bcbs-la-1010\\in\\ProviderTypeCode.txt";
		final long sourceInputOffset = 0;

		sourceLifecycleIntegrate(logicalFileSystemTag, flatTextFormatTag, sourceMetadataFileUri, sourceDataFileUri, sourceInputOffset);
	}
}
