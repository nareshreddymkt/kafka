package com.optum.cdi.core.shared.tests.unit;

import com.optum.cdi.core.shared.FixedLengthFlatTextReaderImpl;
import com.optum.cdi.core.shared.FlatTextRecordImpl;
import com.optum.cdi.core.shared.abstractions.FixedLengthFlatTextFieldMetadata;
import com.optum.cdi.core.shared.abstractions.FixedLengthFlatTextMetadata;
import com.optum.cdi.core.shared.abstractions.FixedLengthFlatTextParser;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.io.InputStream;

import static org.mockito.Mockito.*;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class FixedLengthFlatTextReaderImplTests {
	@BeforeEach
	void setUp() {
	}

	@AfterEach
	void tearDown() {
	}

	@Test
	void shouldCreateTest() throws IOException {
		FixedLengthFlatTextReaderImpl fixedLengthFlatTextReader;

		FixedLengthFlatTextMetadata mockFixedLengthFlatTextFieldMetadata;
		FixedLengthFlatTextParser mockFixedLengthTextParser;
		InputStream mockInputStream;
		long stubOriginalOffset;

		mockFixedLengthFlatTextFieldMetadata = mock(FixedLengthFlatTextMetadata.class);
		mockFixedLengthTextParser = mock(FixedLengthFlatTextParser.class);
		mockInputStream = mock(InputStream.class);
		stubOriginalOffset = 0;

		fixedLengthFlatTextReader = new FixedLengthFlatTextReaderImpl(mockFixedLengthFlatTextFieldMetadata, mockFixedLengthTextParser, mockInputStream, stubOriginalOffset);

		assertFalse(fixedLengthFlatTextReader.hasNext());

		when(mockInputStream.available()).thenReturn(0);

		verify(mockFixedLengthFlatTextFieldMetadata).translateOffsetToSkipChars(stubOriginalOffset);
		verify(mockInputStream).available();

		verifyNoMoreInteractions(mockFixedLengthFlatTextFieldMetadata);
		verifyNoMoreInteractions(mockFixedLengthTextParser);
		verifyNoMoreInteractions(mockInputStream);
	}
}
