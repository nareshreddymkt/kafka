package com.optum.cdi.core.shared.tests.unit;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeAll;

import static org.junit.jupiter.api.Assertions.*;

import groovy.lang.Binding;
import groovy.lang.GroovyShell;
import groovy.lang.Script;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;


public class GroovyShellTest {


    static String getScriptText() {
        String scriptText = "";
        String scriptFileUri = "C:/Users/wcharlto/IdeaProjects/framework-mvp/src/core/shared/test/Concatenation.groovy";
        try {
            scriptText =  new String(Files.readAllBytes(Paths.get(scriptFileUri)));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return scriptText;
    }


    @Test
    void parseScriptWithBinding() {
        String scriptText = getScriptText();
        Map<String,Object> sourceRecord1 = new HashMap<>();
        sourceRecord1.put("MEMBER_ID", "ABC");
        sourceRecord1.put("DATE_OF_BIRTH", "01/24/2018");
        sourceRecord1.put("NAME_FIRST", "JACK");

        Map<String,Object> sourceRecord2 = new HashMap<>();
        sourceRecord2.put("MEMBER_ID", "DEF");
        sourceRecord2.put("DATE_OF_BIRTH", "01/22/2018");
        sourceRecord2.put("NAME_FIRST", "KATE");

        GroovyShell shell = new GroovyShell();
        Binding binding = new Binding(sourceRecord1);
        Script script = shell.parse(scriptText);
        script.setBinding(binding);
        Object actual1 = script.run();
        script.setBinding(new Binding(sourceRecord2));
        Object actual2 = script.run();

        String expected1 = "ABC01242018JACK";
        String expected2 = "DEF0122018KATE";

        assertEquals(expected1, actual1);
        assertEquals(expected2, actual2);

    }

    @Test
    void parseScriptWithBindingFromString() {
        String scriptText = "if (MEMBER_ID && DATE_OF_BIRTH && NAME_FIRST) {\n" +
                "    tmp_DOB = (String)DATE_OF_BIRTH.replaceAll(\"/\", \"\")\n" +
                "    return MEMBER_ID + tmp_DOB + NAME_FIRST\n" +
                "}";

        Map<String,Object> sourceRecord1 = new HashMap<>();
        sourceRecord1.put("MEMBER_ID", "ABC");
        sourceRecord1.put("DATE_OF_BIRTH", "01/24/2018");
        sourceRecord1.put("NAME_FIRST", "JACK");

        GroovyShell shell = new GroovyShell();
        Binding binding = new Binding(sourceRecord1);
        Script script = shell.parse(scriptText);
        script.setBinding(binding);
        Object actual = script.run();

        String expected = "ABC01242018JACK";

        assertEquals(expected, actual);
    }

}
