package com.optum.cdi.core.shared.tests.integration.lifecycle;

import com.optum.cdi.core.shared.abstractions.CommonDataIntakeException;
import com.optum.cdi.core.shared.lifecycle.FieldTransformationProcessorLifecycle;
import org.junit.jupiter.api.Test;

import java.io.IOException;

public class FieldTransformationProcessorLifecycleTests {

    private static void processorLifecycleIntegrate(final String logicalFileSystemTag, final String scriptEngineTypeTag, final String scriptFileUri) throws CommonDataIntakeException {
        FieldTransformationProcessorLifecycle fieldTransformationProcessorLifecycle;
        fieldTransformationProcessorLifecycle = new FieldTransformationProcessorLifecycle(logicalFileSystemTag, scriptEngineTypeTag, scriptFileUri);

    }

    @Test
    void createLifecycleLocalFileSystemGroovyEngine() throws CommonDataIntakeException {
        String fs = "local";
        String engine = "groovy";
        String scriptLocation = "C:/Users/wcharlto/IdeaProjects/framework-mvp/src/core/shared/test/EnvironmentResourceTest.groovy";

        try {
            processorLifecycleIntegrate(fs, engine, scriptLocation);
        } catch (CommonDataIntakeException e) {
            e.printStackTrace();
        }
    }






}
