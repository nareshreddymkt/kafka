package com.optum.cdi.core.shared.tests.unit;

import com.optum.cdi.core.shared.FlatTextRecordImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class FlatTextRecordImplTests {
	@BeforeEach
	void setUp() {
	}

	@AfterEach
	void tearDown() {
	}

	@Test
	void shouldCreateTest() {
		Map<String, Object> mockNotNullMap;
		Map<String, String> mockNotNullMapStr;
		boolean isRawRecord = false;
		String rawRecordKey = null;
		String rawRecordValue = "dummy     data      fixed    for     testing";
		FlatTextRecordImpl flatTextRecord;

		mockNotNullMap = new HashMap<>();
		mockNotNullMapStr = new HashMap<>();

		mockNotNullMapStr.put("bob", "test");

		flatTextRecord = new FlatTextRecordImpl(isRawRecord, rawRecordKey, rawRecordValue, mockNotNullMapStr, mockNotNullMap, mockNotNullMapStr, mockNotNullMap);

		assertNotNull(flatTextRecord);
		assertNotNull(flatTextRecord.getUntypedValue());
		assertNotNull(flatTextRecord.getUntypedKey());
		assertNotNull(flatTextRecord.getTypedValue());
		assertNotNull(flatTextRecord.getTypedKey());
		assertNull(flatTextRecord.getRawRecordKey());
		assertNotNull(flatTextRecord.getRawRecordValue());
		assertFalse(flatTextRecord.isRawRecord());
	}


	@Test
	void shouldCreateRawTextRecordTest() {
		Map<String, Object> mockNotNullMap;
		Map<String, String> mockNotNullMapStr;
		boolean isRawRecord = true;
		String rawRecordKey = null;
		String rawRecordValue = "dummy     data      fixed    for     testing";
		FlatTextRecordImpl flatTextRecord;

		mockNotNullMap = new HashMap<>();
		mockNotNullMapStr = new HashMap<>();

		flatTextRecord = new FlatTextRecordImpl(isRawRecord, rawRecordKey, rawRecordValue,  mockNotNullMapStr, mockNotNullMap, mockNotNullMapStr, mockNotNullMap);

		assertNotNull(flatTextRecord);
		assertNotNull(flatTextRecord.getUntypedValue());
		assertNotNull(flatTextRecord.getUntypedKey());
		assertNotNull(flatTextRecord.getTypedValue());
		assertNotNull(flatTextRecord.getTypedKey());
		assertNull(flatTextRecord.getRawRecordKey());
		assertNotNull(flatTextRecord.getRawRecordValue());
		assertTrue(flatTextRecord.isRawRecord());
	}

	@Test
	void shouldFailOnNullUntypedKeyCreateTest() {
		Map<String, Object> mockNotNullMap;
		Map<String, Object> mockNullMap;
		Map<String, String> mockNotNullMapStr;
		Map<String, String> mockNullMapStr;
		boolean isRawRecord = true;
		String rawRecordKey = null;
		String rawRecordValue = "dummy     data      fixed    for     testing";

		mockNotNullMap = new HashMap<>();
		mockNullMap = null;
		mockNotNullMapStr = new HashMap<>();
		mockNullMapStr = null;

		Throwable exception = assertThrows(IllegalArgumentException.class, () -> {
			FlatTextRecordImpl flatTextRecord = new FlatTextRecordImpl(isRawRecord, rawRecordKey, rawRecordValue,  mockNullMapStr, mockNotNullMap, mockNotNullMapStr, mockNotNullMap); // should throw
		});
		assertEquals("untypedKey", exception.getMessage());
	}

	@Test
	void shouldFailOnNullTypedKeyCreateTest() {
		Map<String, Object> mockNotNullMap;
		Map<String, Object> mockNullMap;
		Map<String, String> mockNotNullMapStr;
		Map<String, String> mockNullMapStr;
		boolean isRawRecord = true;
		String rawRecordKey = null;
		String rawRecordValue = "dummy     data      fixed    for     testing";

		mockNotNullMap = new HashMap<>();
		mockNullMap = null;
		mockNotNullMapStr = new HashMap<>();
		mockNullMapStr = null;

		Throwable exception = assertThrows(IllegalArgumentException.class, () -> {
			FlatTextRecordImpl flatTextRecord = new FlatTextRecordImpl(isRawRecord, rawRecordKey, rawRecordValue,  mockNotNullMapStr, mockNullMap, mockNotNullMapStr, mockNotNullMap); // should throw
		});
		assertEquals("typedKey", exception.getMessage());
	}

	@Test
	void shouldFailOnNullUntypedValueCreateTest() {
		Map<String, Object> mockNotNullMap;
		Map<String, Object> mockNullMap;
		Map<String, String> mockNotNullMapStr;
		Map<String, String> mockNullMapStr;
		boolean isRawRecord = true;
		String rawRecordKey = null;
		String rawRecordValue = "dummy     data      fixed    for     testing";

		mockNotNullMap = new HashMap<>();
		mockNullMap = null;
		mockNotNullMapStr = new HashMap<>();
		mockNullMapStr = null;

		Throwable exception = assertThrows(IllegalArgumentException.class, () -> {
			FlatTextRecordImpl flatTextRecord = new FlatTextRecordImpl(isRawRecord, rawRecordKey, rawRecordValue,  mockNotNullMapStr, mockNotNullMap, mockNullMapStr, mockNotNullMap); // should throw
		});
		assertEquals("untypedValue", exception.getMessage());
	}

	@Test
	void shouldFailOnNullTypedValueCreateTest() {
		Map<String, Object> mockNotNullMap;
		Map<String, Object> mockNullMap;
		Map<String, String> mockNotNullMapStr;
		Map<String, String> mockNullMapStr;
		boolean isRawRecord = true;
		String rawRecordKey = null;
		String rawRecordValue = "dummy     data      fixed    for     testing";

		mockNotNullMap = new HashMap<>();
		mockNullMap = null;
		mockNotNullMapStr = new HashMap<>();
		mockNullMapStr = null;

		Throwable exception = assertThrows(IllegalArgumentException.class, () -> {
			FlatTextRecordImpl flatTextRecord = new FlatTextRecordImpl(isRawRecord, rawRecordKey, rawRecordValue,  mockNotNullMapStr, mockNotNullMap, mockNotNullMapStr, mockNullMap); // should throw
		});
		assertEquals("typedValue", exception.getMessage());
	}
}