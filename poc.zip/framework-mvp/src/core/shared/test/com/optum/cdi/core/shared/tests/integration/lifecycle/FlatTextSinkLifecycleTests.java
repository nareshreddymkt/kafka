package com.optum.cdi.core.shared.tests.integration.lifecycle;

import com.optum.cdi.core.shared.FlatTextRecordImpl;
import com.optum.cdi.core.shared.abstractions.CommonDataIntakeException;
import com.optum.cdi.core.shared.abstractions.FlatTextRecord;
import com.optum.cdi.core.shared.abstractions.FlatTextWriter;
import com.optum.cdi.core.shared.lifecycle.FlatTextSinkLifecycle;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class FlatTextSinkLifecycleTests {
	@BeforeEach
	void setUp() {
	}

	@AfterEach
	void tearDown() {
	}

	private static long sinkLifecycleIntegrate(final String logicalFileSystemTag, final String flatTextFormatTag, final String sinkMetadataFileUri, final String sinkDataFileUri, final long sinkInputOffset) throws CommonDataIntakeException {
		FlatTextSinkLifecycle flatTextSinkLifecycle;
		FlatTextWriter flatTextWriter;

		List<FlatTextRecord> flatTextRecords;
		FlatTextRecord flatTextRecord;

		long count;

		// DO NOT CHECK NULL ARGUMENTS HERE, LET THE CODE UNDER TEST THROW INSTEAD :)

		flatTextSinkLifecycle = new FlatTextSinkLifecycle(logicalFileSystemTag, flatTextFormatTag, sinkMetadataFileUri, sinkDataFileUri, sinkInputOffset);

		if (flatTextSinkLifecycle == null)
			throw new CommonDataIntakeException("null lifecycle");

		try {
			flatTextWriter = flatTextSinkLifecycle.getFlatTextWriter();

			if (flatTextWriter == null)
				throw new CommonDataIntakeException("null writer");

			flatTextRecords = new ArrayList<>();

			for (int i = 0; i < 100; i++) {

				flatTextRecord = FlatTextRecordImpl.fromRawRecord("", "bob");
				flatTextRecords.add(flatTextRecord);
				flatTextSinkLifecycle.incrementTotalRecordCount();

				flatTextRecord = FlatTextRecordImpl.fromParsedRecord("bob", Collections.singletonMap("x", "1"), Collections.singletonMap("x", 1), Collections.singletonMap("y", "2"), Collections.singletonMap("y", 2));
				flatTextRecords.add(flatTextRecord);
				flatTextSinkLifecycle.incrementTotalRecordCount();
			}

			count = flatTextWriter.write(flatTextRecords.iterator());

			flatTextSinkLifecycle.incrementTotalBatchCount();
		}
		finally {
			try {
				if (flatTextSinkLifecycle != null)
					flatTextSinkLifecycle.close();
			}
			catch (IOException ioex) {
				System.out.println(ioex);
				return -1;
			}
		}

		System.out.printf("Test complete... TotalCycleCount: %s | TotalRecordCount: %s | TotalLifecycleSeconds %s.\n", flatTextSinkLifecycle.getTotalBatchCount(), flatTextSinkLifecycle.getTotalRecordCount(), flatTextSinkLifecycle.getTotalLifecycleSeconds());

		return count;
	}

	@Test
	void shouldPerformSinkLifecycleUsingLocalLinesNullMetaFakeZeroTest() throws CommonDataIntakeException {
		final String logicalFileSystemTag = "local";
		final String flatTextFormatTag = "lines";
		final String sinkMetadataFileUri = "c:\\NUL";
		final String sinkDataFileUri = "C:\\kio\\bcbs-la-1010\\out\\fake.txt";
		final long sinkInputOffset = 0;

		sinkLifecycleIntegrate(logicalFileSystemTag, flatTextFormatTag, sinkMetadataFileUri, sinkDataFileUri, sinkInputOffset);
	}

	@Test
	void shouldPerformSinkLifecycleUsingLocalLinesJsonMetaPlanDetailCodeZeroTest() throws CommonDataIntakeException {
		final String logicalFileSystemTag = "local";
		final String flatTextFormatTag = "lines";
		final String sinkMetadataFileUri = "C:\\kio\\bcbs-la-1010\\meta\\plan_detail_cd_metadata.json";
		final String sinkDataFileUri = "C:\\kio\\bcbs-la-1010\\out\\plan_detail_cd.txt";
		final long sinkInputOffset = 0;

		assertEquals(200, sinkLifecycleIntegrate(logicalFileSystemTag, flatTextFormatTag, sinkMetadataFileUri, sinkDataFileUri, sinkInputOffset));
	}
}
