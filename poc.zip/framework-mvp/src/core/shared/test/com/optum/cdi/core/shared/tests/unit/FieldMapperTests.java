package com.optum.cdi.core.shared.tests.unit;

import com.optum.cdi.core.shared.FieldMapperImpl;
import com.optum.cdi.core.shared.ProcessorRecordImpl;
import com.optum.cdi.core.shared.abstractions.CommonDataIntakeException;
import com.optum.cdi.core.shared.abstractions.ProcessorRecord;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeAll;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class FieldMapperTests {

    private static InputStream fieldMappingInputStream;
    private static ProcessorRecord processorRecord;

    @BeforeAll
    static void getFieldMappingMetadataInputStream() {
        try {
            fieldMappingInputStream = new FileInputStream(Paths.get("C:/Users/wcharlto/IdeaProjects/framework-mvp/src/core/shared/test/FieldMappingTest.json").toFile());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    @BeforeAll
    static void createProcessorRecord() {
        Map<String,Object> origKey = new HashMap<>();
        Map<String,Object> origValue = new HashMap<>();
        origValue.put("MEMBER_ID", "ABC123");
        origValue.put("NAME_FIRST", "JACK");
        origValue.put("NAME_LAST", "WHITE");
        origValue.put("INDV_OTHR_ID", "TEMP");

        processorRecord = new ProcessorRecordImpl(origKey, origValue);
    }

    @Test
    void CreateFieldMapper_ValidInputStream_SourceFilterFalse() throws CommonDataIntakeException {
        FieldMapperImpl fieldMapper = new FieldMapperImpl(fieldMappingInputStream, false);
        assertEquals(false, fieldMapper.hasSourceFilter());
    }

    @Test
    void ApplyMapping_SourceFilterFalse_CheckSizeOriginalValueModifiedValue() throws CommonDataIntakeException {
        FieldMapperImpl fieldMapper = new FieldMapperImpl(fieldMappingInputStream, false);

        ProcessorRecord record = fieldMapper.applyMapping(processorRecord);
        assertEquals(record.getOriginalValue().size(), record.getModifiedValue().size());
    }

    @Test
    void ApplyMapping_SourceFilterTrue_CheckLengthOriginalValueModifiedValue() throws CommonDataIntakeException {
        FieldMapperImpl fieldMapper = new FieldMapperImpl(fieldMappingInputStream, true);

        ProcessorRecord record = fieldMapper.applyMapping(processorRecord);
        assertTrue(record.getOriginalValue().size() < record.getModifiedValue().size());
    }
}
