package com.optum.cdi.core.shared.tests.integration.lifecycle;

import com.optum.cdi.core.shared.abstractions.CommonDataIntakeException;
import com.optum.cdi.core.shared.abstractions.FlatTextParser;
import com.optum.cdi.core.shared.abstractions.FlatTextRecord;
import com.optum.cdi.core.shared.lifecycle.FlatTextProcessorLifecycle;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;

public class FlatTextProcessorLifecycleTests {
	@BeforeEach
	void setUp() {
	}

	@AfterEach
	void tearDown() {
	}

	private static void processorLifecycleIntegrate(final String logicalFileSystemTag, final String flatTextFormatTag, final String sourceMetadataFileUri, final String rawRecordLine) throws CommonDataIntakeException {
		FlatTextProcessorLifecycle flatTextProcessorLifecycle;
		FlatTextParser flatTextParser;
		FlatTextRecord flatTextRecord;

		// DO NOT CHECK NULL ARGUMENTS HERE, LET THE CODE UNDER TEST THROW INSTEAD :)

		flatTextProcessorLifecycle = new FlatTextProcessorLifecycle(logicalFileSystemTag, flatTextFormatTag, sourceMetadataFileUri);

		if (flatTextProcessorLifecycle == null)
			throw new CommonDataIntakeException("null lifecycle");

		try {
			flatTextParser = flatTextProcessorLifecycle.getFlatTextParser();

			if (flatTextParser == null)
				throw new CommonDataIntakeException("null parser");

			for (int i = 0; i < 10000; i++) {
				flatTextRecord = flatTextParser.parseLine(rawRecordLine);

				if (flatTextRecord != null) {
					System.out.println(flatTextRecord.getUntypedValue());
				} else
					System.out.println("<null>");

				flatTextProcessorLifecycle.incrementTotalRecordCount();
			}

			flatTextProcessorLifecycle.incrementTotalBatchCount();
		}
		finally {
			try {
				if (flatTextProcessorLifecycle != null)
					flatTextProcessorLifecycle.close();
			}
			catch (IOException ioex) {
				System.out.println(ioex);
				return;
			}
		}

		System.out.printf("Test complete... TotalCycleCount: %s | TotalRecordCount: %s | TotalLifecycleSeconds %s.\n", flatTextProcessorLifecycle.getTotalBatchCount(), flatTextProcessorLifecycle.getTotalRecordCount(), flatTextProcessorLifecycle.getTotalLifecycleSeconds());
	}

	@Test
	void shouldPerformSourceLifecycleUsingLocalFixedNullMetaPlanDetailCodeValidTest() throws CommonDataIntakeException {
		final String logicalFileSystemTag = "local";
		final String flatTextFormatTag = "fixed";
		final String sourceMetadataFileUri = "c:\\NUL";
		final String rawRecordLine = "";

		processorLifecycleIntegrate(logicalFileSystemTag, flatTextFormatTag, sourceMetadataFileUri, rawRecordLine);
	}

	@Test
	void shouldPerformSourceLifecycleUsingLocalFixedJsonMetaPlanDetailCodeValidTest() throws CommonDataIntakeException {
		final String logicalFileSystemTag = "local";
		final String flatTextFormatTag = "fixed";
		final String sourceMetadataFileUri = "C:\\kio\\bcbs-la-1010\\meta\\plan_detail_cd_metadata.json";
		final String rawRecordLine = "30N55ERCW0420016CSTAL17W01A0W0420016GRP BS EMBEDDED VISION                                                CSTASTATE CONTINUATION                                                    L17W01A0GRP EMBEDDED PEDIATRIC VISION - ERISA                                 LHSIBEMBEDDED PEDIATRIC VISION                                             ~  2001604~         ~             ~ NOT APPLICABLE           NNNNOT APPLICABLE           NOT APPLICABLE           NOT APPLICABLE                                                                                        D";

		processorLifecycleIntegrate(logicalFileSystemTag, flatTextFormatTag, sourceMetadataFileUri, rawRecordLine);
	}
}
