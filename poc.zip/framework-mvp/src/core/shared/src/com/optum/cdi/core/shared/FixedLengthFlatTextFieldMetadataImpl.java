package com.optum.cdi.core.shared;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.cdi.core.shared.abstractions.FIELD_TYPE;
import com.optum.cdi.core.shared.abstractions.FixedLengthFlatTextFieldMetadata;

public class FixedLengthFlatTextFieldMetadataImpl implements FixedLengthFlatTextFieldMetadata {

	public FixedLengthFlatTextFieldMetadataImpl() {
	}

	private int startPosition;
	private int fieldLength;
	private String fieldName;
	private int fieldIndex;
	private FIELD_TYPE fieldType;
	private boolean fieldIsRequired;
	private boolean fieldIsKeyPart;
	private String sourceName;

	@Override
	@JsonProperty("sourceName")
	public String getSourceName() {
		return this.sourceName;
	}

	@JsonProperty("sourceName")
	public void setSourceName(String sourceName) {
		this.sourceName = sourceName;
	}

	@Override
	@JsonProperty("startPosition")
	public int getStartPosition() {
		return startPosition;
	}

	@JsonProperty("startPosition")
	public void setStartPosition(int startPosition) {
		this.startPosition = startPosition;
	}

	@Override
	@JsonProperty("fieldLength")
	public int getFieldLength() {
		return fieldLength;
	}

	@JsonProperty("fieldLength")
	public void setFieldLength(int fieldLength) {
		this.fieldLength = fieldLength;
	}

	@Override
	@JsonProperty("fieldName")
	public String getFieldName() {
		return fieldName;
	}

	@JsonProperty("fieldName")
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	@Override
	@JsonProperty("fieldIndex")
	public int getFieldIndex() {
		return fieldIndex;
	}

	@JsonProperty("fieldIndex")
	public void setFieldIndex(int fieldIndex) {
		this.fieldIndex = fieldIndex;
	}

	@Override
	@JsonProperty("fieldType")
	public FIELD_TYPE getFieldType() {
		return fieldType;
	}

	@JsonProperty("fieldType")
	public void setFieldType(FIELD_TYPE fieldType) {
		this.fieldType = fieldType;
	}

	@Override
	@JsonProperty("fieldIsRequired")
	public boolean getFieldIsRequired() {
		return fieldIsRequired;
	}

	@JsonProperty("fieldIsRequired")
	public void setFieldIsRequired(boolean fieldIsRequired) {
		this.fieldIsRequired = fieldIsRequired;
	}

	@Override
	@JsonProperty("fieldIsKeyPart")
	public boolean getFieldIsKeyPart() {
		return fieldIsKeyPart;
	}

	@JsonProperty("fieldIsKeyPart")
	public void setFieldIsKeyPart(boolean fieldIsKeyPart) {
		this.fieldIsKeyPart = fieldIsKeyPart;
	}
}
