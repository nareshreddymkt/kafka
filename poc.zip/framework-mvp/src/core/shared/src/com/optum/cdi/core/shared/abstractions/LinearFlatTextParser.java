package com.optum.cdi.core.shared.abstractions;

public interface LinearFlatTextParser extends FlatTextParser {

}
