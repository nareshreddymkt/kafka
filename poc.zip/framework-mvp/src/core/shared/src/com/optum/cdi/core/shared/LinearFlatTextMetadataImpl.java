package com.optum.cdi.core.shared;

import com.optum.cdi.core.shared.abstractions.FlatTextFieldMetadata;
import com.optum.cdi.core.shared.abstractions.LinearFlatTextMetadata;

import java.util.List;

public class LinearFlatTextMetadataImpl implements LinearFlatTextMetadata {

	public LinearFlatTextMetadataImpl() {
	}

	@Override
	public String getSourceName() {
		return null;
	}

	@Override
	public boolean getHasHeaderRecord() {
		return false;
	}

	@Override
	public boolean getHasTrailerRecord() {
		return false;
	}

	@Override
	public String getRecordTerminator() {
		return null;
	}

	@Override
	public List<FlatTextFieldMetadata> getFlatTextFields() {
		return null;
	}

	@Override
	public long translateOffsetToSkipChars(long originalOffset) {
		return originalOffset; // TODO: verify
	}
}
