package com.optum.cdi.core.shared.lifecycle;

import com.optum.cdi.core.shared.FlatTextWriterFactoryImpl;
import com.optum.cdi.core.shared.abstractions.CommonDataIntakeException;
import com.optum.cdi.core.shared.abstractions.FlatTextWriter;
import com.optum.cdi.core.shared.abstractions.FlatTextWriterFactory;

import java.io.IOException;
import java.io.OutputStream;

public final class FlatTextSinkLifecycle extends FlatTextLifecycle {

	public FlatTextSinkLifecycle(String logicalFileSystemTag, String flatTextFormatTag, String sinkMetadataFileUri, String sinkDataFileUri, long sinkOutputOffset) throws CommonDataIntakeException {
		super(logicalFileSystemTag, flatTextFormatTag, sinkMetadataFileUri, sinkDataFileUri);

		OutputStream sinkOutputStream; // this stream is owned by the flat text reader impl class

		sinkOutputStream = this.getLogicalFileSystem().createFile(sinkDataFileUri);
		this.flatTextWriter = getFlatTextWriterFactory().getInstance(this.getFlatTextMetadata(), sinkOutputStream, sinkOutputOffset);
	}

	private static final FlatTextWriterFactory flatTextWriterFactory = new FlatTextWriterFactoryImpl(getFlatTextFormatterFactory());
	private final FlatTextWriter flatTextWriter;

	public static FlatTextSinkLifecycle create(String logicalFileSystemTag, String flatTextFormatTag, String sinkMetadataFileUri, String sinkDataFileUri, long sinkOutputOffset) {
		try {
			return new FlatTextSinkLifecycle(logicalFileSystemTag, flatTextFormatTag, sinkMetadataFileUri, sinkDataFileUri, sinkOutputOffset);
		}
		catch (CommonDataIntakeException cdiex) {
			getLogger().error(cdiex);
			return null;
		}
	}

	protected static FlatTextWriterFactory getFlatTextWriterFactory() {
		return FlatTextSinkLifecycle.flatTextWriterFactory;
	}

	@Override
	public void close() throws IOException {
		try {
			if (this.getFlatTextWriter() != null) {
				this.getFlatTextWriter().flush();
				this.getFlatTextWriter().close();
			}
		}
		finally {
			super.close();
		}
	}

	public FlatTextWriter getFlatTextWriter() {
		return this.flatTextWriter;
	}
}
