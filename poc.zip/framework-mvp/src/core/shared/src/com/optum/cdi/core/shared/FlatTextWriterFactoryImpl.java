package com.optum.cdi.core.shared;

import com.optum.cdi.core.shared.abstractions.*;

import java.io.OutputStream;

public class FlatTextWriterFactoryImpl implements FlatTextWriterFactory {

	public FlatTextWriterFactoryImpl(FlatTextFormatterFactory flatTextFormatterFactory) {
		if (flatTextFormatterFactory == null)
			throw new IllegalArgumentException("flatTextFormatterFactory");

		this.flatTextFormatterFactory = flatTextFormatterFactory;
	}

	private final FlatTextFormatterFactory flatTextFormatterFactory;

	@Override
	public FlatTextWriter getInstance(FlatTextMetadata flatTextMetadata, OutputStream outputStream, long originalOffset) throws CommonDataIntakeException {
		if (flatTextMetadata instanceof LinearFlatTextMetadata) {
			return new LinearFlatTextWriterImpl((LinearFlatTextMetadata) flatTextMetadata, (LinearFlatTextFormatter) this.getFlatTextFormatterFactory().getInstance(flatTextMetadata), outputStream, originalOffset);
		} else
			throw new CommonDataIntakeException(String.format("Unknown flat text metadata runtime type: %s", flatTextMetadata != null ? flatTextMetadata.getClass().getName() : "<null>"));
	}

	protected FlatTextFormatterFactory getFlatTextFormatterFactory() {
		return flatTextFormatterFactory;
	}
}
