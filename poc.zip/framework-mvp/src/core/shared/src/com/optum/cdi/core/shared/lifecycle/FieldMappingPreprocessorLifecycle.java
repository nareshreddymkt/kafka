package com.optum.cdi.core.shared.lifecycle;

import com.optum.cdi.core.shared.abstractions.CommonDataIntakeException;


public class FieldMappingPreprocessorLifecycle extends AbstractLifecycle {
	public FieldMappingPreprocessorLifecycle(String logicalFileSystemTag, String mappingMetadataFileUri) throws CommonDataIntakeException {
		super(logicalFileSystemTag, mappingMetadataFileUri);
	}

	public static FieldMappingPreprocessorLifecycle create(String logicalFileSystemTag, String mappingMetadataFileUri) {
		try {
			return new FieldMappingPreprocessorLifecycle(logicalFileSystemTag, mappingMetadataFileUri);
		}
		catch (CommonDataIntakeException cdiex) {
			getLogger().error(cdiex);
			return null;
		}
	}
}

