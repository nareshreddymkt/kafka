package com.optum.cdi.core.shared.abstractions;

public interface ScriptExecutionEnvironment {
    ProcessorRecord evaluate(ProcessorRecord record);
}
