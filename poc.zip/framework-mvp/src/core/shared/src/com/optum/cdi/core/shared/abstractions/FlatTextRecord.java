package com.optum.cdi.core.shared.abstractions;

import java.util.Map;

public interface FlatTextRecord {

	Map<String, String> getUntypedKey();

	Map<String, Object> getTypedKey();

	Map<String, String> getUntypedValue();

	Map<String, Object> getTypedValue();

	String getRawRecordKey();

	String getRawRecordValue();

	boolean isRawRecord();
}
