package com.optum.cdi.core.shared;

import java.io.Closeable;
import java.io.IOException;
import java.util.Iterator;
import java.util.function.Function;

public class IteratorProjector<T, Q> implements Iterator<Q>, Closeable {

	private final Iterator<T> inner;
	private final Function<T, Q> change;

	public IteratorProjector(Iterator<T> inner, Function<T, Q> change) {

		if (inner == null)
			throw new IllegalArgumentException("inner");

		if (change == null)
			throw new IllegalArgumentException("change");

		this.inner = inner;
		this.change = change;
	}

	@Override
	public boolean hasNext() {
		return this.getInner().hasNext();
	}

	@Override
	public Q next() {
		T item;
		Q result;

		item = this.getInner().next();
		result = this.getChange().apply(item);

		return result;
	}

	private Iterator<T> getInner() {
		return inner;
	}

	private Function<T, Q> getChange() {
		return change;
	}

	@Override
	public void close() throws IOException {
		if (this.getInner() instanceof Closeable)
			((Closeable) this.getInner()).close();
	}
}
