package com.optum.cdi.core.shared;

import com.optum.cdi.core.shared.abstractions.*;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Iterator;

public class LinearFlatTextWriterImpl extends AbstractFlatTextWriter<LinearFlatTextMetadata, LinearFlatTextFormatter> {
	public LinearFlatTextWriterImpl(LinearFlatTextMetadata linearFlatTextMetadata, LinearFlatTextFormatter linearFlatTextFormatter, OutputStream outputStream, long originalOffset) {
		super(linearFlatTextMetadata, linearFlatTextFormatter, outputStream, originalOffset);
	}
}
