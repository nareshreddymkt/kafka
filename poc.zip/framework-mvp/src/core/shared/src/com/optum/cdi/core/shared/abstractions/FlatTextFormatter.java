package com.optum.cdi.core.shared.abstractions;

public interface FlatTextFormatter {
	String format(FlatTextRecord flatTextRecord);
}
