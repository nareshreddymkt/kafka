package com.optum.cdi.core.shared.abstractions;

import java.io.InputStream;

public interface FlatTextReaderFactory {
	FlatTextReader getInstance(FlatTextMetadata flatTextMetadata, InputStream inputStream, long originalOffset) throws CommonDataIntakeException;
}
