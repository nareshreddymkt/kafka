package com.optum.cdi.core.shared.abstractions;

public interface FieldMapper {
	boolean hasSourceFilter();

	ProcessorRecord applyMapping(ProcessorRecord processorRecord);
}
