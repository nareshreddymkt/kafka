package com.optum.cdi.core.shared.lifecycle;

import com.optum.cdi.core.shared.ScriptExecutionEnvironmentFactoryImpl;
import com.optum.cdi.core.shared.abstractions.CommonDataIntakeException;
import com.optum.cdi.core.shared.abstractions.ScriptExecutionEnvironment;
import com.optum.cdi.core.shared.abstractions.ScriptExecutionEnvironmentFactory;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.time.Instant;


public class FieldTransformationProcessorLifecycle extends AbstractLifecycle {
    private static final Logger logger = Logger.getLogger(FieldTransformationProcessorLifecycle.class);

    private static final ScriptExecutionEnvironmentFactory scriptExecutionEnvironmentFactory = new ScriptExecutionEnvironmentFactoryImpl();
    private final ScriptExecutionEnvironment scriptExecutionEnvironment;

    private Instant lifecycleDisposed;

    public FieldTransformationProcessorLifecycle(String logicalFileSystemTag, String scriptFileUri, String scriptEngineTypeTag) throws CommonDataIntakeException {
        super(logicalFileSystemTag, scriptFileUri);

        if (scriptEngineTypeTag == null)
            throw new IllegalArgumentException("flatTextFormatTag");

        InputStream scriptInputStream = this.getLogicalFileSystem().openFile(scriptFileUri);
        this.scriptExecutionEnvironment = getScriptExecutionEnvironmentFactory().getInstance(scriptEngineTypeTag, scriptInputStream);
    }

    public static FieldTransformationProcessorLifecycle create(String logicalFileSystemTag,  String scriptFileUri, String scriptEngineTypeTag) {
        try {
            return new FieldTransformationProcessorLifecycle(logicalFileSystemTag, scriptEngineTypeTag, scriptFileUri);
        } catch (CommonDataIntakeException cdiex) {
            getLogger().error(cdiex);
            return null;
        }
    }

    @Override
    public void close() throws IOException {

        if (this.getLifecycleDisposed() == null)
            this.setLifecycleDisposed(Instant.now());
    }

    protected static Logger getLogger() {
        return logger;
    }

    private static ScriptExecutionEnvironmentFactory getScriptExecutionEnvironmentFactory() {
        return scriptExecutionEnvironmentFactory;
    }

    public ScriptExecutionEnvironment getScriptExecutionEnvironment() {
        return scriptExecutionEnvironment;
    }

    private Instant getLifecycleDisposed() {
        return lifecycleDisposed;
    }

    private void setLifecycleDisposed(Instant lifecycleDisposed) {
        this.lifecycleDisposed = lifecycleDisposed;
    }
}
