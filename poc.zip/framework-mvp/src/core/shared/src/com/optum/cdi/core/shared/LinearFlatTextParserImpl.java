package com.optum.cdi.core.shared;

import com.optum.cdi.core.shared.abstractions.FlatTextParser;
import com.optum.cdi.core.shared.abstractions.FlatTextRecord;
import com.optum.cdi.core.shared.abstractions.LinearFlatTextMetadata;

public class LinearFlatTextParserImpl implements FlatTextParser {
	public LinearFlatTextParserImpl(LinearFlatTextMetadata linearFlatTextMetadata) {
		if (linearFlatTextMetadata == null)
			throw new IllegalArgumentException("linearFlatTextMetadata");

		this.linearFlatTextMetadata = linearFlatTextMetadata;
	}

	private final LinearFlatTextMetadata linearFlatTextMetadata;

	@Override
	public FlatTextRecord parseLine(final String rawLogicalRecord) {
		return FlatTextRecordImpl.fromRawRecord("", rawLogicalRecord);
	}

	private LinearFlatTextMetadata getLinearFlatTextMetadataMetadata() {
		return linearFlatTextMetadata;
	}
}
