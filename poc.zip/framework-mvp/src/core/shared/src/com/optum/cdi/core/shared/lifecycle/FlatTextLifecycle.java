package com.optum.cdi.core.shared.lifecycle;

import com.optum.cdi.core.shared.FlatTextFormatterFactoryImpl;
import com.optum.cdi.core.shared.FlatTextMetadataFactoryImpl;
import com.optum.cdi.core.shared.FlatTextParserFactoryImpl;
import com.optum.cdi.core.shared.abstractions.*;
import org.apache.log4j.Logger;

import java.io.InputStream;

public abstract class FlatTextLifecycle extends AbstractLifecycle {
	protected FlatTextLifecycle(String logicalFileSystemTag, String flatTextFormatTag, String metadataFileUri, String dataFileUri) throws CommonDataIntakeException {
		super(logicalFileSystemTag, metadataFileUri);

		if (flatTextFormatTag == null)
			throw new IllegalArgumentException("flatTextFormatTag");

		if (dataFileUri == null)
			throw new IllegalArgumentException("dataFileUri");

		final InputStream metadataInputStream = this.getMetadataInputStream(); // this stream is owned by the metadata factory impl class
		this.flatTextMetadata = getFlatTextMetadataFactory().getInstance(flatTextFormatTag, metadataInputStream);
	}

	private static final FlatTextMetadataFactory flatTextMetadataFactory = new FlatTextMetadataFactoryImpl();
	private static final FlatTextParserFactory flatTextParserFactory = new FlatTextParserFactoryImpl();
	private static final FlatTextFormatterFactory flatTextFormatterFactory = new FlatTextFormatterFactoryImpl();
	private static final Logger logger = Logger.getLogger(FlatTextLifecycle.class);
	private final FlatTextMetadata flatTextMetadata;

	protected static Logger getLogger() {
		return logger;
	}

	protected static FlatTextMetadataFactory getFlatTextMetadataFactory() {
		return flatTextMetadataFactory;
	}

	protected static FlatTextParserFactory getFlatTextParserFactory() {
		return flatTextParserFactory;
	}

	protected static FlatTextFormatterFactory getFlatTextFormatterFactory() {
		return flatTextFormatterFactory;
	}

	public FlatTextMetadata getFlatTextMetadata() {
		return this.flatTextMetadata;
	}
}
