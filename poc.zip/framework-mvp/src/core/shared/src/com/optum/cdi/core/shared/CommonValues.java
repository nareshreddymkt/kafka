package com.optum.cdi.core.shared;

public class CommonValues {
	public final static String CDI_FRAMEWORK_VERSION = "0.0.4.0";
	public final static String CDI_LOGICAL_FILE_SYSTEM_TAG_LOCAL = "local";
	public final static String CDI_LOGICAL_FILE_SYSTEM_TAG_HDFS = "hdfs";
	public final static String CDI_FLAT_TEXT_FORMAT_TAG_LINES = "lines";
	public final static String CDI_FLAT_TEXT_FORMAT_TAG_FIXEDLEN = "fixed";
	public final static String CDI_FLAT_TEXT_FORMAT_TAG_DELIMITED = "delimited";


	public static final String SOURCE_DATA_FILE_URI_CONFIG = "sourcedatafileuri";
	public static final String SOURCE_METADATA_FILE_URI_CONFIG = "sourcemetadatafileuri";
	public static final String SINK_DATA_FILE_URI_CONFIG = "sinkdatafileuri";
	public static final String SINK_METADATA_FILE_URI_CONFIG = "sinkmetadatafileuri";
	public static final String LFS_TAG_CONFIG = "logicalfilesystemtag";
	public static final String FTF_TAG_CONFIG = "flattextformattag";
	public static final String TARGET_TOPIC_CONFIG = "targettopic";
	public static final String PROCESSOR_METADATA_FILE_URI_CONFIG = "processormetadatafileuri";
	public static final String SCRIPT_FILE_URI_CONFIG = "scriptfileuri";
	public static final String SCRIPT_TYPE_CONFIG = "pythongroovyruby";
}
