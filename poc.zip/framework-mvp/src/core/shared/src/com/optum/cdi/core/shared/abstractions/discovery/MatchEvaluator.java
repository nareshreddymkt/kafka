package com.optum.cdi.core.shared.abstractions.discovery;

public interface MatchEvaluator {
	boolean match(Object context);
}
