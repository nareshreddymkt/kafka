package com.optum.cdi.core.shared;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.cdi.core.shared.abstractions.FixedLengthFlatTextFieldMetadata;
import com.optum.cdi.core.shared.abstractions.FixedLengthFlatTextMetadata;
import com.optum.cdi.core.shared.abstractions.FlatTextFieldMetadata;

import java.util.ArrayList;
import java.util.List;

public class FixedLengthFlatTextMetadataImpl implements FixedLengthFlatTextMetadata {

	public FixedLengthFlatTextMetadataImpl() {
	}

	private final List<FixedLengthFlatTextFieldMetadata> fixedLengthFields = new ArrayList<>();
	private boolean hasHeaderRecord;
	private boolean hasTrailerRecord;
	private String recordTerminator;
	private Integer lineLength;
	private String sourceName;

	@Override
	@JsonProperty("sourceName")
	public String getSourceName() {
		return this.sourceName;
	}

	@JsonProperty("sourceName")
	public void setSourceName(String sourceName) {
		this.sourceName = sourceName;
	}

	@Override
	@JsonProperty("hasHeader")
	public boolean getHasHeaderRecord() {
		return this.hasHeaderRecord;
	}

	@JsonProperty("hasHeader")
	public void setHasHeaderRecord(boolean hasHeaderRecord) {
		this.hasHeaderRecord = hasHeaderRecord;
	}

	@Override
	@JsonProperty("hasTrailer")
	public boolean getHasTrailerRecord() {
		return this.hasTrailerRecord;
	}

	@JsonProperty("hasTrailer")
	public void setHasTrailerRecord(boolean hasTrailerRecord) {
		this.hasTrailerRecord = hasTrailerRecord;
	}

	@Override
	@JsonProperty("endOfRecord")
	public String getRecordTerminator() {
		return this.recordTerminator;
	}

	@JsonProperty("endOfRecord")
	public void setRecordTerminator(String recordTerminator) {
		this.recordTerminator = recordTerminator;
	}

	@Override
	@JsonProperty("lineLength")
	public int getLineLength() {
		return lineLength;
	}

	@JsonProperty("lineLength")
	public void setLineLength(Integer lineLength) {
		this.lineLength = lineLength;
	}

	@Override
	@JsonProperty("fixedLengthFields")
	public List<FixedLengthFlatTextFieldMetadata> getFixedLengthFields() {
		return this.fixedLengthFields;
	}

	@Override
	public List<FlatTextFieldMetadata> getFlatTextFields() {
		return new ArrayList<>(this.getFixedLengthFields());
	}

	@Override
	public long translateOffsetToSkipChars(long originalOffset) {
		return this.getLineLength() * originalOffset; // TODO: verify
	}
}
