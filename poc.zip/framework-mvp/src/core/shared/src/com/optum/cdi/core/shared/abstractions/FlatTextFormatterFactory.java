package com.optum.cdi.core.shared.abstractions;

public interface FlatTextFormatterFactory {
	FlatTextFormatter getInstance(FlatTextMetadata flatTextMetadata) throws CommonDataIntakeException;
}
