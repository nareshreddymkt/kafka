package com.optum.cdi.core.shared.abstractions;

public interface FlatTextParserFactory {
	FlatTextParser getInstance(FlatTextMetadata flatTextMetadata) throws CommonDataIntakeException;
}
