package com.optum.cdi.core.shared.abstractions;

public interface FlatTextParser {
	FlatTextRecord parseLine(String rawLogicalRecord);
}
