package com.optum.cdi.core.shared.telemetry;

public interface BasicLifecycleTelemetry {
	long getTotalRecordCount();

	long getTotalBatchCount();

	long getTotalLifecycleSeconds();


	double calcRecordThroughput();

	double calcBatchThroughput();


	void incrementTotalRecordCount(long value);

	void incrementTotalRecordCount();

	void incrementTotalBatchCount();
}
