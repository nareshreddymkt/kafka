package com.optum.cdi.core.shared.abstractions;

import java.io.Closeable;
import java.util.Iterator;

public interface FlatTextReader extends Closeable, Iterator<FlatTextRecord> {
	long getCurrentOffset();
	Iterator<FlatTextRecord> read();
}
