package com.optum.cdi.core.shared.abstractions;

import java.util.Map;

public interface ProcessorRecord {
    Map<String, ?> getOriginalKey();
    Map<String, ?> getOriginalValue();
    Map<String, ?> getModifiedValue();
    void setModifiedValue(Map<String, ?> modifiedValue);
}
