package com.optum.cdi.core.shared.abstractions;

public interface FlatTextFieldMetadata {

	String getFieldName();

	int getFieldIndex();

	FIELD_TYPE getFieldType();

	boolean getFieldIsRequired();

	boolean getFieldIsKeyPart();

	String getSourceName();
}
