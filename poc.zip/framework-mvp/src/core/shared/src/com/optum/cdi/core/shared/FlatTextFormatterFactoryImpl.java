package com.optum.cdi.core.shared;

import com.optum.cdi.core.shared.abstractions.*;

public class FlatTextFormatterFactoryImpl implements FlatTextFormatterFactory {

	@Override
	public FlatTextFormatter getInstance(FlatTextMetadata flatTextMetadata) throws CommonDataIntakeException {
		if (flatTextMetadata instanceof LinearFlatTextMetadata) {
			return new LinearFlatTextFormatterImpl((LinearFlatTextMetadata) flatTextMetadata);
		} else
			throw new CommonDataIntakeException(String.format("Unknown flat text metadata runtime type: %s", flatTextMetadata != null ? flatTextMetadata.getClass().getName() : "<null>"));
	}

}
