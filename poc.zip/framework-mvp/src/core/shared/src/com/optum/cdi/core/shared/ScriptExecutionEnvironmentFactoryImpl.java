package com.optum.cdi.core.shared;

import com.optum.cdi.core.shared.abstractions.CommonDataIntakeException;
import com.optum.cdi.core.shared.abstractions.ScriptExecutionEnvironment;
import com.optum.cdi.core.shared.abstractions.ScriptExecutionEnvironmentFactory;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.stream.Stream;

public class ScriptExecutionEnvironmentFactoryImpl implements ScriptExecutionEnvironmentFactory {

    private InputStream scriptInputStream;


    @Override
    public ScriptExecutionEnvironment getInstance(String scriptEngineTypeTag, InputStream scriptInputStream) throws CommonDataIntakeException {
        ScriptExecutionEnvironment executionEnvironment;
        String scriptText;

        //Check arguments
        if (scriptEngineTypeTag == null || scriptEngineTypeTag.isEmpty()) {
            throw new IllegalArgumentException("scriptEngineTypeTag");
        }

        if (scriptInputStream == null) {
            throw new IllegalArgumentException("scriptInputStream");
        }
        else {
            this.scriptInputStream = scriptInputStream;
        }

        //Supplied script text from input stream
        try {
            scriptText = getScriptText();
        } catch (IOException e) {
            throw new CommonDataIntakeException(e.toString());
        }

        switch (scriptEngineTypeTag.toLowerCase()) {
            case "groovy":
                executionEnvironment = new ScriptExecutionEnvironmentGroovy(scriptText);
                break;
            case "python":
                throw new CommonDataIntakeException("python scriptEngineTypeTag not yet implemented");
            case "ruby":
                throw new CommonDataIntakeException("ruby scriptEngineTypeTag not yet implemented");
            default:
                throw new CommonDataIntakeException("unknown scriptEngineTypeTag");
        }
        return executionEnvironment;
    }

    private String getScriptText() throws IOException {
        //High-speed read to get the whole script file into memory
        ByteArrayOutputStream result = new ByteArrayOutputStream();
        byte[] buffer = new byte[2048];
        int length;
        while ((length = scriptInputStream.read(buffer)) != -1) {
            result.write(buffer, 0, length);
        }
        return result.toString(StandardCharsets.UTF_8.name());
    }
}
