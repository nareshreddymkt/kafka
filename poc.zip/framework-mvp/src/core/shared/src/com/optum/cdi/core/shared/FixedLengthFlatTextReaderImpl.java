package com.optum.cdi.core.shared;

import com.optum.cdi.core.shared.abstractions.AbstractFlatTextReader;
import com.optum.cdi.core.shared.abstractions.FixedLengthFlatTextParser;
import com.optum.cdi.core.shared.abstractions.FixedLengthFlatTextMetadata;

import java.io.InputStream;

public class FixedLengthFlatTextReaderImpl extends AbstractFlatTextReader<FixedLengthFlatTextMetadata, FixedLengthFlatTextParser> {
	public FixedLengthFlatTextReaderImpl(FixedLengthFlatTextMetadata fixedLengthTextMetadata, FixedLengthFlatTextParser fixedLengthTextParser, InputStream inputStream, long originalOffset) {
		super(fixedLengthTextMetadata, fixedLengthTextParser, inputStream, originalOffset);
	}
}
