package com.optum.cdi.core.shared;

import com.optum.cdi.core.shared.abstractions.AbstractFlatTextReader;
import com.optum.cdi.core.shared.abstractions.LinearFlatTextMetadata;

import java.io.InputStream;

public class LinearFlatTextReaderImpl extends AbstractFlatTextReader<LinearFlatTextMetadata, LinearFlatTextParserImpl> {
	public LinearFlatTextReaderImpl(LinearFlatTextMetadata linearFlatTextMetadata, LinearFlatTextParserImpl linearFlatTextParser, InputStream inputStream, long originalOffset) {
		super(linearFlatTextMetadata, linearFlatTextParser, inputStream, originalOffset);
	}
}
