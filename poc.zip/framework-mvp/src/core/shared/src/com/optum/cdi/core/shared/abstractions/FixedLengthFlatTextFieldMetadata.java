package com.optum.cdi.core.shared.abstractions;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.optum.cdi.core.shared.FixedLengthFlatTextFieldMetadataImpl;

@JsonDeserialize(as = FixedLengthFlatTextFieldMetadataImpl.class)
public interface FixedLengthFlatTextFieldMetadata extends FlatTextFieldMetadata {

	int getStartPosition();

	int getFieldLength();
}
