package com.optum.cdi.core.shared.abstractions;

import org.apache.log4j.Logger;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Iterator;

public abstract class AbstractFlatTextWriter<TMetadata extends FlatTextMetadata, TFormatter extends FlatTextFormatter> implements FlatTextWriter {
	private static final Logger logger = Logger.getLogger(AbstractFlatTextWriter.class);
	private final TMetadata flatTextMetadata;
	private final TFormatter flatTextFormatter;
	private final OutputStream outputStream;
	private final BufferedWriter bufferedWriter;
	private final long originalOffset;
	private long currentLineOffset;
	
	protected AbstractFlatTextWriter(TMetadata flatTextMetadata, TFormatter flatTextFormatter, OutputStream outputStream, long originalOffset) {
		if (flatTextMetadata == null)
			throw new IllegalArgumentException("flatTextMetadata");

		if (flatTextFormatter == null)
			throw new IllegalArgumentException("flatTextFormatter");

		if (outputStream == null)
			throw new IllegalArgumentException("outputStream");

		if (originalOffset < 0)
			throw new IllegalArgumentException("originalOffset");

		this.flatTextMetadata = flatTextMetadata;
		this.flatTextFormatter = flatTextFormatter;
		this.outputStream = outputStream;
		this.originalOffset = originalOffset;

		this.bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream));
	}

	private static Logger getLogger() {
		return logger;
	}

	protected String getRecordTerminator() {
		return this.getFlatTextMetadata().getRecordTerminator();
	}

	@Override
	public long write(Iterator<FlatTextRecord> flatTextRecords) {
		String value;
		FlatTextRecord flatTextRecord;

		final String recordTerminator = this.getRecordTerminator();

		if (flatTextRecords == null)
			throw new IllegalArgumentException("flatTextRecords");

		try {
			long count = 0;
			while (flatTextRecords.hasNext()) {
				flatTextRecord = flatTextRecords.next();

				if (flatTextRecord == null)
					continue;

				// feels a little odd here
				value = this.getFlatTextFormatter().format(flatTextRecord);

				if (count > 0)
					value = (recordTerminator != null ? recordTerminator : System.lineSeparator()) + value;

				this.getBufferedWriter().write(value);

				count++;
			}

			return count;
		}
		catch (IOException ioex) {
			// intentionally swallow this exception for now
			getLogger().debug(ioex);
			//throw new CommonDataIntakeException(ioex);
		}

		return -1;
	}

	@Override
	public void close() throws IOException {
		if (this.getBufferedWriter() != null)
			this.getBufferedWriter().close();

		if (this.getOutputStream() != null)
			this.getOutputStream().close();
	}

	protected TMetadata getFlatTextMetadata() {
		return flatTextMetadata;
	}

	protected OutputStream getOutputStream() {
		return outputStream;
	}

	protected long getOriginalOffset() {
		return originalOffset;
	}

	private long getCurrentLineOffset() {
		return currentLineOffset;
	}

	private void setCurrentLineOffset(long currentLineOffset) {
		this.currentLineOffset = currentLineOffset;
	}

	protected TFormatter getFlatTextFormatter() {
		return flatTextFormatter;
	}

	protected BufferedWriter getBufferedWriter() {
		return bufferedWriter;
	}

	@Override
	public void flush() {
		try {
			this.getBufferedWriter().flush();
		}
		catch (IOException ioex) {
			// intentionally swallow this exception for now
			getLogger().debug(ioex);
		}
	}
}
