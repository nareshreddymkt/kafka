package com.optum.cdi.core.shared;

import com.optum.cdi.core.shared.abstractions.*;

public class FlatTextParserFactoryImpl implements FlatTextParserFactory {

	@Override
	public FlatTextParser getInstance(FlatTextMetadata flatTextMetadata) throws CommonDataIntakeException {
		if (flatTextMetadata instanceof FixedLengthFlatTextMetadata) {
			return new FixedLengthFlatTextParserImpl((FixedLengthFlatTextMetadata) flatTextMetadata);
		} else if (flatTextMetadata instanceof LinearFlatTextMetadata) {
			return new LinearFlatTextParserImpl((LinearFlatTextMetadata) flatTextMetadata);
		} else
			throw new CommonDataIntakeException(String.format("Unknown flat text metadata runtime type: %s", flatTextMetadata != null ? flatTextMetadata.getClass().getName() : "<null>"));
	}

}
