package com.optum.cdi.core.shared;

import com.optum.cdi.core.shared.abstractions.ProcessorRecord;

import java.util.Collections;
import java.util.Map;

public class ProcessorRecordImpl implements ProcessorRecord {
	private final Map<String, ?> originalKey;
	private final Map<String, ?> originalValue;
	private Map<String, ?> modifiedValue;

	public ProcessorRecordImpl(Map<String, ?> originalKey, Map<String, ?> originalValue) {

		if (originalKey == null)
			throw new IllegalArgumentException("originalKey");

		if (originalValue == null)
			throw new IllegalArgumentException("originalValue");

		this.originalKey = Collections.unmodifiableMap(originalKey);
		this.originalValue = Collections.unmodifiableMap(originalValue);
	}

	@Override
	public Map<String, ?> getOriginalKey() {
		return this.originalKey;
	}

	@Override
	public Map<String, ?> getOriginalValue() {
		return this.originalValue;
	}

	@Override
	public Map<String, ?> getModifiedValue() {
		return this.modifiedValue;
	}

	@Override
	public void setModifiedValue(Map<String, ?> modifiedValue) {
		this.modifiedValue = modifiedValue;
	}
}
