package com.optum.cdi.core.shared.abstractions;

public enum FIELD_TYPE {
	Unknown,
	String,
	DateTime,
	TimeSpan,
	Integer8,
	Integer16,
	Integer32,
	Integer64,
	Single,
	Double,
	Decimal
}
