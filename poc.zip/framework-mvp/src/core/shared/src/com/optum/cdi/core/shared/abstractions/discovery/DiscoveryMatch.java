package com.optum.cdi.core.shared.abstractions.discovery;

public interface DiscoveryMatch {
}
