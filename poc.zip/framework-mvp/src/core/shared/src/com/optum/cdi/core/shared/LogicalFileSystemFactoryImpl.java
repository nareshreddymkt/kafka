package com.optum.cdi.core.shared;

import com.optum.cdi.core.shared.abstractions.CommonDataIntakeException;
import com.optum.cdi.core.shared.abstractions.LogicalFileSystem;
import com.optum.cdi.core.shared.abstractions.LogicalFileSystemFactory;

public class LogicalFileSystemFactoryImpl implements LogicalFileSystemFactory {
	public LogicalFileSystemFactoryImpl() {
	}

	@Override
	public LogicalFileSystem getInstance(String logicalFileSystemTag) throws CommonDataIntakeException {

		if (logicalFileSystemTag == null)
			throw new IllegalArgumentException("logicalFileSystemTag");

		if (logicalFileSystemTag.equals(CommonValues.CDI_LOGICAL_FILE_SYSTEM_TAG_LOCAL))
			return new LocalLogicalFileSystemImpl("");
		else
			throw new CommonDataIntakeException(String.format("Unknown logical file system tag: %s", logicalFileSystemTag));
	}
}
