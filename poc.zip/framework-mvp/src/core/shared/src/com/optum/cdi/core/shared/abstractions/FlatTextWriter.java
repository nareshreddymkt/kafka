package com.optum.cdi.core.shared.abstractions;

import java.io.Closeable;
import java.util.Iterator;

public interface FlatTextWriter extends Closeable {
	long write(Iterator<FlatTextRecord> flatTextRecords);
	void flush();
}
