package com.optum.cdi.core.shared.lifecycle;

import com.optum.cdi.core.shared.FlatTextReaderFactoryImpl;
import com.optum.cdi.core.shared.abstractions.CommonDataIntakeException;
import com.optum.cdi.core.shared.abstractions.FlatTextReader;
import com.optum.cdi.core.shared.abstractions.FlatTextReaderFactory;

import java.io.IOException;
import java.io.InputStream;

public final class FlatTextSourceLifecycle extends FlatTextLifecycle {
	public FlatTextSourceLifecycle(String logicalFileSystemTag, String flatTextFormatTag, String sourceMetadataFileUri, String sourceDataFileUri, long sourceInputOffset) throws CommonDataIntakeException {
		super(logicalFileSystemTag, flatTextFormatTag, sourceMetadataFileUri, sourceDataFileUri);

		InputStream sourceInputStream; // this stream is owned by the flat text reader impl class

		sourceInputStream = this.getLogicalFileSystem().openFile(sourceDataFileUri);
		this.flatTextReader = getFlatTextReaderFactory().getInstance(this.getFlatTextMetadata(), sourceInputStream, sourceInputOffset);
	}

	private static final FlatTextReaderFactory flatTextReaderFactory = new FlatTextReaderFactoryImpl(getFlatTextParserFactory());
	private final FlatTextReader flatTextReader;

	public static FlatTextSourceLifecycle create(String logicalFileSystemTag, String flatTextFormatTag, String sourceMetadataFileUri, String sourceDataFileUri, long sourceInputOffset) {
		try {
			return new FlatTextSourceLifecycle(logicalFileSystemTag, flatTextFormatTag, sourceMetadataFileUri, sourceDataFileUri, sourceInputOffset);
		}
		catch (CommonDataIntakeException cdiex) {
			getLogger().error(cdiex);
			return null;
		}
	}

	protected static FlatTextReaderFactory getFlatTextReaderFactory() {
		return FlatTextSourceLifecycle.flatTextReaderFactory;
	}

	@Override
	public void close() throws IOException {
		try {
			if (this.getFlatTextReader() != null)
				this.getFlatTextReader().close();
		}
		finally {
			super.close();
		}
	}

	public FlatTextReader getFlatTextReader() {
		return this.flatTextReader;
	}
}
