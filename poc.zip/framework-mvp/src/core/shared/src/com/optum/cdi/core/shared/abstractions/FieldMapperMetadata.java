package com.optum.cdi.core.shared.abstractions;

import java.util.List;

public interface FieldMapperMetadata {
	List<FieldMapperFieldMetadata> getFieldMappings();
	FIELD_MAPPER_MODE getFieldMapperMode();
}
