package com.optum.cdi.core.shared.lifecycle;

import com.optum.cdi.core.shared.abstractions.CommonDataIntakeException;
import com.optum.cdi.core.shared.abstractions.FlatTextParser;

public class FlatTextProcessorLifecycle extends FlatTextLifecycle {

	public FlatTextProcessorLifecycle(String logicalFileSystemTag, String flatTextFormatTag, String processorMetadataFileUri) throws CommonDataIntakeException {
		super(logicalFileSystemTag, flatTextFormatTag, processorMetadataFileUri, EMPTY_STRING);

		this.flatTextParser = getFlatTextParserFactory().getInstance(this.getFlatTextMetadata());
	}

	private static final String EMPTY_STRING = "";
	private final FlatTextParser flatTextParser;

	public static FlatTextProcessorLifecycle create(String logicalFileSystemTag, String flatTextFormatTag, String processorMetadataFileUri) {
		try {
			return new FlatTextProcessorLifecycle(logicalFileSystemTag, flatTextFormatTag, processorMetadataFileUri);
		}
		catch (CommonDataIntakeException cdiex) {
			getLogger().error(cdiex);
			return null;
		}
	}

	public FlatTextParser getFlatTextParser() {
		return flatTextParser;
	}
}
