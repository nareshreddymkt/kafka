package com.optum.cdi.core.shared.abstractions;

public interface LinearFlatTextFormatter extends FlatTextFormatter {

}
