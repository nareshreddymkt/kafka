package com.optum.cdi.core.shared;

import com.optum.cdi.core.shared.abstractions.*;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class FixedLengthFlatTextParserImpl implements FixedLengthFlatTextParser {
	public FixedLengthFlatTextParserImpl(FixedLengthFlatTextMetadata fixedLengthFlatTextMetadata) {
		if (fixedLengthFlatTextMetadata == null)
			throw new IllegalArgumentException("fixedLengthFlatTextMetadata");

		this.fixedLengthFlatTextMetadata = fixedLengthFlatTextMetadata;
	}

	private final FixedLengthFlatTextMetadata fixedLengthFlatTextMetadata;

	@Override
	public FlatTextRecord parseLine(final String rawLogicalRecord) {
		int fieldLength;
		int fieldStartCharIndex;
		String fieldName;
		String tmpVal;
		String tmpLine = rawLogicalRecord;

		Map<String, String> untypedKey;
		Map<String, Object> typedKey;
		Map<String, String> untypedValue;
		Map<String, Object> typedValue;

		final int valuesCapacity = 200;
		final int keyCapacity = 10;
		final float valuesLoadFactor = 0.8f;
		final float keyLoadFactor = 0.9f;

		untypedKey = new HashMap<>(keyCapacity, keyLoadFactor);
		typedKey = new HashMap<>(keyCapacity, keyLoadFactor);
		untypedValue = new HashMap<>(valuesCapacity, valuesLoadFactor);
		typedValue = new HashMap<>(valuesCapacity, valuesLoadFactor);

		for (FixedLengthFlatTextFieldMetadata field : this.getFixedLengthFlatTextMetadata().getFixedLengthFields()) {
			fieldLength = field.getFieldLength();
			fieldStartCharIndex = field.getStartPosition() - 1;
			fieldName = field.getFieldName();

			if (tmpLine.length() >= (fieldLength + fieldStartCharIndex)) {
				tmpVal = tmpLine.substring(fieldStartCharIndex, (fieldStartCharIndex + fieldLength));
				untypedValue.put(fieldName, tmpVal.trim());
				typedValue.put(fieldName, asTyped(field.getFieldType(), tmpVal.trim()));
			}
		}

		return FlatTextRecordImpl.fromParsedRecord(rawLogicalRecord, untypedKey, typedKey, untypedValue, typedValue);
	}

	private Object asTyped(FIELD_TYPE fieldType, String untypedValue) {
		Object typedValue;

		switch (fieldType) {
			case Integer8:
				typedValue = Byte.valueOf(untypedValue);
				break;
			case Integer16:
				typedValue = Short.valueOf(untypedValue);
				break;
			case Integer32:
				typedValue = Integer.valueOf(untypedValue);
				break;
			case Integer64:
				typedValue = Long.valueOf(untypedValue);
				break;
			case DateTime:
				typedValue = Date.parse(untypedValue); // TODO: fix
				break;
			case String:
				typedValue = untypedValue;
				break;
			case Unknown:
				typedValue = null; // no clue
				break;
			case Decimal:
				typedValue = BigDecimal.valueOf(Double.valueOf(untypedValue)); // TODO: fix
				break;
			case Double:
				typedValue = Double.valueOf(untypedValue);
				break;
			case Single:
				typedValue = Double.valueOf(untypedValue);
				break;
			default:
				typedValue = untypedValue;
		}
		return typedValue;
	}

	private FixedLengthFlatTextMetadata getFixedLengthFlatTextMetadata() {
		return fixedLengthFlatTextMetadata;
	}
}
