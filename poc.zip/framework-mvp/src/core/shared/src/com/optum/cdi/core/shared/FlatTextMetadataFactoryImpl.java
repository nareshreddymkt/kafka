package com.optum.cdi.core.shared;

import com.optum.cdi.core.shared.abstractions.*;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.io.InputStream;

public class FlatTextMetadataFactoryImpl implements FlatTextMetadataFactory {
	@Override
	public FlatTextMetadata getInstance(String flatTextFormatTag, InputStream inputStream) throws CommonDataIntakeException {

		if (flatTextFormatTag == null)
			throw new IllegalArgumentException("flatTextFormatTag");

		if (inputStream == null)
			throw new IllegalArgumentException("inputStream");

		if (flatTextFormatTag.equals(CommonValues.CDI_FLAT_TEXT_FORMAT_TAG_FIXEDLEN)) {
			try {
				ObjectMapper mapper;

				mapper = new ObjectMapper();
				return mapper.readValue(inputStream, FixedLengthFlatTextMetadataImpl.class);
			} catch (IOException ioex) {
				throw new CommonDataIntakeException(ioex);
			}
		}
		else if (flatTextFormatTag.equals(CommonValues.CDI_FLAT_TEXT_FORMAT_TAG_LINES)) {
			return new LinearFlatTextMetadataImpl();
		} else {
			throw new CommonDataIntakeException(String.format("Unknown flat text format tag: %s", flatTextFormatTag));
		}
	}
}
