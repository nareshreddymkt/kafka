package com.optum.cdi.core.shared;

import com.optum.cdi.core.shared.abstractions.FlatTextRecord;
import com.optum.cdi.core.shared.abstractions.LinearFlatTextFormatter;
import com.optum.cdi.core.shared.abstractions.LinearFlatTextMetadata;

public class LinearFlatTextFormatterImpl implements LinearFlatTextFormatter {
	public LinearFlatTextFormatterImpl(LinearFlatTextMetadata linearFlatTextMetadata) {
		if (linearFlatTextMetadata == null)
			throw new IllegalArgumentException("linearFlatTextMetadata");

		this.linearFlatTextMetadata = linearFlatTextMetadata;
	}

	private final LinearFlatTextMetadata linearFlatTextMetadata;

	@Override
	public String format(FlatTextRecord flatTextRecord) {
		String data;

		if (flatTextRecord == null)
			return null;

		// really should only be raw records using this formatter, however, if someone passes in a topic with parsed records,
		// we can spit those out too just albeit intrinsic formatting via .toString()
		if (flatTextRecord.isRawRecord())
			data = flatTextRecord.getRawRecordValue();
		else
			data = flatTextRecord.toString();

		return data;
	}

	protected LinearFlatTextMetadata getLinearFlatTextMetadata() {
		return linearFlatTextMetadata;
	}
}
