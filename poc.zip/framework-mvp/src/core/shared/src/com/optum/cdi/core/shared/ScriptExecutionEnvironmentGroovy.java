package com.optum.cdi.core.shared;

import com.optum.cdi.core.shared.abstractions.ProcessorRecord;
import com.optum.cdi.core.shared.abstractions.ScriptExecutionEnvironment;
import groovy.lang.GroovyShell;
import groovy.lang.Binding;
import groovy.lang.Script;

public class ScriptExecutionEnvironmentGroovy implements ScriptExecutionEnvironment{
    private Script compiledScript;

    public ScriptExecutionEnvironmentGroovy(String scriptText) {
        if (scriptText == null || scriptText.isEmpty()) {
            throw new IllegalArgumentException("scriptInputStream");
        }
        //Setup shell environment and parse script,
        //which compiles on the fly to enable speed of execution
        GroovyShell shell = new GroovyShell();
        this.compiledScript = shell.parse(scriptText);
    }

    @Override
    public ProcessorRecord evaluate(ProcessorRecord record) {
        Binding binding = new Binding();
        binding.setVariable("processorRecord", record);
        compiledScript.setBinding(binding);
        compiledScript.run();
        return (ProcessorRecord)binding.getVariable("processorRecord");
    }
}
