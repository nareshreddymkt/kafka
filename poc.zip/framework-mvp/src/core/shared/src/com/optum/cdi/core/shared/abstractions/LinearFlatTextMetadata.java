package com.optum.cdi.core.shared.abstractions;

public interface LinearFlatTextMetadata extends FlatTextMetadata {
}
