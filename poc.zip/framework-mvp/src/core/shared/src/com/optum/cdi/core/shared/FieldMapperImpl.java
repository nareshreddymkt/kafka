package com.optum.cdi.core.shared;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.cdi.core.shared.abstractions.CommonDataIntakeException;
import com.optum.cdi.core.shared.abstractions.FieldMapper;
import com.optum.cdi.core.shared.abstractions.ProcessorRecord;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class FieldMapperImpl implements FieldMapper {
    private final boolean hasSourceFilter;
    private final Map<String, Object> tmpMapping;
    private Map<String, String> sourceTargetMapping;

    public FieldMapperImpl(InputStream mappingMetadataInputStream, boolean hasSourceFilter) throws CommonDataIntakeException {
         this.sourceTargetMapping = createSourceTargetMapping(mappingMetadataInputStream);
         this.hasSourceFilter = hasSourceFilter;

        this.tmpMapping = new HashMap<>(150, 0.85f);

    }

    private Map<String, String> createSourceTargetMapping(InputStream mappingMetadataInputStream) throws CommonDataIntakeException{
        sourceTargetMapping = new HashMap<>();
        ObjectMapper mapper = new ObjectMapper();
        try {
             sourceTargetMapping = mapper.readValue(mappingMetadataInputStream, Map.class);
        } catch (IOException e) {
            throw new CommonDataIntakeException("mappingMetadataInputStream");
        }
        return sourceTargetMapping;
    }

    @Override
    public boolean hasSourceFilter() {
        return hasSourceFilter;
    }

    @Override
    public ProcessorRecord applyMapping(ProcessorRecord processorRecord) {
        final Map<String, ?> origValue = processorRecord.getOriginalValue();
        String valueEntryKey;
        String targetKey;

        for (Map.Entry<String, ?> valueEntry : origValue.entrySet()) {
            valueEntryKey = valueEntry.getKey();
            if (sourceTargetMapping.containsKey(valueEntryKey))
            {
                //Value of sourceTargetMapping will be new key for tmpMapping
                targetKey = sourceTargetMapping.get(valueEntryKey);
                tmpMapping.put(targetKey, valueEntry.getValue());
            }
            else if (hasSourceFilter()) {
                continue;
            }
            else {
                tmpMapping.put(valueEntryKey, valueEntry.getValue());
            }
        }
        processorRecord.setModifiedValue(tmpMapping);
        tmpMapping.clear();

        return processorRecord;
    }

    public Map<String,String> getSourceTargetMapping() {
        return sourceTargetMapping;
    }
}
