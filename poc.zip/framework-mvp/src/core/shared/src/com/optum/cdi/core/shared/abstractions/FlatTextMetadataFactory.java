package com.optum.cdi.core.shared.abstractions;

import java.io.InputStream;

public interface FlatTextMetadataFactory {
	FlatTextMetadata getInstance(String flatTextFormatTag, InputStream inputStream) throws CommonDataIntakeException;
}
