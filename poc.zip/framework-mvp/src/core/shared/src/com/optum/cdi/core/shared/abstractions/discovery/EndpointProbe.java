package com.optum.cdi.core.shared.abstractions.discovery;

import java.util.List;

public interface EndpointProbe {
	void initialize();

	List<DiscoveryMatch> discover();

	void terminate();
}
