package com.optum.cdi.core.shared.abstractions;

import java.io.OutputStream;

public interface FlatTextWriterFactory {
	FlatTextWriter getInstance(FlatTextMetadata flatTextMetadata, OutputStream outputStream, long originalOffset) throws CommonDataIntakeException;
}
