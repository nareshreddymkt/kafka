package com.optum.cdi.core.shared.abstractions;

import java.io.InputStream;
import java.io.OutputStream;

public interface LogicalFileSystem {
	boolean getFileExists(String fileUri) throws CommonDataIntakeException;

	void deleteFile(String fileUri) throws CommonDataIntakeException;

	InputStream openFile(String fileUri) throws CommonDataIntakeException;

	OutputStream createFile(String fileUri) throws CommonDataIntakeException;
}
