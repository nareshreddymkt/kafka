package com.optum.cdi.core.shared.abstractions;

public class CommonDataIntakeException extends Exception {
	public CommonDataIntakeException() {
	}

	public CommonDataIntakeException(String message) {
		super(message);
	}

	public CommonDataIntakeException(String message, Throwable cause) {
		super(message, cause);
	}

	public CommonDataIntakeException(Throwable cause) {
		super(cause);
	}
}
