package com.optum.cdi.core.shared;

import com.optum.cdi.core.shared.abstractions.*;

import java.io.InputStream;

public class FlatTextReaderFactoryImpl implements FlatTextReaderFactory {

	public FlatTextReaderFactoryImpl(FlatTextParserFactory flatTextParserFactory) {
		if (flatTextParserFactory == null)
			throw new IllegalArgumentException("flatTextParserFactory");

		this.flatTextParserFactory = flatTextParserFactory;
	}

	private final FlatTextParserFactory flatTextParserFactory;

	@Override
	public FlatTextReader getInstance(FlatTextMetadata flatTextMetadata, InputStream inputStream, long originalOffset) throws CommonDataIntakeException {
		if (flatTextMetadata instanceof FixedLengthFlatTextMetadata) {
			return new FixedLengthFlatTextReaderImpl((FixedLengthFlatTextMetadata) flatTextMetadata, (FixedLengthFlatTextParser) getFlatTextParserFactory().getInstance(flatTextMetadata), inputStream, originalOffset);
		} else if (flatTextMetadata instanceof LinearFlatTextMetadata) {
			return new LinearFlatTextReaderImpl((LinearFlatTextMetadata) flatTextMetadata, (LinearFlatTextParserImpl) getFlatTextParserFactory().getInstance(flatTextMetadata), inputStream, originalOffset);
		} else
			throw new CommonDataIntakeException(String.format("Unknown flat text metadata runtime type: %s", flatTextMetadata != null ? flatTextMetadata.getClass().getName() : "<null>"));
	}

	protected FlatTextParserFactory getFlatTextParserFactory() {
		return flatTextParserFactory;
	}
}
