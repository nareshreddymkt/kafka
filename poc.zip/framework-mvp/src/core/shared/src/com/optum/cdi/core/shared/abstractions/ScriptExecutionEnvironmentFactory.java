package com.optum.cdi.core.shared.abstractions;

import org.codehaus.plexus.util.StringInputStream;

import java.io.InputStream;

public interface ScriptExecutionEnvironmentFactory {
    ScriptExecutionEnvironment getInstance(String scriptEngineTypeTag, InputStream scriptText) throws CommonDataIntakeException;
}



