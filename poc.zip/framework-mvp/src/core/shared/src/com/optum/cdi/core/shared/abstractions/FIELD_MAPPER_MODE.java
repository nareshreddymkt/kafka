package com.optum.cdi.core.shared.abstractions;

public enum FIELD_MAPPER_MODE {
	Blacklist, // (default) let all fields thru EXCEPT what is explicitly deleted (target == null || target == "") in field list
	Whitelist // let no fields thru EXCEPT what is explicitly not deleted (source == target [pass thru] || source != target && (target != null && target != "")) in field list
}
