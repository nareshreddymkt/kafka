package com.optum.cdi.core.shared;

import com.optum.cdi.core.shared.abstractions.CommonDataIntakeException;
import com.optum.cdi.core.shared.abstractions.LogicalFileSystem;

import java.io.*;

public class LocalLogicalFileSystemImpl implements LogicalFileSystem {
	private final String baseDirectory;

	public LocalLogicalFileSystemImpl(String baseDirectory) {

		if (baseDirectory == null)
			throw new IllegalArgumentException("baseDirectory");

		this.baseDirectory = baseDirectory; // not used yet
	}

	@Override
	public boolean getFileExists(String fileUri) throws CommonDataIntakeException {

		if (fileUri == null)
			throw new IllegalArgumentException("fileUri");

		return new File(fileUri).exists();
	}

	@Override
	public void deleteFile(String fileUri) throws CommonDataIntakeException {
		new File(fileUri).delete();
	}

	@Override
	public InputStream openFile(String fileUri) throws CommonDataIntakeException {
		try {
			if (fileUri == null)
				throw new IllegalArgumentException("fileUri");

			return new FileInputStream(fileUri);
		} catch (FileNotFoundException ex) {
			throw new CommonDataIntakeException(String.format("Encountered a file not found conidtion for file URI: %s", fileUri), ex);
		}
	}

	@Override
	public OutputStream createFile(String fileUri) throws CommonDataIntakeException {
		try {
			if (fileUri == null)
				throw new IllegalArgumentException("fileUri");

			return new FileOutputStream(fileUri);
		} catch (FileNotFoundException ex) {
			throw new CommonDataIntakeException(String.format("Encountered a file not found conidtion for file URI: %s", fileUri), ex);
		}
	}
}
