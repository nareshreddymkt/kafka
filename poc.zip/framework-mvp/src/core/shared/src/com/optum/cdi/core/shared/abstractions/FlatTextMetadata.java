package com.optum.cdi.core.shared.abstractions;

import java.util.List;

public interface FlatTextMetadata {

	boolean getHasHeaderRecord();

	boolean getHasTrailerRecord();

	String getRecordTerminator();

	List<FlatTextFieldMetadata> getFlatTextFields();

	long translateOffsetToSkipChars(long originalOffset);

	String getSourceName();
}
