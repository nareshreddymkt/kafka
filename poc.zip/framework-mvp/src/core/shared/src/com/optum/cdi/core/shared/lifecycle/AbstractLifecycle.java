package com.optum.cdi.core.shared.lifecycle;

import com.optum.cdi.core.shared.LogicalFileSystemFactoryImpl;
import com.optum.cdi.core.shared.abstractions.CommonDataIntakeException;
import com.optum.cdi.core.shared.abstractions.LogicalFileSystem;
import com.optum.cdi.core.shared.abstractions.LogicalFileSystemFactory;
import com.optum.cdi.core.shared.telemetry.BasicLifecycleTelemetry;
import org.apache.log4j.Logger;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.time.Duration;
import java.time.Instant;

public abstract class AbstractLifecycle implements Closeable, BasicLifecycleTelemetry {
	protected AbstractLifecycle(String logicalFileSystemTag, String metadataFileUri) throws CommonDataIntakeException {
		if (logicalFileSystemTag == null)
			throw new IllegalArgumentException("logicalFileSystemTag");

		if (metadataFileUri == null)
			throw new IllegalArgumentException("metadataFileUri");

		this.lifecycleCreated = Instant.now();

		this.logicalFileSystem = getLogicalFileSystemFactory().getInstance(logicalFileSystemTag);
		this.metadataInputStream = this.getLogicalFileSystem().openFile(metadataFileUri); // this stream is owned by the metadata factory impl class
	}

	private static final LogicalFileSystemFactory logicalFileSystemFactory = new LogicalFileSystemFactoryImpl();
	private static final Logger logger = Logger.getLogger(AbstractLifecycle.class);
	private final InputStream metadataInputStream; // this stream is owned by the metadata factory impl class
	private final LogicalFileSystem logicalFileSystem;
	private final Instant lifecycleCreated;
	private Instant lifecycleDisposed;
	private long totalBatchCount = 0;
	private long totalRecordCount = 0;

	protected static Logger getLogger() {
		return logger;
	}

	protected static LogicalFileSystemFactory getLogicalFileSystemFactory() {
		return logicalFileSystemFactory;
	}

	@Override
	public void close() throws IOException {

		if (this.getLifecycleDisposed() == null)
			this.setLifecycleDisposed(Instant.now());
	}

	public double calcRecordThroughput() {
		return this.calcThroughput(this.getTotalRecordCount());
	}

	public double calcBatchThroughput() {
		return this.calcThroughput(this.getTotalBatchCount());
	}

	private double calcThroughput(final long count) {
		final long time = this.getTotalLifecycleSeconds();
		double value;

		if (time <= 0L)
			return Double.NaN;

		if (count <= 0L)
			return Double.NaN;

		value = count / time;

		return value;
	}

	public long getTotalLifecycleSeconds() {
		final long INVALID = 0;
		long seconds = INVALID;

		if (this.getLifecycleCreated() != null && this.getLifecycleDisposed() != null) {
			seconds = Math.abs(Duration.between(this.getLifecycleCreated(), this.getLifecycleDisposed()).getSeconds());

			// coerce to one if X <= zero
			if (seconds <= 0)
				seconds = 1;
		}

		return seconds;
	}

	protected LogicalFileSystem getLogicalFileSystem() {
		return logicalFileSystem;
	}

	public long getTotalRecordCount() {
		return totalRecordCount;
	}

	private void setTotalRecordCount(long totalRecordCount) {
		this.totalRecordCount = totalRecordCount;
	}

	public long getTotalBatchCount() {
		return totalBatchCount;
	}

	private void setTotalBatchCount(long totalBatchCount) {
		this.totalBatchCount = totalBatchCount;
	}

	public void incrementTotalRecordCount(long value) {
		this.setTotalRecordCount(this.getTotalRecordCount() + value);
	}

	public void incrementTotalRecordCount() {
		this.incrementTotalRecordCount(1);
	}

	public void incrementTotalBatchCount() {
		this.setTotalBatchCount(this.getTotalBatchCount() + 1);
	}

	private Instant getLifecycleCreated() {
		return lifecycleCreated;
	}

	private Instant getLifecycleDisposed() {
		return lifecycleDisposed;
	}

	private void setLifecycleDisposed(Instant lifecycleDisposed) {
		this.lifecycleDisposed = lifecycleDisposed;
	}

	protected InputStream getMetadataInputStream() {
		return metadataInputStream;
	}
}
