package com.optum.cdi.core.shared.abstractions;

public interface LogicalFileSystemFactory {
	LogicalFileSystem getInstance(String logicalFileSystemTag) throws CommonDataIntakeException;
}
