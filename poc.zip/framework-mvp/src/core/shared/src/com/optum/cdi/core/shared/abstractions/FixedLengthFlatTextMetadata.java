package com.optum.cdi.core.shared.abstractions;

import java.util.List;

public interface FixedLengthFlatTextMetadata extends FlatTextMetadata {
	List<FixedLengthFlatTextFieldMetadata> getFixedLengthFields();

	int getLineLength();
}
