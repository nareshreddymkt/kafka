package com.optum.cdi.core.shared.abstractions;

import org.apache.log4j.Logger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Iterator;

public abstract class AbstractFlatTextReader<TMetadata extends FlatTextMetadata, TParser extends FlatTextParser> implements FlatTextReader {
	private static final Logger logger = Logger.getLogger(AbstractFlatTextReader.class);
	private final TMetadata flatTextMetadata;
	private final TParser flatTextParser;
	private final InputStream inputStream;
	private final BufferedReader bufferedReader;
	private final long originalOffset;
	private long currentLineOffset;
	protected AbstractFlatTextReader(TMetadata flatTextMetadata, TParser flatTextParser, InputStream inputStream, long originalOffset) {
		if (flatTextMetadata == null)
			throw new IllegalArgumentException("flatTextMetadata");

		if (flatTextParser == null)
			throw new IllegalArgumentException("flatTextParser");

		if (inputStream == null)
			throw new IllegalArgumentException("inputStream");

		if (originalOffset < 0)
			throw new IllegalArgumentException("originalOffset");

		this.flatTextMetadata = flatTextMetadata;
		this.flatTextParser = flatTextParser;
		this.inputStream = inputStream;
		this.originalOffset = originalOffset;

		this.bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

		try {
			this.setCurrentLineOffset(this.getOriginalOffset());
			final long offsetInBytes = this.getFlatTextMetadata().translateOffsetToSkipChars(this.getOriginalOffset());
			this.getBufferedReader().skip(offsetInBytes);
		}
		catch (IOException ioex) {
			this.setCurrentLineOffset(0); // HACK
		}
	}

	private static Logger getLogger() {
		return logger;
	}

	protected String getRecordTerminator() {
		return this.getFlatTextMetadata().getRecordTerminator();
	}

	@Override
	public long getCurrentOffset() {
		// NOTE: return Current(Line) NOT Original!!
		return this.getCurrentLineOffset();
	}

	@Override
	public FlatTextRecord next() {
		String rawLogicalRecord;
		FlatTextRecord flatTextRecord = null;

		try {
			if (this.getBufferedReader() == null)
				return flatTextRecord;

			// TODO: fix this and respect the getRecordTerminator()...
			rawLogicalRecord = this.getBufferedReader().readLine(); // THIS CAN BLOCK!!!

			if (rawLogicalRecord == null)
				return flatTextRecord;

			this.setCurrentLineOffset(this.getCurrentLineOffset() + 1);
			flatTextRecord = this.getFlatTextParser().parseLine(rawLogicalRecord);
		}
		catch (IOException ioex) {
			// intentionally swallow this exception for now
			getLogger().debug(ioex);
			flatTextRecord = null;
		}

		return flatTextRecord;
	}

	@Override
	public void close() throws IOException {
		if (this.getBufferedReader() != null)
			this.getBufferedReader().close();

		if (this.getInputStream() != null)
			this.getInputStream().close();
	}

	@Override
	public Iterator<FlatTextRecord> read() {
		return this;
	}

	protected TMetadata getFlatTextMetadata() {
		return flatTextMetadata;
	}

	protected InputStream getInputStream() {
		return inputStream;
	}

	protected long getOriginalOffset() {
		return originalOffset;
	}

	private long getCurrentLineOffset() {
		return currentLineOffset;
	}

	private void setCurrentLineOffset(long currentLineOffset) {
		this.currentLineOffset = currentLineOffset;
	}

	protected TParser getFlatTextParser() {
		return flatTextParser;
	}

	protected BufferedReader getBufferedReader() {
		return bufferedReader;
	}

	@Override
	public boolean hasNext() {
		try {
			return this.getBufferedReader().ready();
		}
		catch (IOException ioex) {
			// intentionally swallow this exception for now
			getLogger().debug(ioex);
			return false;
		}
	}
}
