package com.optum.cdi.core.shared;

import com.optum.cdi.core.shared.abstractions.FlatTextRecord;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class FlatTextRecordImpl implements FlatTextRecord {

	public FlatTextRecordImpl(boolean isRawRecord,
							  String rawRecordKey, String rawRecordValue,
							  Map<String, String> untypedKey,
							  Map<String, Object> typedKey,
							  Map<String, String> untypedValue,
							  Map<String, Object> typedValue) {

		if (untypedKey == null)
			throw new IllegalArgumentException("untypedKey");

		if (typedKey == null)
			throw new IllegalArgumentException("typedKey");

		if (untypedValue == null)
			throw new IllegalArgumentException("untypedValue");

		if (typedValue == null)
			throw new IllegalArgumentException("typedValue");

		this.isRawRecord = isRawRecord;
		this.rawRecordKey = rawRecordKey;
		this.rawRecordValue = rawRecordValue;

		this.untypedKey = Collections.unmodifiableMap(untypedKey);
		this.typedKey = Collections.unmodifiableMap(typedKey);
		this.untypedValue = Collections.unmodifiableMap(untypedValue);
		this.typedValue = Collections.unmodifiableMap(typedValue);
	}

	private final Map<String, String> untypedKey;
	private final Map<String, Object> typedKey;
	private final Map<String, String> untypedValue;
	private final Map<String, Object> typedValue;
	private final String rawRecordKey;
	private final String rawRecordValue;
	private final boolean isRawRecord;

	public static FlatTextRecord fromRawRecord(String rawRecordKey, String rawRecordValue) {
		final Map<String, Object> typed = new HashMap<>();
		final Map<String, String> untyped = new HashMap<>();

		if (rawRecordKey == null)
			throw new IllegalArgumentException("rawRecordKey");

		if (rawRecordValue == null)
			throw new IllegalArgumentException("rawRecordValue");

		return new FlatTextRecordImpl(true, rawRecordKey, rawRecordValue, untyped, typed, untyped, typed);
	}

	public static FlatTextRecord fromParsedRecord(String rawLogicalRecord,
												  Map<String, String> untypedKey,
												  Map<String, Object> typedKey,
												  Map<String, String> untypedValue,
												  Map<String, Object> typedValue) {
		if (untypedKey == null)
			throw new IllegalArgumentException("untypedKey");

		if (typedKey == null)
			throw new IllegalArgumentException("typedKey");

		if (untypedValue == null)
			throw new IllegalArgumentException("untypedValue");

		if (typedValue == null)
			throw new IllegalArgumentException("typedValue");

		return new FlatTextRecordImpl(false, null, rawLogicalRecord, untypedKey, typedKey, untypedValue, typedValue);
	}

	@Override
	public Map<String, String> getUntypedKey() {
		return this.untypedKey;
	}

	@Override
	public Map<String, Object> getTypedKey() {
		return this.typedKey;
	}

	@Override
	public Map<String, String> getUntypedValue() {
		return this.untypedValue;
	}

	@Override
	public Map<String, Object> getTypedValue() {
		return this.typedValue;
	}

	public String getRawRecordValue() {
		return rawRecordValue;
	}

	public String getRawRecordKey() {
		return rawRecordKey;
	}

	@Override
	public boolean isRawRecord() {
		return this.isRawRecord;
	}


	@Override
	public String toString() {
		return "{" + "KEY=" + typedKey + "; VALUE=" + typedValue + "}";
	}
}
