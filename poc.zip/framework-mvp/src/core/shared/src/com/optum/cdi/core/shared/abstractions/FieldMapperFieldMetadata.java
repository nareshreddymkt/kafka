package com.optum.cdi.core.shared.abstractions;

public interface FieldMapperFieldMetadata {
	String getSourceField();
	String getTargetField();
}
