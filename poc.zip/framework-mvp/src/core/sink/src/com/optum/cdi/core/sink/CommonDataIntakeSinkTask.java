package com.optum.cdi.core.sink;

import com.optum.cdi.core.shared.CommonValues;
import com.optum.cdi.core.shared.IteratorProjector;
import com.optum.cdi.core.shared.telemetry.BasicLifecycleTelemetry;
import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.config.ConfigException;
import org.apache.kafka.connect.errors.ConnectException;
import org.apache.kafka.connect.sink.SinkRecord;
import org.apache.kafka.connect.sink.SinkTask;
import org.apache.log4j.Logger;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Function;

public abstract class CommonDataIntakeSinkTask<TConfig extends CommonDataIntakeSinkTaskConfig> extends SinkTask {
	protected CommonDataIntakeSinkTask() {
		getLogger().info("sourceTask::.ctor()");
		this.sinkTaskStop = new AtomicBoolean(false);
	}

	private static final Logger logger = Logger.getLogger(CommonDataIntakeSinkTask.class);
	private final AtomicBoolean sinkTaskStop;
	private TConfig sinkTaskConfig;

	protected static Logger getLogger() {
		return logger;
	}

	protected static void printConsole(String format, Object... args) {
		System.out.printf(format, args);
	}

	protected abstract TConfig getSinkTaskConfigInstance(Map<?, ?> properties);

	protected abstract void onSinkTaskInitialize();

	protected abstract void onSinkTaskTerminate();

	@Override
	public final String version() {
		return CommonValues.CDI_FRAMEWORK_VERSION;
	}

	@Override
	public final void start(Map<String, String> properties) {
		if (properties == null)
			throw new IllegalArgumentException("properties");

		getLogger().info("sinkTask::start()");

		try {
			this.setSinkTaskConfig(this.getSinkTaskConfigInstance(properties));
		}
		catch (ConfigException ce) {
			throw new ConnectException("Couldn't start sink connector configuration error.", ce);
		}
		catch (Exception e) {
			throw new ConnectException("An error has occurred when starting sink connector." + e);
		}

		this.onSinkTaskInitialize();
	}

	protected abstract void onSinkBatchRecordYieldItem(long batchRecordCount, SinkRecord sinkRecord);

	@Override
	public void put(Collection<SinkRecord> sinkRecords) {
		long count;

		if (sinkRecords == null)
			throw new IllegalArgumentException("sinkRecords");

		getLogger().info("sinkTask::put()");

		final Function<Iterator<SinkRecord>, Long> sinkRecordFixator = this.aquireSinkRecordFixator();
		final BasicLifecycleTelemetry basicLifecycleTelemetry = this.aquireSinkBasicLifecycleTelemetry();
		final Iterator<SinkRecord> sinkRecordIterator = sinkRecords.iterator();

		if (this.getSinkTaskStop() != null &&
			!this.getSinkTaskStop().get() &&
			sinkRecordIterator != null && /* implied but still good to check to prevent possible NPE */
			basicLifecycleTelemetry != null &&
			this.canSinkRetainBatchRecord()) {
			count = sinkRecordFixator.apply(sinkRecordIterator);

			basicLifecycleTelemetry.incrementTotalRecordCount(count);
			basicLifecycleTelemetry.incrementTotalBatchCount();

			this.onSinkRetainComplete();

			// we are done, report some stats explicitly to console
			printConsole("Retain complete... batches: %s | records: %s | duration: %s | throughput: %s." + System.lineSeparator(),
					basicLifecycleTelemetry.getTotalBatchCount(),
					basicLifecycleTelemetry.getTotalRecordCount(),
					basicLifecycleTelemetry.getTotalLifecycleSeconds(),
					basicLifecycleTelemetry.calcRecordThroughput());
		}
	}

	protected abstract Function<Iterator<SinkRecord>, Long> aquireSinkRecordFixator();

	@Override
	public void flush(Map<TopicPartition, OffsetAndMetadata> offsets) {
		getLogger().info("sinkTask::flush()");
		this.onSinkTaskFlushOffets(offsets);
	}

	protected abstract void onSinkTaskFlushOffets(Map<TopicPartition, OffsetAndMetadata> offsets);

	protected abstract BasicLifecycleTelemetry aquireSinkBasicLifecycleTelemetry();

	protected abstract void onSinkRetainComplete();

	protected abstract boolean canSinkRetainBatchRecord();

	@Override
	public final void stop() {
		getLogger().info("sinkTask::stop()");

		synchronized (this) {
			this.onSinkTaskTerminate();
		}
	}

	protected final TConfig getSinkTaskConfig() {
		return sinkTaskConfig;
	}

	private void setSinkTaskConfig(TConfig sinkTaskConfig) {
		this.sinkTaskConfig = sinkTaskConfig;
	}

	protected final AtomicBoolean getSinkTaskStop() {
		return this.sinkTaskStop;
	}
}
