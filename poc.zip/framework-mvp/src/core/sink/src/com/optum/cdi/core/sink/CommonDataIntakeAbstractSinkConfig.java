package com.optum.cdi.core.sink;

import org.apache.kafka.common.config.AbstractConfig;
import org.apache.kafka.common.config.ConfigDef;

import java.util.Map;

public class CommonDataIntakeAbstractSinkConfig extends AbstractConfig {
	protected CommonDataIntakeAbstractSinkConfig(ConfigDef config, Map<?, ?> parsedConfig) {
		super(config, parsedConfig);
	}
}
