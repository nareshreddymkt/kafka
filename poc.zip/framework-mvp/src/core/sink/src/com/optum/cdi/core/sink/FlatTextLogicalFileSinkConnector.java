package com.optum.cdi.core.sink;

import org.apache.kafka.common.config.ConfigDef;
import org.apache.kafka.connect.connector.Task;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class FlatTextLogicalFileSinkConnector extends CommonDataIntakeSinkConnector<FlatTextLogicalFileSinkConnectorConfig> {
	public FlatTextLogicalFileSinkConnector() {
	}

	@Override
	protected FlatTextLogicalFileSinkConnectorConfig getSinkConnectorConfigInstance(Map<?, ?> properties) {
		return new FlatTextLogicalFileSinkConnectorConfig(properties);
	}

	@Override
	protected ConfigDef getSinkConnectorConfigTemplate() {
		return FlatTextLogicalFileSinkConnectorConfig.conf();
	}

	@Override
	protected Class<? extends Task> getSinkConnectorTaskClass() {
		return FlatTextLogicalFileSinkTask.class;
	}

	@Override
	protected void onSinkConnectorInitialize() {
		// do nothing
	}

	@Override
	protected void onSinkConnectorTerminate() {
		// do nothing
	}

	@Override
	protected List<Map<String, String>> getSinkTaskConfigs(int maxTasks) {
		ArrayList<Map<String, String>> configs;
		Map<String, String> config;

		configs = new ArrayList<>();

		// only one input stream makes sense right now; think "MVP" ;)
		maxTasks = 1;

		for (int i = 0; i < maxTasks; i++) {
			config = this.getSinkConnectorConfig().originalsStrings();
			configs.add(config);
		}

		return configs;
	}


}
