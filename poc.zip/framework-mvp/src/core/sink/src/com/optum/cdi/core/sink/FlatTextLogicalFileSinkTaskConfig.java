package com.optum.cdi.core.sink;

import org.apache.kafka.common.config.ConfigDef;

import java.util.List;
import java.util.Map;

import static com.optum.cdi.core.shared.CommonValues.*;

// RIGHT NOW THIS IS A COPY OF THE CONNECTOR CONFIG CLASS BECAUSE WE ARE MVP and DANIEL IS LAZY
public class FlatTextLogicalFileSinkTaskConfig extends CommonDataIntakeSinkTaskConfig {

	public FlatTextLogicalFileSinkTaskConfig(Map<?, ?> parsedConfig) {
		super(conf(), parsedConfig);
	}

	private static final ConfigDef CONFIG_DEF = new ConfigDef()
			.define(LFS_TAG_CONFIG, ConfigDef.Type.STRING, ConfigDef.Importance.HIGH, "Logical file system tag used to interpret the sink data and metadata URIs.")
			.define(FTF_TAG_CONFIG, ConfigDef.Type.STRING, ConfigDef.Importance.HIGH, "Flat text format tag used to load the metadata and determine reader/parser.")
			.define(SINK_DATA_FILE_URI_CONFIG, ConfigDef.Type.STRING, ConfigDef.Importance.HIGH, "Sink data logical file URI.")
			.define(SINK_METADATA_FILE_URI_CONFIG, ConfigDef.Type.STRING, ConfigDef.Importance.HIGH, "Sink metadata logical file URI.");

	public static ConfigDef conf() {
		return CONFIG_DEF;
	}

	protected String getSinkDataFileUri() {
		return this.getString(SINK_DATA_FILE_URI_CONFIG);
	}

	protected String getSinkMetadataFileUri() {
		return this.getString(SINK_METADATA_FILE_URI_CONFIG);
	}

	protected String getLogicalFileSystemTag() {
		return this.getString(LFS_TAG_CONFIG);
	}

	protected String getFlatTextFormatTag() {
		return this.getString(FTF_TAG_CONFIG);
	}

	protected List<String> getTopics() {
		return this.getList("topics" /* standard config key */);
	}
}
