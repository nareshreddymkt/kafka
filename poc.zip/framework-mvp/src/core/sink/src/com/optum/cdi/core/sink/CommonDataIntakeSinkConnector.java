package com.optum.cdi.core.sink;

import com.optum.cdi.core.shared.CommonValues;
import org.apache.kafka.common.config.ConfigDef;
import org.apache.kafka.common.config.ConfigException;
import org.apache.kafka.connect.connector.Task;
import org.apache.kafka.connect.errors.ConnectException;
import org.apache.kafka.connect.sink.SinkConnector;
import org.apache.log4j.Logger;

import java.util.List;
import java.util.Map;

public abstract class CommonDataIntakeSinkConnector<TConfig extends CommonDataIntakeSinkConnectorConfig> extends SinkConnector {
	protected CommonDataIntakeSinkConnector() {
		getLogger().info("sink::.ctor()");
	}

	private static final Logger logger = Logger.getLogger(CommonDataIntakeSinkConnector.class);
	private TConfig sinkConnectorConfig;

	protected static Logger getLogger() {
		return logger;
	}

	protected static void printConsole(String format, Object... args) {
		System.out.printf(format, args);
	}

	protected abstract TConfig getSinkConnectorConfigInstance(Map<?, ?> properties);

	protected abstract ConfigDef getSinkConnectorConfigTemplate();

	protected abstract Class<? extends Task> getSinkConnectorTaskClass();

	protected abstract void onSinkConnectorInitialize();

	protected abstract void onSinkConnectorTerminate();

	protected abstract List<Map<String, String>> getSinkTaskConfigs(int maxTasks);

	@Override
	public final String version() {
		return CommonValues.CDI_FRAMEWORK_VERSION;
	}

	@Override
	public final void start(Map<String, String> properties) {
		if (properties == null)
			throw new IllegalArgumentException("properties");

		getLogger().info("sink::start()");

		try {
			this.setSinkConnectorConfig(this.getSinkConnectorConfigInstance(properties));
		}
		catch (ConfigException ce) {
			throw new ConnectException("Couldn't start sink connector configuration error.", ce);
		}
		catch (Exception e) {
			throw new ConnectException("An error has occurred when starting sink connector." + e);
		}

		this.onSinkConnectorInitialize();
	}

	@Override
	public final Class<? extends Task> taskClass() {
		getLogger().info("sink::taskClass()");
		return this.getSinkConnectorTaskClass();
	}

	@Override
	public final List<Map<String, String>> taskConfigs(int maxTasks) {
		getLogger().info("sink::taskConfigs(" + Integer.toString(maxTasks) + ")");

		if (this.getSinkConnectorConfig() == null)
			throw new ConnectException("Connector config has not been initialized.");

		return this.getSinkTaskConfigs(maxTasks);
	}

	@Override
	public final void stop() {
		getLogger().info("sink::stop()");
		this.onSinkConnectorTerminate();
	}

	@Override
	public final ConfigDef config() {
		getLogger().info("sink::config()");
		return this.getSinkConnectorConfigTemplate();
	}

	protected final TConfig getSinkConnectorConfig() {
		return sinkConnectorConfig;
	}

	private void setSinkConnectorConfig(TConfig sinkConnectorConfig) {
		this.sinkConnectorConfig = sinkConnectorConfig;
	}
}
