package com.optum.cdi.core.sink;

import com.optum.cdi.core.shared.FlatTextRecordImpl;
import com.optum.cdi.core.shared.IteratorProjector;
import com.optum.cdi.core.shared.abstractions.FlatTextRecord;
import com.optum.cdi.core.shared.lifecycle.FlatTextSinkLifecycle;
import com.optum.cdi.core.shared.telemetry.BasicLifecycleTelemetry;
import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.connect.sink.SinkRecord;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.function.Function;

public class FlatTextLogicalFileSinkTask extends CommonDataIntakeSinkTask<FlatTextLogicalFileSinkTaskConfig> {
	public FlatTextLogicalFileSinkTask() {
	}

	private FlatTextSinkLifecycle flatTextSinkLifecycle;

	@Override
	protected FlatTextLogicalFileSinkTaskConfig getSinkTaskConfigInstance(Map<?, ?> properties) {
		return new FlatTextLogicalFileSinkTaskConfig(properties);
	}

	@Override
	protected void onSinkTaskInitialize() {
		final long SINK_OFFSET = 0;

		this.setFlatTextSinkLifecycle(FlatTextSinkLifecycle.create(
				this.getSinkTaskConfig().getLogicalFileSystemTag(),
				this.getSinkTaskConfig().getFlatTextFormatTag(),
				this.getSinkTaskConfig().getSinkMetadataFileUri(),
				this.getSinkTaskConfig().getSinkDataFileUri(),
				SINK_OFFSET));
	}

	@Override
	protected void onSinkTaskTerminate() {
		this.ensureLifecycleDisposed();
	}

	@Override
	protected void onSinkBatchRecordYieldItem(long batchRecordCount, SinkRecord sinkRecord) {
		// do nothing
	}

	private void ensureLifecycleDisposed() {
		synchronized (this) {
			try {
				if (this.getFlatTextSinkLifecycle() != null) {
					this.getFlatTextSinkLifecycle().close();
				}
			}
			catch (IOException ioex) {
				getLogger().warn(ioex);
			}
		}
	}

	@Override
	protected void onSinkTaskFlushOffets(Map<TopicPartition, OffsetAndMetadata> offsets) {
		this.getFlatTextSinkLifecycle().getFlatTextWriter().flush();
	}

	@Override
	protected BasicLifecycleTelemetry aquireSinkBasicLifecycleTelemetry() {
		return this.getFlatTextSinkLifecycle();
	}

	@Override
	protected void onSinkRetainComplete() {
		//this.getFlatTextSinkLifecycle().getFlatTextWriter().flush();
	}

	@Override
	protected boolean canSinkRetainBatchRecord() {
		// check for valid lifecycle and/or reader
		return this.getFlatTextSinkLifecycle() != null &&
				this.getFlatTextSinkLifecycle().getFlatTextWriter() != null;
	}

	@Override
	protected Function<Iterator<SinkRecord>, Long> aquireSinkRecordFixator() {
		if (!this.canSinkRetainBatchRecord())
			return null;

		return (itr) ->
		{
			IteratorProjector<SinkRecord, FlatTextRecord> iteratorProjector;

			if (itr == null)
				throw new IllegalArgumentException("itr");

			iteratorProjector = new IteratorProjector<SinkRecord, FlatTextRecord>(itr, (sr) -> {
				final Object key = sr.key();
				final Object value = sr.value();

				FlatTextRecord flatTextRecord = null;

				if (sr != null) {
					if (key instanceof String && value instanceof String) {
						final String rawRecordKey = (String) key;
						final String rawRecordValue = (String) value;

						flatTextRecord = FlatTextRecordImpl.fromRawRecord(rawRecordKey, rawRecordValue);
					} else if (key instanceof Map && value instanceof Map) {
						final String rawLogicalRecord = "";
						final Map<String, String> untypedKey = (Map) key;
						final Map<String, Object> typedKey = (Map) key;
						final Map<String, String> untypedValue = (Map) value;
						final Map<String, Object> typedValue = (Map) value;

						flatTextRecord = FlatTextRecordImpl.fromParsedRecord(rawLogicalRecord, untypedKey, typedKey, untypedValue, typedValue);
					}
				}

				return flatTextRecord;
			});

			return this.getFlatTextSinkLifecycle().getFlatTextWriter().write(iteratorProjector);
		};
	}

	private FlatTextSinkLifecycle getFlatTextSinkLifecycle() {
		return flatTextSinkLifecycle;
	}

	private void setFlatTextSinkLifecycle(FlatTextSinkLifecycle flatTextSinkLifecycle) {
		this.flatTextSinkLifecycle = flatTextSinkLifecycle;
	}
}
