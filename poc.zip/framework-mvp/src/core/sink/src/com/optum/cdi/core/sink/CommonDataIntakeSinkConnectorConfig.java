package com.optum.cdi.core.sink;

import org.apache.kafka.common.config.ConfigDef;

import java.util.Map;

public abstract class CommonDataIntakeSinkConnectorConfig extends CommonDataIntakeAbstractSinkConfig {
	protected CommonDataIntakeSinkConnectorConfig(ConfigDef config, Map<?, ?> parsedConfig) {
		super(config, parsedConfig);
	}
}
