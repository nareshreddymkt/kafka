package com.optum.cdi.core.sink;

import org.apache.kafka.common.config.ConfigDef;

import java.util.Map;

public abstract class CommonDataIntakeSinkTaskConfig extends CommonDataIntakeAbstractSinkConfig {
	protected CommonDataIntakeSinkTaskConfig(ConfigDef config, Map<?, ?> parsedConfig) {
		super(config, parsedConfig);
	}
}
