package com.optum.cdi.core.common.kcore;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.common.errors.SerializationException;
import org.apache.kafka.common.serialization.Deserializer;

import java.util.HashMap;
import java.util.Map;

public class MapDeserializer implements Deserializer<Map<?, ?>> {
	public MapDeserializer() {
		this(new ObjectMapper());
	}

	public MapDeserializer(ObjectMapper objectMapper) {
		if (objectMapper == null)
			throw new IllegalArgumentException("objectMapper");

		this.objectMapper = objectMapper;
	}

	private final ObjectMapper objectMapper;

	public final ObjectMapper getObjectMapper() {
		return objectMapper;
	}

	@Override
	public final void configure(Map<String, ?> config, boolean isKey) {
		// do nothing
	}

	@Override
	public final Map<?, ?> deserialize(String s, byte[] bytes) {
		if (bytes == null) {
			return null;
		} else {
			try {
				final TypeReference<HashMap<?, ?>> typeRef = new TypeReference<HashMap<?, ?>>() {
				};
				return this.getObjectMapper().readValue(bytes, typeRef);
			}
			catch (Exception ex) {
				throw new SerializationException("Error deserializing Map", ex);
			}
		}
	}

	@Override
	public final void close() {
		// do nothing
	}
}
