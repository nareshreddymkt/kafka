package com.optum.cdi.core.common.kcore;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.common.errors.SerializationException;
import org.apache.kafka.common.serialization.Serializer;

import java.util.Map;

public class MapSerializer implements Serializer<Map<?, ?>> {
	public MapSerializer() {
		this(new ObjectMapper());
	}

	public MapSerializer(ObjectMapper objectMapper) {
		if (objectMapper == null)
			throw new IllegalArgumentException("objectMapper");

		this.objectMapper = objectMapper;
	}

	private final ObjectMapper objectMapper;

	@Override
	public final void configure(Map<String, ?> config, boolean isKey) {
		// do nothing
	}

	@Override
	public final byte[] serialize(String topic, Map<?, ?> data) {
		if (data == null) {
			return null;
		} else {
			try {
				return this.getObjectMapper().writeValueAsBytes(data);
			}
			catch (Exception ex) {
				throw new SerializationException("Error serializing Map", ex);
			}
		}
	}

	@Override
	public final void close() {
		// do nothing
	}

	public final ObjectMapper getObjectMapper() {
		return objectMapper;
	}
}
