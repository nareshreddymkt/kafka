package com.optum.cdi.core.model.v20180129;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

public class OrgPopulationGroup {

	public OrgPopulationGroup() {
	}

	private String orgId;
	private Long orgSrcSysId;
	private Date orgEffDtlDt;
	private String orgPopGrpId;
	private Date effDtlDt;
	private String creatUserId;
	private Timestamp creatTmstmp;
	private String updtUserId;
	private Timestamp updtTmstmp;
	private Long audId;
	private Date cancDtlDt;
	private String orgPopGrpNm;
	private Date orgPopGrpEffStrtDt;
	private Date orgPopGrpEffEndDt;
	private Long adrTypId;
	private Integer pstAdrSurrgKey;
	private String adrLn1Txt;
	private String adrLn2Txt;
	private String adrLn3Txt;
	private String adrLn4Txt;
	private String adrLn5Txt;
	private Integer adrVldId;
	private String adrGuidVer;
	private String resDlvrInd;
	private String adrHseNbrWoFrac;
	private String adrHseNbrFrac;
	private String adrStrPrfxDir;
	private String adrStrNm;
	private String adrStrSufxAbbr;
	private String adrStrSufxDir;
	private String adrSecUnitDesg;
	private String adrSecUnitQual;
	private String adrPoBoxNbr;
	private String adrRteDesg;
	private String adrBoxNbr;
	private String adrUrbnNm;
	private String adrTnNm;
	private String adrDlvrPtCd;
	private String adrDlvrPtChkDgt;
	private String adrCarrRteCd;
	private String latDeg;
	private String lngDeg;
	private String pstCd;
	private String pstPrfxCd;
	private String pstSufxCd;
	private String pstDesc;
	private Long tmZoneId;
	private String tmZoneNm;
	private BigDecimal utcOfstTm;
	private Long isoCntryId;
	private Long isoCntrySubdivId;
	private Long fipsStId;
	private Long fipsCntyId;
	private Long stPrvcId;
	private String delInd;
	private String specialFields;

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public Long getOrgSrcSysId() {
		return orgSrcSysId;
	}

	public void setOrgSrcSysId(Long orgSrcSysId) {
		this.orgSrcSysId = orgSrcSysId;
	}

	public Date getOrgEffDtlDt() {
		return orgEffDtlDt;
	}

	public void setOrgEffDtlDt(Date orgEffDtlDt) {
		this.orgEffDtlDt = orgEffDtlDt;
	}

	public String getOrgPopGrpId() {
		return orgPopGrpId;
	}

	public void setOrgPopGrpId(String orgPopGrpId) {
		this.orgPopGrpId = orgPopGrpId;
	}

	public Date getEffDtlDt() {
		return effDtlDt;
	}

	public void setEffDtlDt(Date effDtlDt) {
		this.effDtlDt = effDtlDt;
	}

	public String getCreatUserId() {
		return creatUserId;
	}

	public void setCreatUserId(String creatUserId) {
		this.creatUserId = creatUserId;
	}

	public Timestamp getCreatTmstmp() {
		return creatTmstmp;
	}

	public void setCreatTmstmp(Timestamp creatTmstmp) {
		this.creatTmstmp = creatTmstmp;
	}

	public String getUpdtUserId() {
		return updtUserId;
	}

	public void setUpdtUserId(String updtUserId) {
		this.updtUserId = updtUserId;
	}

	public Timestamp getUpdtTmstmp() {
		return updtTmstmp;
	}

	public void setUpdtTmstmp(Timestamp updtTmstmp) {
		this.updtTmstmp = updtTmstmp;
	}

	public Long getAudId() {
		return audId;
	}

	public void setAudId(Long audId) {
		this.audId = audId;
	}

	public Date getCancDtlDt() {
		return cancDtlDt;
	}

	public void setCancDtlDt(Date cancDtlDt) {
		this.cancDtlDt = cancDtlDt;
	}

	public String getOrgPopGrpNm() {
		return orgPopGrpNm;
	}

	public void setOrgPopGrpNm(String orgPopGrpNm) {
		this.orgPopGrpNm = orgPopGrpNm;
	}

	public Date getOrgPopGrpEffStrtDt() {
		return orgPopGrpEffStrtDt;
	}

	public void setOrgPopGrpEffStrtDt(Date orgPopGrpEffStrtDt) {
		this.orgPopGrpEffStrtDt = orgPopGrpEffStrtDt;
	}

	public Date getOrgPopGrpEffEndDt() {
		return orgPopGrpEffEndDt;
	}

	public void setOrgPopGrpEffEndDt(Date orgPopGrpEffEndDt) {
		this.orgPopGrpEffEndDt = orgPopGrpEffEndDt;
	}

	public Long getAdrTypId() {
		return adrTypId;
	}

	public void setAdrTypId(Long adrTypId) {
		this.adrTypId = adrTypId;
	}

	public Integer getPstAdrSurrgKey() {
		return pstAdrSurrgKey;
	}

	public void setPstAdrSurrgKey(Integer pstAdrSurrgKey) {
		this.pstAdrSurrgKey = pstAdrSurrgKey;
	}

	public String getAdrLn1Txt() {
		return adrLn1Txt;
	}

	public void setAdrLn1Txt(String adrLn1Txt) {
		this.adrLn1Txt = adrLn1Txt;
	}

	public String getAdrLn2Txt() {
		return adrLn2Txt;
	}

	public void setAdrLn2Txt(String adrLn2Txt) {
		this.adrLn2Txt = adrLn2Txt;
	}

	public String getAdrLn3Txt() {
		return adrLn3Txt;
	}

	public void setAdrLn3Txt(String adrLn3Txt) {
		this.adrLn3Txt = adrLn3Txt;
	}

	public String getAdrLn4Txt() {
		return adrLn4Txt;
	}

	public void setAdrLn4Txt(String adrLn4Txt) {
		this.adrLn4Txt = adrLn4Txt;
	}

	public String getAdrLn5Txt() {
		return adrLn5Txt;
	}

	public void setAdrLn5Txt(String adrLn5Txt) {
		this.adrLn5Txt = adrLn5Txt;
	}

	public Integer getAdrVldId() {
		return adrVldId;
	}

	public void setAdrVldId(Integer adrVldId) {
		this.adrVldId = adrVldId;
	}

	public String getAdrGuidVer() {
		return adrGuidVer;
	}

	public void setAdrGuidVer(String adrGuidVer) {
		this.adrGuidVer = adrGuidVer;
	}

	public String getResDlvrInd() {
		return resDlvrInd;
	}

	public void setResDlvrInd(String resDlvrInd) {
		this.resDlvrInd = resDlvrInd;
	}

	public String getAdrHseNbrWoFrac() {
		return adrHseNbrWoFrac;
	}

	public void setAdrHseNbrWoFrac(String adrHseNbrWoFrac) {
		this.adrHseNbrWoFrac = adrHseNbrWoFrac;
	}

	public String getAdrHseNbrFrac() {
		return adrHseNbrFrac;
	}

	public void setAdrHseNbrFrac(String adrHseNbrFrac) {
		this.adrHseNbrFrac = adrHseNbrFrac;
	}

	public String getAdrStrPrfxDir() {
		return adrStrPrfxDir;
	}

	public void setAdrStrPrfxDir(String adrStrPrfxDir) {
		this.adrStrPrfxDir = adrStrPrfxDir;
	}

	public String getAdrStrNm() {
		return adrStrNm;
	}

	public void setAdrStrNm(String adrStrNm) {
		this.adrStrNm = adrStrNm;
	}

	public String getAdrStrSufxAbbr() {
		return adrStrSufxAbbr;
	}

	public void setAdrStrSufxAbbr(String adrStrSufxAbbr) {
		this.adrStrSufxAbbr = adrStrSufxAbbr;
	}

	public String getAdrStrSufxDir() {
		return adrStrSufxDir;
	}

	public void setAdrStrSufxDir(String adrStrSufxDir) {
		this.adrStrSufxDir = adrStrSufxDir;
	}

	public String getAdrSecUnitDesg() {
		return adrSecUnitDesg;
	}

	public void setAdrSecUnitDesg(String adrSecUnitDesg) {
		this.adrSecUnitDesg = adrSecUnitDesg;
	}

	public String getAdrSecUnitQual() {
		return adrSecUnitQual;
	}

	public void setAdrSecUnitQual(String adrSecUnitQual) {
		this.adrSecUnitQual = adrSecUnitQual;
	}

	public String getAdrPoBoxNbr() {
		return adrPoBoxNbr;
	}

	public void setAdrPoBoxNbr(String adrPoBoxNbr) {
		this.adrPoBoxNbr = adrPoBoxNbr;
	}

	public String getAdrRteDesg() {
		return adrRteDesg;
	}

	public void setAdrRteDesg(String adrRteDesg) {
		this.adrRteDesg = adrRteDesg;
	}

	public String getAdrBoxNbr() {
		return adrBoxNbr;
	}

	public void setAdrBoxNbr(String adrBoxNbr) {
		this.adrBoxNbr = adrBoxNbr;
	}

	public String getAdrUrbnNm() {
		return adrUrbnNm;
	}

	public void setAdrUrbnNm(String adrUrbnNm) {
		this.adrUrbnNm = adrUrbnNm;
	}

	public String getAdrTnNm() {
		return adrTnNm;
	}

	public void setAdrTnNm(String adrTnNm) {
		this.adrTnNm = adrTnNm;
	}

	public String getAdrDlvrPtCd() {
		return adrDlvrPtCd;
	}

	public void setAdrDlvrPtCd(String adrDlvrPtCd) {
		this.adrDlvrPtCd = adrDlvrPtCd;
	}

	public String getAdrDlvrPtChkDgt() {
		return adrDlvrPtChkDgt;
	}

	public void setAdrDlvrPtChkDgt(String adrDlvrPtChkDgt) {
		this.adrDlvrPtChkDgt = adrDlvrPtChkDgt;
	}

	public String getAdrCarrRteCd() {
		return adrCarrRteCd;
	}

	public void setAdrCarrRteCd(String adrCarrRteCd) {
		this.adrCarrRteCd = adrCarrRteCd;
	}

	public String getLatDeg() {
		return latDeg;
	}

	public void setLatDeg(String latDeg) {
		this.latDeg = latDeg;
	}

	public String getLngDeg() {
		return lngDeg;
	}

	public void setLngDeg(String lngDeg) {
		this.lngDeg = lngDeg;
	}

	public String getPstCd() {
		return pstCd;
	}

	public void setPstCd(String pstCd) {
		this.pstCd = pstCd;
	}

	public String getPstPrfxCd() {
		return pstPrfxCd;
	}

	public void setPstPrfxCd(String pstPrfxCd) {
		this.pstPrfxCd = pstPrfxCd;
	}

	public String getPstSufxCd() {
		return pstSufxCd;
	}

	public void setPstSufxCd(String pstSufxCd) {
		this.pstSufxCd = pstSufxCd;
	}

	public String getPstDesc() {
		return pstDesc;
	}

	public void setPstDesc(String pstDesc) {
		this.pstDesc = pstDesc;
	}

	public Long getTmZoneId() {
		return tmZoneId;
	}

	public void setTmZoneId(Long tmZoneId) {
		this.tmZoneId = tmZoneId;
	}

	public String getTmZoneNm() {
		return tmZoneNm;
	}

	public void setTmZoneNm(String tmZoneNm) {
		this.tmZoneNm = tmZoneNm;
	}

	public BigDecimal getUtcOfstTm() {
		return utcOfstTm;
	}

	public void setUtcOfstTm(BigDecimal utcOfstTm) {
		this.utcOfstTm = utcOfstTm;
	}

	public Long getIsoCntryId() {
		return isoCntryId;
	}

	public void setIsoCntryId(Long isoCntryId) {
		this.isoCntryId = isoCntryId;
	}

	public Long getIsoCntrySubdivId() {
		return isoCntrySubdivId;
	}

	public void setIsoCntrySubdivId(Long isoCntrySubdivId) {
		this.isoCntrySubdivId = isoCntrySubdivId;
	}

	public Long getFipsStId() {
		return fipsStId;
	}

	public void setFipsStId(Long fipsStId) {
		this.fipsStId = fipsStId;
	}

	public Long getFipsCntyId() {
		return fipsCntyId;
	}

	public void setFipsCntyId(Long fipsCntyId) {
		this.fipsCntyId = fipsCntyId;
	}

	public Long getStPrvcId() {
		return stPrvcId;
	}

	public void setStPrvcId(Long stPrvcId) {
		this.stPrvcId = stPrvcId;
	}

	public String getDelInd() {
		return delInd;
	}

	public void setDelInd(String delInd) {
		this.delInd = delInd;
	}

	public String getSpecialFields() {
		return specialFields;
	}

	public void setSpecialFields(String specialFields) {
		this.specialFields = specialFields;
	}


}