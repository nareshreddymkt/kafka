package com.optum.cdi.core.model.v20180129;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

public class ProviderLocation {

	public ProviderLocation() {
	}

	private String provId;
	private Long provSrcSysId;
	private Date provEffDtlDt;
	private Long provAdrTypId;
	private String provLocId;
	private Date effDtlDt;
	private String creatUserId;
	private Timestamp creatTmstmp;
	private String updtUserId;
	private Timestamp updtTmstmp;
	private Long audId;
	private Date cancDtlDt;
	private String locNm;
	private Date locEffDt;
	private Date locCancDt;
	private String priAdrInd;
	private Date provPracLocClmRunOutDt;
	private String cptdPayPayeNm;
	private String clmPayPayeId;
	private String clmPayPayeNm;
	private String adaAcssRqrInd;
	private Long hlthcarOrgGdrTypId;
	private Date cliaEffDt;
	private Long trtBedTypId;
	private BigDecimal trtBedCnt;
	private String adrLn1Txt;
	private String adrLn2Txt;
	private String adrLn3Txt;
	private String adrLn4Txt;
	private String adrLn5Txt;
	private Integer adrVldId;
	private String adrGuidVer;
	private String resDlvrInd;
	private String adrHseNbrWoFrac;
	private String adrHseNbrFrac;
	private String adrStrPrfxDir;
	private String adrStrNm;
	private String adrStrSufxAbbr;
	private String adrStrSufxDir;
	private String adrSecUnitDesg;
	private String adrSecUnitQual;
	private String adrPoBoxNbr;
	private String adrRteDesg;
	private String adrBoxNbr;
	private String adrUrbnNm;
	private String adrTnNm;
	private String adrDlvrPtCd;
	private String adrDlvrPtChkDgt;
	private String adrCarrRteCd;
	private String latDeg;
	private String lngDeg;
	private String pstCd;
	private String pstPrfxCd;
	private String pstSufxCd;
	private String pstDesc;
	private Long tmZoneId;
	private String tmZoneNm;
	private BigDecimal utcOfstTm;
	private Long isoCntryId;
	private Long isoCntrySubdivId;
	private Long fipsStId;
	private Long fipsCntyId;
	private Long stPrvcId;
	private Long cntcRoleId;
	private String cntcTitl;
	private Long cntcNmPrfxId;
	private String cntcFstNm;
	private String cntcMidlNm;
	private String cntcMidlInitTxt;
	private String cntcLstNm;
	private Long cntcNmSufxId;
	private Long cntcCrdntlSufxId;
	private Long cntcStsId;
	private Long cmnctTypId;
	private String elctrCmnctTxt;
	private Long isoCntryTelId;
	private String areaCd;
	private String xchgNbr;
	private String telNbr;
	private String extNbr;
	private String priTelInd;
	private Long cmnctStsId;
	private Long licTypId;
	private String licNbr;
	private Date licEffDt;
	private Date licExpirDt;
	private Date licIssDt;
	private String licBdNbr;
	private String licBdDesc;
	private Long licTrmRsnTypId;
	private Long licStsTypId;
	private String faxNbr;
	private String delInd;
	private String specialFields;

	public String getProvId() {
		return provId;
	}

	public void setProvId(String provId) {
		this.provId = provId;
	}

	public Long getProvSrcSysId() {
		return provSrcSysId;
	}

	public void setProvSrcSysId(Long provSrcSysId) {
		this.provSrcSysId = provSrcSysId;
	}

	public Date getProvEffDtlDt() {
		return provEffDtlDt;
	}

	public void setProvEffDtlDt(Date provEffDtlDt) {
		this.provEffDtlDt = provEffDtlDt;
	}

	public Long getProvAdrTypId() {
		return provAdrTypId;
	}

	public void setProvAdrTypId(Long provAdrTypId) {
		this.provAdrTypId = provAdrTypId;
	}

	public String getProvLocId() {
		return provLocId;
	}

	public void setProvLocId(String provLocId) {
		this.provLocId = provLocId;
	}

	public Date getEffDtlDt() {
		return effDtlDt;
	}

	public void setEffDtlDt(Date effDtlDt) {
		this.effDtlDt = effDtlDt;
	}

	public String getCreatUserId() {
		return creatUserId;
	}

	public void setCreatUserId(String creatUserId) {
		this.creatUserId = creatUserId;
	}

	public Timestamp getCreatTmstmp() {
		return creatTmstmp;
	}

	public void setCreatTmstmp(Timestamp creatTmstmp) {
		this.creatTmstmp = creatTmstmp;
	}

	public String getUpdtUserId() {
		return updtUserId;
	}

	public void setUpdtUserId(String updtUserId) {
		this.updtUserId = updtUserId;
	}

	public Timestamp getUpdtTmstmp() {
		return updtTmstmp;
	}

	public void setUpdtTmstmp(Timestamp updtTmstmp) {
		this.updtTmstmp = updtTmstmp;
	}

	public Long getAudId() {
		return audId;
	}

	public void setAudId(Long audId) {
		this.audId = audId;
	}

	public Date getCancDtlDt() {
		return cancDtlDt;
	}

	public void setCancDtlDt(Date cancDtlDt) {
		this.cancDtlDt = cancDtlDt;
	}

	public String getLocNm() {
		return locNm;
	}

	public void setLocNm(String locNm) {
		this.locNm = locNm;
	}

	public Date getLocEffDt() {
		return locEffDt;
	}

	public void setLocEffDt(Date locEffDt) {
		this.locEffDt = locEffDt;
	}

	public Date getLocCancDt() {
		return locCancDt;
	}

	public void setLocCancDt(Date locCancDt) {
		this.locCancDt = locCancDt;
	}

	public String getPriAdrInd() {
		return priAdrInd;
	}

	public void setPriAdrInd(String priAdrInd) {
		this.priAdrInd = priAdrInd;
	}

	public Date getProvPracLocClmRunOutDt() {
		return provPracLocClmRunOutDt;
	}

	public void setProvPracLocClmRunOutDt(Date provPracLocClmRunOutDt) {
		this.provPracLocClmRunOutDt = provPracLocClmRunOutDt;
	}

	public String getCptdPayPayeNm() {
		return cptdPayPayeNm;
	}

	public void setCptdPayPayeNm(String cptdPayPayeNm) {
		this.cptdPayPayeNm = cptdPayPayeNm;
	}

	public String getClmPayPayeId() {
		return clmPayPayeId;
	}

	public void setClmPayPayeId(String clmPayPayeId) {
		this.clmPayPayeId = clmPayPayeId;
	}

	public String getClmPayPayeNm() {
		return clmPayPayeNm;
	}

	public void setClmPayPayeNm(String clmPayPayeNm) {
		this.clmPayPayeNm = clmPayPayeNm;
	}

	public String getAdaAcssRqrInd() {
		return adaAcssRqrInd;
	}

	public void setAdaAcssRqrInd(String adaAcssRqrInd) {
		this.adaAcssRqrInd = adaAcssRqrInd;
	}

	public Long getHlthcarOrgGdrTypId() {
		return hlthcarOrgGdrTypId;
	}

	public void setHlthcarOrgGdrTypId(Long hlthcarOrgGdrTypId) {
		this.hlthcarOrgGdrTypId = hlthcarOrgGdrTypId;
	}

	public Date getCliaEffDt() {
		return cliaEffDt;
	}

	public void setCliaEffDt(Date cliaEffDt) {
		this.cliaEffDt = cliaEffDt;
	}

	public Long getTrtBedTypId() {
		return trtBedTypId;
	}

	public void setTrtBedTypId(Long trtBedTypId) {
		this.trtBedTypId = trtBedTypId;
	}

	public BigDecimal getTrtBedCnt() {
		return trtBedCnt;
	}

	public void setTrtBedCnt(BigDecimal trtBedCnt) {
		this.trtBedCnt = trtBedCnt;
	}

	public String getAdrLn1Txt() {
		return adrLn1Txt;
	}

	public void setAdrLn1Txt(String adrLn1Txt) {
		this.adrLn1Txt = adrLn1Txt;
	}

	public String getAdrLn2Txt() {
		return adrLn2Txt;
	}

	public void setAdrLn2Txt(String adrLn2Txt) {
		this.adrLn2Txt = adrLn2Txt;
	}

	public String getAdrLn3Txt() {
		return adrLn3Txt;
	}

	public void setAdrLn3Txt(String adrLn3Txt) {
		this.adrLn3Txt = adrLn3Txt;
	}

	public String getAdrLn4Txt() {
		return adrLn4Txt;
	}

	public void setAdrLn4Txt(String adrLn4Txt) {
		this.adrLn4Txt = adrLn4Txt;
	}

	public String getAdrLn5Txt() {
		return adrLn5Txt;
	}

	public void setAdrLn5Txt(String adrLn5Txt) {
		this.adrLn5Txt = adrLn5Txt;
	}

	public Integer getAdrVldId() {
		return adrVldId;
	}

	public void setAdrVldId(Integer adrVldId) {
		this.adrVldId = adrVldId;
	}

	public String getAdrGuidVer() {
		return adrGuidVer;
	}

	public void setAdrGuidVer(String adrGuidVer) {
		this.adrGuidVer = adrGuidVer;
	}

	public String getResDlvrInd() {
		return resDlvrInd;
	}

	public void setResDlvrInd(String resDlvrInd) {
		this.resDlvrInd = resDlvrInd;
	}

	public String getAdrHseNbrWoFrac() {
		return adrHseNbrWoFrac;
	}

	public void setAdrHseNbrWoFrac(String adrHseNbrWoFrac) {
		this.adrHseNbrWoFrac = adrHseNbrWoFrac;
	}

	public String getAdrHseNbrFrac() {
		return adrHseNbrFrac;
	}

	public void setAdrHseNbrFrac(String adrHseNbrFrac) {
		this.adrHseNbrFrac = adrHseNbrFrac;
	}

	public String getAdrStrPrfxDir() {
		return adrStrPrfxDir;
	}

	public void setAdrStrPrfxDir(String adrStrPrfxDir) {
		this.adrStrPrfxDir = adrStrPrfxDir;
	}

	public String getAdrStrNm() {
		return adrStrNm;
	}

	public void setAdrStrNm(String adrStrNm) {
		this.adrStrNm = adrStrNm;
	}

	public String getAdrStrSufxAbbr() {
		return adrStrSufxAbbr;
	}

	public void setAdrStrSufxAbbr(String adrStrSufxAbbr) {
		this.adrStrSufxAbbr = adrStrSufxAbbr;
	}

	public String getAdrStrSufxDir() {
		return adrStrSufxDir;
	}

	public void setAdrStrSufxDir(String adrStrSufxDir) {
		this.adrStrSufxDir = adrStrSufxDir;
	}

	public String getAdrSecUnitDesg() {
		return adrSecUnitDesg;
	}

	public void setAdrSecUnitDesg(String adrSecUnitDesg) {
		this.adrSecUnitDesg = adrSecUnitDesg;
	}

	public String getAdrSecUnitQual() {
		return adrSecUnitQual;
	}

	public void setAdrSecUnitQual(String adrSecUnitQual) {
		this.adrSecUnitQual = adrSecUnitQual;
	}

	public String getAdrPoBoxNbr() {
		return adrPoBoxNbr;
	}

	public void setAdrPoBoxNbr(String adrPoBoxNbr) {
		this.adrPoBoxNbr = adrPoBoxNbr;
	}

	public String getAdrRteDesg() {
		return adrRteDesg;
	}

	public void setAdrRteDesg(String adrRteDesg) {
		this.adrRteDesg = adrRteDesg;
	}

	public String getAdrBoxNbr() {
		return adrBoxNbr;
	}

	public void setAdrBoxNbr(String adrBoxNbr) {
		this.adrBoxNbr = adrBoxNbr;
	}

	public String getAdrUrbnNm() {
		return adrUrbnNm;
	}

	public void setAdrUrbnNm(String adrUrbnNm) {
		this.adrUrbnNm = adrUrbnNm;
	}

	public String getAdrTnNm() {
		return adrTnNm;
	}

	public void setAdrTnNm(String adrTnNm) {
		this.adrTnNm = adrTnNm;
	}

	public String getAdrDlvrPtCd() {
		return adrDlvrPtCd;
	}

	public void setAdrDlvrPtCd(String adrDlvrPtCd) {
		this.adrDlvrPtCd = adrDlvrPtCd;
	}

	public String getAdrDlvrPtChkDgt() {
		return adrDlvrPtChkDgt;
	}

	public void setAdrDlvrPtChkDgt(String adrDlvrPtChkDgt) {
		this.adrDlvrPtChkDgt = adrDlvrPtChkDgt;
	}

	public String getAdrCarrRteCd() {
		return adrCarrRteCd;
	}

	public void setAdrCarrRteCd(String adrCarrRteCd) {
		this.adrCarrRteCd = adrCarrRteCd;
	}

	public String getLatDeg() {
		return latDeg;
	}

	public void setLatDeg(String latDeg) {
		this.latDeg = latDeg;
	}

	public String getLngDeg() {
		return lngDeg;
	}

	public void setLngDeg(String lngDeg) {
		this.lngDeg = lngDeg;
	}

	public String getPstCd() {
		return pstCd;
	}

	public void setPstCd(String pstCd) {
		this.pstCd = pstCd;
	}

	public String getPstPrfxCd() {
		return pstPrfxCd;
	}

	public void setPstPrfxCd(String pstPrfxCd) {
		this.pstPrfxCd = pstPrfxCd;
	}

	public String getPstSufxCd() {
		return pstSufxCd;
	}

	public void setPstSufxCd(String pstSufxCd) {
		this.pstSufxCd = pstSufxCd;
	}

	public String getPstDesc() {
		return pstDesc;
	}

	public void setPstDesc(String pstDesc) {
		this.pstDesc = pstDesc;
	}

	public Long getTmZoneId() {
		return tmZoneId;
	}

	public void setTmZoneId(Long tmZoneId) {
		this.tmZoneId = tmZoneId;
	}

	public String getTmZoneNm() {
		return tmZoneNm;
	}

	public void setTmZoneNm(String tmZoneNm) {
		this.tmZoneNm = tmZoneNm;
	}

	public BigDecimal getUtcOfstTm() {
		return utcOfstTm;
	}

	public void setUtcOfstTm(BigDecimal utcOfstTm) {
		this.utcOfstTm = utcOfstTm;
	}

	public Long getIsoCntryId() {
		return isoCntryId;
	}

	public void setIsoCntryId(Long isoCntryId) {
		this.isoCntryId = isoCntryId;
	}

	public Long getIsoCntrySubdivId() {
		return isoCntrySubdivId;
	}

	public void setIsoCntrySubdivId(Long isoCntrySubdivId) {
		this.isoCntrySubdivId = isoCntrySubdivId;
	}

	public Long getFipsStId() {
		return fipsStId;
	}

	public void setFipsStId(Long fipsStId) {
		this.fipsStId = fipsStId;
	}

	public Long getFipsCntyId() {
		return fipsCntyId;
	}

	public void setFipsCntyId(Long fipsCntyId) {
		this.fipsCntyId = fipsCntyId;
	}

	public Long getStPrvcId() {
		return stPrvcId;
	}

	public void setStPrvcId(Long stPrvcId) {
		this.stPrvcId = stPrvcId;
	}

	public Long getCntcRoleId() {
		return cntcRoleId;
	}

	public void setCntcRoleId(Long cntcRoleId) {
		this.cntcRoleId = cntcRoleId;
	}

	public String getCntcTitl() {
		return cntcTitl;
	}

	public void setCntcTitl(String cntcTitl) {
		this.cntcTitl = cntcTitl;
	}

	public Long getCntcNmPrfxId() {
		return cntcNmPrfxId;
	}

	public void setCntcNmPrfxId(Long cntcNmPrfxId) {
		this.cntcNmPrfxId = cntcNmPrfxId;
	}

	public String getCntcFstNm() {
		return cntcFstNm;
	}

	public void setCntcFstNm(String cntcFstNm) {
		this.cntcFstNm = cntcFstNm;
	}

	public String getCntcMidlNm() {
		return cntcMidlNm;
	}

	public void setCntcMidlNm(String cntcMidlNm) {
		this.cntcMidlNm = cntcMidlNm;
	}

	public String getCntcMidlInitTxt() {
		return cntcMidlInitTxt;
	}

	public void setCntcMidlInitTxt(String cntcMidlInitTxt) {
		this.cntcMidlInitTxt = cntcMidlInitTxt;
	}

	public String getCntcLstNm() {
		return cntcLstNm;
	}

	public void setCntcLstNm(String cntcLstNm) {
		this.cntcLstNm = cntcLstNm;
	}

	public Long getCntcNmSufxId() {
		return cntcNmSufxId;
	}

	public void setCntcNmSufxId(Long cntcNmSufxId) {
		this.cntcNmSufxId = cntcNmSufxId;
	}

	public Long getCntcCrdntlSufxId() {
		return cntcCrdntlSufxId;
	}

	public void setCntcCrdntlSufxId(Long cntcCrdntlSufxId) {
		this.cntcCrdntlSufxId = cntcCrdntlSufxId;
	}

	public Long getCntcStsId() {
		return cntcStsId;
	}

	public void setCntcStsId(Long cntcStsId) {
		this.cntcStsId = cntcStsId;
	}

	public Long getCmnctTypId() {
		return cmnctTypId;
	}

	public void setCmnctTypId(Long cmnctTypId) {
		this.cmnctTypId = cmnctTypId;
	}

	public String getElctrCmnctTxt() {
		return elctrCmnctTxt;
	}

	public void setElctrCmnctTxt(String elctrCmnctTxt) {
		this.elctrCmnctTxt = elctrCmnctTxt;
	}

	public Long getIsoCntryTelId() {
		return isoCntryTelId;
	}

	public void setIsoCntryTelId(Long isoCntryTelId) {
		this.isoCntryTelId = isoCntryTelId;
	}

	public String getAreaCd() {
		return areaCd;
	}

	public void setAreaCd(String areaCd) {
		this.areaCd = areaCd;
	}

	public String getXchgNbr() {
		return xchgNbr;
	}

	public void setXchgNbr(String xchgNbr) {
		this.xchgNbr = xchgNbr;
	}

	public String getTelNbr() {
		return telNbr;
	}

	public void setTelNbr(String telNbr) {
		this.telNbr = telNbr;
	}

	public String getExtNbr() {
		return extNbr;
	}

	public void setExtNbr(String extNbr) {
		this.extNbr = extNbr;
	}

	public String getPriTelInd() {
		return priTelInd;
	}

	public void setPriTelInd(String priTelInd) {
		this.priTelInd = priTelInd;
	}

	public Long getCmnctStsId() {
		return cmnctStsId;
	}

	public void setCmnctStsId(Long cmnctStsId) {
		this.cmnctStsId = cmnctStsId;
	}

	public Long getLicTypId() {
		return licTypId;
	}

	public void setLicTypId(Long licTypId) {
		this.licTypId = licTypId;
	}

	public String getLicNbr() {
		return licNbr;
	}

	public void setLicNbr(String licNbr) {
		this.licNbr = licNbr;
	}

	public Date getLicEffDt() {
		return licEffDt;
	}

	public void setLicEffDt(Date licEffDt) {
		this.licEffDt = licEffDt;
	}

	public Date getLicExpirDt() {
		return licExpirDt;
	}

	public void setLicExpirDt(Date licExpirDt) {
		this.licExpirDt = licExpirDt;
	}

	public Date getLicIssDt() {
		return licIssDt;
	}

	public void setLicIssDt(Date licIssDt) {
		this.licIssDt = licIssDt;
	}

	public String getLicBdNbr() {
		return licBdNbr;
	}

	public void setLicBdNbr(String licBdNbr) {
		this.licBdNbr = licBdNbr;
	}

	public String getLicBdDesc() {
		return licBdDesc;
	}

	public void setLicBdDesc(String licBdDesc) {
		this.licBdDesc = licBdDesc;
	}

	public Long getLicTrmRsnTypId() {
		return licTrmRsnTypId;
	}

	public void setLicTrmRsnTypId(Long licTrmRsnTypId) {
		this.licTrmRsnTypId = licTrmRsnTypId;
	}

	public Long getLicStsTypId() {
		return licStsTypId;
	}

	public void setLicStsTypId(Long licStsTypId) {
		this.licStsTypId = licStsTypId;
	}

	public String getFaxNbr() {
		return faxNbr;
	}

	public void setFaxNbr(String faxNbr) {
		this.faxNbr = faxNbr;
	}

	public String getDelInd() {
		return delInd;
	}

	public void setDelInd(String delInd) {
		this.delInd = delInd;
	}

	public String getSpecialFields() {
		return specialFields;
	}

	public void setSpecialFields(String specialFields) {
		this.specialFields = specialFields;
	}


}