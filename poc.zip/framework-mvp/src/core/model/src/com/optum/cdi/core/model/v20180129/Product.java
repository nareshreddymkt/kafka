package com.optum.cdi.core.model.v20180129;

import java.sql.Timestamp;
import java.util.Date;

public class Product {

	public Product() {
	}

	private String prdctCd;
	private String prdctVerNbr;
	private Long srcSysId;
	private Date effDtlDt;
	private String creatUserId;
	private Timestamp creatTmstmp;
	private String updtUserId;
	private Timestamp updtTmstmp;
	private Long audId;
	private Date cancDtlDt;
	private Long prdctCatgyId;
	private Long prdctSbcatgyId;
	private Integer busSegId;
	private String busSegNm;
	private String busSegDesc;
	private Integer busEntpId;
	private String busEntpNm;
	private String busEntpCntcNm;
	private String busEntpTelNbr;
	private String busEntpFaxNbr;
	private String busEntpCntcEmail;
	private String derivFromPrdctCd;
	private String derivFromPrdctVerNbr;
	private Long derivFromPrdctSrcSysId;
	private Date derivFromPrdctEffDtlDt;
	private String prdctNm;
	private String prdctShrtNm;
	private String prdctDesc;
	private Long prdctGlId;
	private String eligEnrlGuidInd;
	private Long prdctFamId;
	private String hiosPrdctId;
	private String tierInd;
	private String delInd;
	private String specialFields;

	public String getPrdctCd() {
		return prdctCd;
	}

	public void setPrdctCd(String prdctCd) {
		this.prdctCd = prdctCd;
	}

	public String getPrdctVerNbr() {
		return prdctVerNbr;
	}

	public void setPrdctVerNbr(String prdctVerNbr) {
		this.prdctVerNbr = prdctVerNbr;
	}

	public Long getSrcSysId() {
		return srcSysId;
	}

	public void setSrcSysId(Long srcSysId) {
		this.srcSysId = srcSysId;
	}

	public Date getEffDtlDt() {
		return effDtlDt;
	}

	public void setEffDtlDt(Date effDtlDt) {
		this.effDtlDt = effDtlDt;
	}

	public String getCreatUserId() {
		return creatUserId;
	}

	public void setCreatUserId(String creatUserId) {
		this.creatUserId = creatUserId;
	}

	public Timestamp getCreatTmstmp() {
		return creatTmstmp;
	}

	public void setCreatTmstmp(Timestamp creatTmstmp) {
		this.creatTmstmp = creatTmstmp;
	}

	public String getUpdtUserId() {
		return updtUserId;
	}

	public void setUpdtUserId(String updtUserId) {
		this.updtUserId = updtUserId;
	}

	public Timestamp getUpdtTmstmp() {
		return updtTmstmp;
	}

	public void setUpdtTmstmp(Timestamp updtTmstmp) {
		this.updtTmstmp = updtTmstmp;
	}

	public Long getAudId() {
		return audId;
	}

	public void setAudId(Long audId) {
		this.audId = audId;
	}

	public Date getCancDtlDt() {
		return cancDtlDt;
	}

	public void setCancDtlDt(Date cancDtlDt) {
		this.cancDtlDt = cancDtlDt;
	}

	public Long getPrdctCatgyId() {
		return prdctCatgyId;
	}

	public void setPrdctCatgyId(Long prdctCatgyId) {
		this.prdctCatgyId = prdctCatgyId;
	}

	public Long getPrdctSbcatgyId() {
		return prdctSbcatgyId;
	}

	public void setPrdctSbcatgyId(Long prdctSbcatgyId) {
		this.prdctSbcatgyId = prdctSbcatgyId;
	}

	public Integer getBusSegId() {
		return busSegId;
	}

	public void setBusSegId(Integer busSegId) {
		this.busSegId = busSegId;
	}

	public String getBusSegNm() {
		return busSegNm;
	}

	public void setBusSegNm(String busSegNm) {
		this.busSegNm = busSegNm;
	}

	public String getBusSegDesc() {
		return busSegDesc;
	}

	public void setBusSegDesc(String busSegDesc) {
		this.busSegDesc = busSegDesc;
	}

	public Integer getBusEntpId() {
		return busEntpId;
	}

	public void setBusEntpId(Integer busEntpId) {
		this.busEntpId = busEntpId;
	}

	public String getBusEntpNm() {
		return busEntpNm;
	}

	public void setBusEntpNm(String busEntpNm) {
		this.busEntpNm = busEntpNm;
	}

	public String getBusEntpCntcNm() {
		return busEntpCntcNm;
	}

	public void setBusEntpCntcNm(String busEntpCntcNm) {
		this.busEntpCntcNm = busEntpCntcNm;
	}

	public String getBusEntpTelNbr() {
		return busEntpTelNbr;
	}

	public void setBusEntpTelNbr(String busEntpTelNbr) {
		this.busEntpTelNbr = busEntpTelNbr;
	}

	public String getBusEntpFaxNbr() {
		return busEntpFaxNbr;
	}

	public void setBusEntpFaxNbr(String busEntpFaxNbr) {
		this.busEntpFaxNbr = busEntpFaxNbr;
	}

	public String getBusEntpCntcEmail() {
		return busEntpCntcEmail;
	}

	public void setBusEntpCntcEmail(String busEntpCntcEmail) {
		this.busEntpCntcEmail = busEntpCntcEmail;
	}

	public String getDerivFromPrdctCd() {
		return derivFromPrdctCd;
	}

	public void setDerivFromPrdctCd(String derivFromPrdctCd) {
		this.derivFromPrdctCd = derivFromPrdctCd;
	}

	public String getDerivFromPrdctVerNbr() {
		return derivFromPrdctVerNbr;
	}

	public void setDerivFromPrdctVerNbr(String derivFromPrdctVerNbr) {
		this.derivFromPrdctVerNbr = derivFromPrdctVerNbr;
	}

	public Long getDerivFromPrdctSrcSysId() {
		return derivFromPrdctSrcSysId;
	}

	public void setDerivFromPrdctSrcSysId(Long derivFromPrdctSrcSysId) {
		this.derivFromPrdctSrcSysId = derivFromPrdctSrcSysId;
	}

	public Date getDerivFromPrdctEffDtlDt() {
		return derivFromPrdctEffDtlDt;
	}

	public void setDerivFromPrdctEffDtlDt(Date derivFromPrdctEffDtlDt) {
		this.derivFromPrdctEffDtlDt = derivFromPrdctEffDtlDt;
	}

	public String getPrdctNm() {
		return prdctNm;
	}

	public void setPrdctNm(String prdctNm) {
		this.prdctNm = prdctNm;
	}

	public String getPrdctShrtNm() {
		return prdctShrtNm;
	}

	public void setPrdctShrtNm(String prdctShrtNm) {
		this.prdctShrtNm = prdctShrtNm;
	}

	public String getPrdctDesc() {
		return prdctDesc;
	}

	public void setPrdctDesc(String prdctDesc) {
		this.prdctDesc = prdctDesc;
	}

	public Long getPrdctGlId() {
		return prdctGlId;
	}

	public void setPrdctGlId(Long prdctGlId) {
		this.prdctGlId = prdctGlId;
	}

	public String getEligEnrlGuidInd() {
		return eligEnrlGuidInd;
	}

	public void setEligEnrlGuidInd(String eligEnrlGuidInd) {
		this.eligEnrlGuidInd = eligEnrlGuidInd;
	}

	public Long getPrdctFamId() {
		return prdctFamId;
	}

	public void setPrdctFamId(Long prdctFamId) {
		this.prdctFamId = prdctFamId;
	}

	public String getHiosPrdctId() {
		return hiosPrdctId;
	}

	public void setHiosPrdctId(String hiosPrdctId) {
		this.hiosPrdctId = hiosPrdctId;
	}

	public String getTierInd() {
		return tierInd;
	}

	public void setTierInd(String tierInd) {
		this.tierInd = tierInd;
	}

	public String getDelInd() {
		return delInd;
	}

	public void setDelInd(String delInd) {
		this.delInd = delInd;
	}

	public String getSpecialFields() {
		return specialFields;
	}

	public void setSpecialFields(String specialFields) {
		this.specialFields = specialFields;
	}


}