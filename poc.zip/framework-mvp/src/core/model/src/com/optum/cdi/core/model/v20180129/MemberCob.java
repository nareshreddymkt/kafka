package com.optum.cdi.core.model.v20180129;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

public class MemberCob {

	public MemberCob() {
	}

	private String sbscrIndvId;
	private Long sbscrSrcSysId;
	private Date sbscrEffDtlDt;
	private String enrleeIndvId;
	private Long enrleeSrcSysId;
	private Date enrleeEffDtlDt;
	private Date mbrshpEffDt;
	private String custAcctId;
	private Long custAcctSrcSysId;
	private Date custAcctEffDtlDt;
	private String custPchsId;
	private Date custPchsEffDtlDt;
	private Date mbrshpEffDtlDt;
	private Long cobInsTypId;
	private Date cobInsEffDt;
	private String cobInsCarrNbr;
	private Long cobCovTypId;
	private Date effDtlDt;
	private String creatUserId;
	private Timestamp creatTmstmp;
	private String updtUserId;
	private Timestamp updtTmstmp;
	private Long audId;
	private Date cancDtlDt;
	private Long medcrEntlTypId;
	private Long payrRespSeqId;
	private Long cobRsnTypId;
	private String cobInsCarrNm;
	private String cobInsCarrTaxId;
	private String cobInsPolNbr;
	private String cobInsPolNm;
	private Long custdTypId;
	private String cobInsTelNbr;
	private Date cobInsVerfDt;
	private Date cobInsTrmDt;
	private String cobInsEeId;
	private String cobInsEe2Id;
	private String cobInsEe3Id;
	private String hcfaNatPlnId;
	private String cobNoteTxt;
	private Integer cobInsPstAdrSurrgKey;
	private String adrLn1Txt;
	private String adrLn2Txt;
	private String adrLn3Txt;
	private String adrLn4Txt;
	private String adrLn5Txt;
	private Integer adrVldId;
	private String adrGuidVer;
	private String resDlvrInd;
	private String adrHseNbrWoFrac;
	private String adrHseNbrFrac;
	private String adrStrPrfxDir;
	private String adrStrNm;
	private String adrStrSufxAbbr;
	private String adrStrSufxDir;
	private String adrSecUnitDesg;
	private String adrSecUnitQual;
	private String adrPoBoxNbr;
	private String adrRteDesg;
	private String adrBoxNbr;
	private String adrUrbnNm;
	private String adrTnNm;
	private String adrDlvrPtCd;
	private String adrDlvrPtChkDgt;
	private String adrCarrRteCd;
	private String latDeg;
	private String lngDeg;
	private String pstCd;
	private String pstPrfxCd;
	private String pstSufxCd;
	private String pstDesc;
	private Long tmZoneId;
	private String tmZoneNm;
	private BigDecimal utcOfstTm;
	private Long isoCntryId;
	private Long isoCntrySubdivId;
	private Long fipsStId;
	private Long fipsCntyId;
	private Long stPrvcId;
	private String delInd;
	private String specialFields;

	public String getSbscrIndvId() {
		return sbscrIndvId;
	}

	public void setSbscrIndvId(String sbscrIndvId) {
		this.sbscrIndvId = sbscrIndvId;
	}

	public Long getSbscrSrcSysId() {
		return sbscrSrcSysId;
	}

	public void setSbscrSrcSysId(Long sbscrSrcSysId) {
		this.sbscrSrcSysId = sbscrSrcSysId;
	}

	public Date getSbscrEffDtlDt() {
		return sbscrEffDtlDt;
	}

	public void setSbscrEffDtlDt(Date sbscrEffDtlDt) {
		this.sbscrEffDtlDt = sbscrEffDtlDt;
	}

	public String getEnrleeIndvId() {
		return enrleeIndvId;
	}

	public void setEnrleeIndvId(String enrleeIndvId) {
		this.enrleeIndvId = enrleeIndvId;
	}

	public Long getEnrleeSrcSysId() {
		return enrleeSrcSysId;
	}

	public void setEnrleeSrcSysId(Long enrleeSrcSysId) {
		this.enrleeSrcSysId = enrleeSrcSysId;
	}

	public Date getEnrleeEffDtlDt() {
		return enrleeEffDtlDt;
	}

	public void setEnrleeEffDtlDt(Date enrleeEffDtlDt) {
		this.enrleeEffDtlDt = enrleeEffDtlDt;
	}

	public Date getMbrshpEffDt() {
		return mbrshpEffDt;
	}

	public void setMbrshpEffDt(Date mbrshpEffDt) {
		this.mbrshpEffDt = mbrshpEffDt;
	}

	public String getCustAcctId() {
		return custAcctId;
	}

	public void setCustAcctId(String custAcctId) {
		this.custAcctId = custAcctId;
	}

	public Long getCustAcctSrcSysId() {
		return custAcctSrcSysId;
	}

	public void setCustAcctSrcSysId(Long custAcctSrcSysId) {
		this.custAcctSrcSysId = custAcctSrcSysId;
	}

	public Date getCustAcctEffDtlDt() {
		return custAcctEffDtlDt;
	}

	public void setCustAcctEffDtlDt(Date custAcctEffDtlDt) {
		this.custAcctEffDtlDt = custAcctEffDtlDt;
	}

	public String getCustPchsId() {
		return custPchsId;
	}

	public void setCustPchsId(String custPchsId) {
		this.custPchsId = custPchsId;
	}

	public Date getCustPchsEffDtlDt() {
		return custPchsEffDtlDt;
	}

	public void setCustPchsEffDtlDt(Date custPchsEffDtlDt) {
		this.custPchsEffDtlDt = custPchsEffDtlDt;
	}

	public Date getMbrshpEffDtlDt() {
		return mbrshpEffDtlDt;
	}

	public void setMbrshpEffDtlDt(Date mbrshpEffDtlDt) {
		this.mbrshpEffDtlDt = mbrshpEffDtlDt;
	}

	public Long getCobInsTypId() {
		return cobInsTypId;
	}

	public void setCobInsTypId(Long cobInsTypId) {
		this.cobInsTypId = cobInsTypId;
	}

	public Date getCobInsEffDt() {
		return cobInsEffDt;
	}

	public void setCobInsEffDt(Date cobInsEffDt) {
		this.cobInsEffDt = cobInsEffDt;
	}

	public String getCobInsCarrNbr() {
		return cobInsCarrNbr;
	}

	public void setCobInsCarrNbr(String cobInsCarrNbr) {
		this.cobInsCarrNbr = cobInsCarrNbr;
	}

	public Long getCobCovTypId() {
		return cobCovTypId;
	}

	public void setCobCovTypId(Long cobCovTypId) {
		this.cobCovTypId = cobCovTypId;
	}

	public Date getEffDtlDt() {
		return effDtlDt;
	}

	public void setEffDtlDt(Date effDtlDt) {
		this.effDtlDt = effDtlDt;
	}

	public String getCreatUserId() {
		return creatUserId;
	}

	public void setCreatUserId(String creatUserId) {
		this.creatUserId = creatUserId;
	}

	public Timestamp getCreatTmstmp() {
		return creatTmstmp;
	}

	public void setCreatTmstmp(Timestamp creatTmstmp) {
		this.creatTmstmp = creatTmstmp;
	}

	public String getUpdtUserId() {
		return updtUserId;
	}

	public void setUpdtUserId(String updtUserId) {
		this.updtUserId = updtUserId;
	}

	public Timestamp getUpdtTmstmp() {
		return updtTmstmp;
	}

	public void setUpdtTmstmp(Timestamp updtTmstmp) {
		this.updtTmstmp = updtTmstmp;
	}

	public Long getAudId() {
		return audId;
	}

	public void setAudId(Long audId) {
		this.audId = audId;
	}

	public Date getCancDtlDt() {
		return cancDtlDt;
	}

	public void setCancDtlDt(Date cancDtlDt) {
		this.cancDtlDt = cancDtlDt;
	}

	public Long getMedcrEntlTypId() {
		return medcrEntlTypId;
	}

	public void setMedcrEntlTypId(Long medcrEntlTypId) {
		this.medcrEntlTypId = medcrEntlTypId;
	}

	public Long getPayrRespSeqId() {
		return payrRespSeqId;
	}

	public void setPayrRespSeqId(Long payrRespSeqId) {
		this.payrRespSeqId = payrRespSeqId;
	}

	public Long getCobRsnTypId() {
		return cobRsnTypId;
	}

	public void setCobRsnTypId(Long cobRsnTypId) {
		this.cobRsnTypId = cobRsnTypId;
	}

	public String getCobInsCarrNm() {
		return cobInsCarrNm;
	}

	public void setCobInsCarrNm(String cobInsCarrNm) {
		this.cobInsCarrNm = cobInsCarrNm;
	}

	public String getCobInsCarrTaxId() {
		return cobInsCarrTaxId;
	}

	public void setCobInsCarrTaxId(String cobInsCarrTaxId) {
		this.cobInsCarrTaxId = cobInsCarrTaxId;
	}

	public String getCobInsPolNbr() {
		return cobInsPolNbr;
	}

	public void setCobInsPolNbr(String cobInsPolNbr) {
		this.cobInsPolNbr = cobInsPolNbr;
	}

	public String getCobInsPolNm() {
		return cobInsPolNm;
	}

	public void setCobInsPolNm(String cobInsPolNm) {
		this.cobInsPolNm = cobInsPolNm;
	}

	public Long getCustdTypId() {
		return custdTypId;
	}

	public void setCustdTypId(Long custdTypId) {
		this.custdTypId = custdTypId;
	}

	public String getCobInsTelNbr() {
		return cobInsTelNbr;
	}

	public void setCobInsTelNbr(String cobInsTelNbr) {
		this.cobInsTelNbr = cobInsTelNbr;
	}

	public Date getCobInsVerfDt() {
		return cobInsVerfDt;
	}

	public void setCobInsVerfDt(Date cobInsVerfDt) {
		this.cobInsVerfDt = cobInsVerfDt;
	}

	public Date getCobInsTrmDt() {
		return cobInsTrmDt;
	}

	public void setCobInsTrmDt(Date cobInsTrmDt) {
		this.cobInsTrmDt = cobInsTrmDt;
	}

	public String getCobInsEeId() {
		return cobInsEeId;
	}

	public void setCobInsEeId(String cobInsEeId) {
		this.cobInsEeId = cobInsEeId;
	}

	public String getCobInsEe2Id() {
		return cobInsEe2Id;
	}

	public void setCobInsEe2Id(String cobInsEe2Id) {
		this.cobInsEe2Id = cobInsEe2Id;
	}

	public String getCobInsEe3Id() {
		return cobInsEe3Id;
	}

	public void setCobInsEe3Id(String cobInsEe3Id) {
		this.cobInsEe3Id = cobInsEe3Id;
	}

	public String getHcfaNatPlnId() {
		return hcfaNatPlnId;
	}

	public void setHcfaNatPlnId(String hcfaNatPlnId) {
		this.hcfaNatPlnId = hcfaNatPlnId;
	}

	public String getCobNoteTxt() {
		return cobNoteTxt;
	}

	public void setCobNoteTxt(String cobNoteTxt) {
		this.cobNoteTxt = cobNoteTxt;
	}

	public Integer getCobInsPstAdrSurrgKey() {
		return cobInsPstAdrSurrgKey;
	}

	public void setCobInsPstAdrSurrgKey(Integer cobInsPstAdrSurrgKey) {
		this.cobInsPstAdrSurrgKey = cobInsPstAdrSurrgKey;
	}

	public String getAdrLn1Txt() {
		return adrLn1Txt;
	}

	public void setAdrLn1Txt(String adrLn1Txt) {
		this.adrLn1Txt = adrLn1Txt;
	}

	public String getAdrLn2Txt() {
		return adrLn2Txt;
	}

	public void setAdrLn2Txt(String adrLn2Txt) {
		this.adrLn2Txt = adrLn2Txt;
	}

	public String getAdrLn3Txt() {
		return adrLn3Txt;
	}

	public void setAdrLn3Txt(String adrLn3Txt) {
		this.adrLn3Txt = adrLn3Txt;
	}

	public String getAdrLn4Txt() {
		return adrLn4Txt;
	}

	public void setAdrLn4Txt(String adrLn4Txt) {
		this.adrLn4Txt = adrLn4Txt;
	}

	public String getAdrLn5Txt() {
		return adrLn5Txt;
	}

	public void setAdrLn5Txt(String adrLn5Txt) {
		this.adrLn5Txt = adrLn5Txt;
	}

	public Integer getAdrVldId() {
		return adrVldId;
	}

	public void setAdrVldId(Integer adrVldId) {
		this.adrVldId = adrVldId;
	}

	public String getAdrGuidVer() {
		return adrGuidVer;
	}

	public void setAdrGuidVer(String adrGuidVer) {
		this.adrGuidVer = adrGuidVer;
	}

	public String getResDlvrInd() {
		return resDlvrInd;
	}

	public void setResDlvrInd(String resDlvrInd) {
		this.resDlvrInd = resDlvrInd;
	}

	public String getAdrHseNbrWoFrac() {
		return adrHseNbrWoFrac;
	}

	public void setAdrHseNbrWoFrac(String adrHseNbrWoFrac) {
		this.adrHseNbrWoFrac = adrHseNbrWoFrac;
	}

	public String getAdrHseNbrFrac() {
		return adrHseNbrFrac;
	}

	public void setAdrHseNbrFrac(String adrHseNbrFrac) {
		this.adrHseNbrFrac = adrHseNbrFrac;
	}

	public String getAdrStrPrfxDir() {
		return adrStrPrfxDir;
	}

	public void setAdrStrPrfxDir(String adrStrPrfxDir) {
		this.adrStrPrfxDir = adrStrPrfxDir;
	}

	public String getAdrStrNm() {
		return adrStrNm;
	}

	public void setAdrStrNm(String adrStrNm) {
		this.adrStrNm = adrStrNm;
	}

	public String getAdrStrSufxAbbr() {
		return adrStrSufxAbbr;
	}

	public void setAdrStrSufxAbbr(String adrStrSufxAbbr) {
		this.adrStrSufxAbbr = adrStrSufxAbbr;
	}

	public String getAdrStrSufxDir() {
		return adrStrSufxDir;
	}

	public void setAdrStrSufxDir(String adrStrSufxDir) {
		this.adrStrSufxDir = adrStrSufxDir;
	}

	public String getAdrSecUnitDesg() {
		return adrSecUnitDesg;
	}

	public void setAdrSecUnitDesg(String adrSecUnitDesg) {
		this.adrSecUnitDesg = adrSecUnitDesg;
	}

	public String getAdrSecUnitQual() {
		return adrSecUnitQual;
	}

	public void setAdrSecUnitQual(String adrSecUnitQual) {
		this.adrSecUnitQual = adrSecUnitQual;
	}

	public String getAdrPoBoxNbr() {
		return adrPoBoxNbr;
	}

	public void setAdrPoBoxNbr(String adrPoBoxNbr) {
		this.adrPoBoxNbr = adrPoBoxNbr;
	}

	public String getAdrRteDesg() {
		return adrRteDesg;
	}

	public void setAdrRteDesg(String adrRteDesg) {
		this.adrRteDesg = adrRteDesg;
	}

	public String getAdrBoxNbr() {
		return adrBoxNbr;
	}

	public void setAdrBoxNbr(String adrBoxNbr) {
		this.adrBoxNbr = adrBoxNbr;
	}

	public String getAdrUrbnNm() {
		return adrUrbnNm;
	}

	public void setAdrUrbnNm(String adrUrbnNm) {
		this.adrUrbnNm = adrUrbnNm;
	}

	public String getAdrTnNm() {
		return adrTnNm;
	}

	public void setAdrTnNm(String adrTnNm) {
		this.adrTnNm = adrTnNm;
	}

	public String getAdrDlvrPtCd() {
		return adrDlvrPtCd;
	}

	public void setAdrDlvrPtCd(String adrDlvrPtCd) {
		this.adrDlvrPtCd = adrDlvrPtCd;
	}

	public String getAdrDlvrPtChkDgt() {
		return adrDlvrPtChkDgt;
	}

	public void setAdrDlvrPtChkDgt(String adrDlvrPtChkDgt) {
		this.adrDlvrPtChkDgt = adrDlvrPtChkDgt;
	}

	public String getAdrCarrRteCd() {
		return adrCarrRteCd;
	}

	public void setAdrCarrRteCd(String adrCarrRteCd) {
		this.adrCarrRteCd = adrCarrRteCd;
	}

	public String getLatDeg() {
		return latDeg;
	}

	public void setLatDeg(String latDeg) {
		this.latDeg = latDeg;
	}

	public String getLngDeg() {
		return lngDeg;
	}

	public void setLngDeg(String lngDeg) {
		this.lngDeg = lngDeg;
	}

	public String getPstCd() {
		return pstCd;
	}

	public void setPstCd(String pstCd) {
		this.pstCd = pstCd;
	}

	public String getPstPrfxCd() {
		return pstPrfxCd;
	}

	public void setPstPrfxCd(String pstPrfxCd) {
		this.pstPrfxCd = pstPrfxCd;
	}

	public String getPstSufxCd() {
		return pstSufxCd;
	}

	public void setPstSufxCd(String pstSufxCd) {
		this.pstSufxCd = pstSufxCd;
	}

	public String getPstDesc() {
		return pstDesc;
	}

	public void setPstDesc(String pstDesc) {
		this.pstDesc = pstDesc;
	}

	public Long getTmZoneId() {
		return tmZoneId;
	}

	public void setTmZoneId(Long tmZoneId) {
		this.tmZoneId = tmZoneId;
	}

	public String getTmZoneNm() {
		return tmZoneNm;
	}

	public void setTmZoneNm(String tmZoneNm) {
		this.tmZoneNm = tmZoneNm;
	}

	public BigDecimal getUtcOfstTm() {
		return utcOfstTm;
	}

	public void setUtcOfstTm(BigDecimal utcOfstTm) {
		this.utcOfstTm = utcOfstTm;
	}

	public Long getIsoCntryId() {
		return isoCntryId;
	}

	public void setIsoCntryId(Long isoCntryId) {
		this.isoCntryId = isoCntryId;
	}

	public Long getIsoCntrySubdivId() {
		return isoCntrySubdivId;
	}

	public void setIsoCntrySubdivId(Long isoCntrySubdivId) {
		this.isoCntrySubdivId = isoCntrySubdivId;
	}

	public Long getFipsStId() {
		return fipsStId;
	}

	public void setFipsStId(Long fipsStId) {
		this.fipsStId = fipsStId;
	}

	public Long getFipsCntyId() {
		return fipsCntyId;
	}

	public void setFipsCntyId(Long fipsCntyId) {
		this.fipsCntyId = fipsCntyId;
	}

	public Long getStPrvcId() {
		return stPrvcId;
	}

	public void setStPrvcId(Long stPrvcId) {
		this.stPrvcId = stPrvcId;
	}

	public String getDelInd() {
		return delInd;
	}

	public void setDelInd(String delInd) {
		this.delInd = delInd;
	}

	public String getSpecialFields() {
		return specialFields;
	}

	public void setSpecialFields(String specialFields) {
		this.specialFields = specialFields;
	}


}