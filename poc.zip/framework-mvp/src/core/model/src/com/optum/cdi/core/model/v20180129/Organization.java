package com.optum.cdi.core.model.v20180129;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

public class Organization {

	public Organization() {
	}

	private String orgId;
	private Long srcSysId;
	private Date effDtlDt;
	private String creatUserId;
	private Timestamp creatTmstmp;
	private String updtUserId;
	private Timestamp updtTmstmp;
	private Long audId;
	private Date cancDtlDt;
	private String parOrgId;
	private Long parSrcSysId;
	private Date parEffDtlDt;
	private String orgNm;
	private Date orgCreatDt;
	private Date orgTrmDt;
	private Long orgTypId;
	private Long orgFranchId;
	private Long busSegId;
	private String busSegNm;
	private Long mktSegId;
	private String mktSegVal;
	private String mktSegDesc;
	private BigDecimal mktSegMinSzCnt;
	private BigDecimal mktSegMaxSzCnt;
	private String erisaInd;
	private String govtOperInd;
	private String pubPvtInd;
	private String smlBusInd;
	private Long nonErisaCatgyTypId;
	private Long rlgnXmptStsId;
	private Long mlrWrtAsurcId;
	private Long mnrtyTypId;
	private Long atpDesgTypId;
	private String atpOrgNm;
	private String stkSymVal;
	private BigDecimal annlRvnuAmt;
	private String wmnOwnInd;
	private String adjCmtyRtInd;
	private Long onshrRstrcTypId;
	private Long rptYrId;
	private Long eeCntMethId;
	private BigDecimal rptYrVal;
	private Integer eeCnt;
	private Long cmnctTypId;
	private Long cntcRoleId;
	private Long isoCntryTelId;
	private String areaCd;
	private String xchgNbr;
	private String telNbr;
	private String extNbr;
	private String priTelInd;
	private String tin;
	private Long taxIdTypId;
	private String delInd;
	private String specialFields;

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public Long getSrcSysId() {
		return srcSysId;
	}

	public void setSrcSysId(Long srcSysId) {
		this.srcSysId = srcSysId;
	}

	public Date getEffDtlDt() {
		return effDtlDt;
	}

	public void setEffDtlDt(Date effDtlDt) {
		this.effDtlDt = effDtlDt;
	}

	public String getCreatUserId() {
		return creatUserId;
	}

	public void setCreatUserId(String creatUserId) {
		this.creatUserId = creatUserId;
	}

	public Timestamp getCreatTmstmp() {
		return creatTmstmp;
	}

	public void setCreatTmstmp(Timestamp creatTmstmp) {
		this.creatTmstmp = creatTmstmp;
	}

	public String getUpdtUserId() {
		return updtUserId;
	}

	public void setUpdtUserId(String updtUserId) {
		this.updtUserId = updtUserId;
	}

	public Timestamp getUpdtTmstmp() {
		return updtTmstmp;
	}

	public void setUpdtTmstmp(Timestamp updtTmstmp) {
		this.updtTmstmp = updtTmstmp;
	}

	public Long getAudId() {
		return audId;
	}

	public void setAudId(Long audId) {
		this.audId = audId;
	}

	public Date getCancDtlDt() {
		return cancDtlDt;
	}

	public void setCancDtlDt(Date cancDtlDt) {
		this.cancDtlDt = cancDtlDt;
	}

	public String getParOrgId() {
		return parOrgId;
	}

	public void setParOrgId(String parOrgId) {
		this.parOrgId = parOrgId;
	}

	public Long getParSrcSysId() {
		return parSrcSysId;
	}

	public void setParSrcSysId(Long parSrcSysId) {
		this.parSrcSysId = parSrcSysId;
	}

	public Date getParEffDtlDt() {
		return parEffDtlDt;
	}

	public void setParEffDtlDt(Date parEffDtlDt) {
		this.parEffDtlDt = parEffDtlDt;
	}

	public String getOrgNm() {
		return orgNm;
	}

	public void setOrgNm(String orgNm) {
		this.orgNm = orgNm;
	}

	public Date getOrgCreatDt() {
		return orgCreatDt;
	}

	public void setOrgCreatDt(Date orgCreatDt) {
		this.orgCreatDt = orgCreatDt;
	}

	public Date getOrgTrmDt() {
		return orgTrmDt;
	}

	public void setOrgTrmDt(Date orgTrmDt) {
		this.orgTrmDt = orgTrmDt;
	}

	public Long getOrgTypId() {
		return orgTypId;
	}

	public void setOrgTypId(Long orgTypId) {
		this.orgTypId = orgTypId;
	}

	public Long getOrgFranchId() {
		return orgFranchId;
	}

	public void setOrgFranchId(Long orgFranchId) {
		this.orgFranchId = orgFranchId;
	}

	public Long getBusSegId() {
		return busSegId;
	}

	public void setBusSegId(Long busSegId) {
		this.busSegId = busSegId;
	}

	public String getBusSegNm() {
		return busSegNm;
	}

	public void setBusSegNm(String busSegNm) {
		this.busSegNm = busSegNm;
	}

	public Long getMktSegId() {
		return mktSegId;
	}

	public void setMktSegId(Long mktSegId) {
		this.mktSegId = mktSegId;
	}

	public String getMktSegVal() {
		return mktSegVal;
	}

	public void setMktSegVal(String mktSegVal) {
		this.mktSegVal = mktSegVal;
	}

	public String getMktSegDesc() {
		return mktSegDesc;
	}

	public void setMktSegDesc(String mktSegDesc) {
		this.mktSegDesc = mktSegDesc;
	}

	public BigDecimal getMktSegMinSzCnt() {
		return mktSegMinSzCnt;
	}

	public void setMktSegMinSzCnt(BigDecimal mktSegMinSzCnt) {
		this.mktSegMinSzCnt = mktSegMinSzCnt;
	}

	public BigDecimal getMktSegMaxSzCnt() {
		return mktSegMaxSzCnt;
	}

	public void setMktSegMaxSzCnt(BigDecimal mktSegMaxSzCnt) {
		this.mktSegMaxSzCnt = mktSegMaxSzCnt;
	}

	public String getErisaInd() {
		return erisaInd;
	}

	public void setErisaInd(String erisaInd) {
		this.erisaInd = erisaInd;
	}

	public String getGovtOperInd() {
		return govtOperInd;
	}

	public void setGovtOperInd(String govtOperInd) {
		this.govtOperInd = govtOperInd;
	}

	public String getPubPvtInd() {
		return pubPvtInd;
	}

	public void setPubPvtInd(String pubPvtInd) {
		this.pubPvtInd = pubPvtInd;
	}

	public String getSmlBusInd() {
		return smlBusInd;
	}

	public void setSmlBusInd(String smlBusInd) {
		this.smlBusInd = smlBusInd;
	}

	public Long getNonErisaCatgyTypId() {
		return nonErisaCatgyTypId;
	}

	public void setNonErisaCatgyTypId(Long nonErisaCatgyTypId) {
		this.nonErisaCatgyTypId = nonErisaCatgyTypId;
	}

	public Long getRlgnXmptStsId() {
		return rlgnXmptStsId;
	}

	public void setRlgnXmptStsId(Long rlgnXmptStsId) {
		this.rlgnXmptStsId = rlgnXmptStsId;
	}

	public Long getMlrWrtAsurcId() {
		return mlrWrtAsurcId;
	}

	public void setMlrWrtAsurcId(Long mlrWrtAsurcId) {
		this.mlrWrtAsurcId = mlrWrtAsurcId;
	}

	public Long getMnrtyTypId() {
		return mnrtyTypId;
	}

	public void setMnrtyTypId(Long mnrtyTypId) {
		this.mnrtyTypId = mnrtyTypId;
	}

	public Long getAtpDesgTypId() {
		return atpDesgTypId;
	}

	public void setAtpDesgTypId(Long atpDesgTypId) {
		this.atpDesgTypId = atpDesgTypId;
	}

	public String getAtpOrgNm() {
		return atpOrgNm;
	}

	public void setAtpOrgNm(String atpOrgNm) {
		this.atpOrgNm = atpOrgNm;
	}

	public String getStkSymVal() {
		return stkSymVal;
	}

	public void setStkSymVal(String stkSymVal) {
		this.stkSymVal = stkSymVal;
	}

	public BigDecimal getAnnlRvnuAmt() {
		return annlRvnuAmt;
	}

	public void setAnnlRvnuAmt(BigDecimal annlRvnuAmt) {
		this.annlRvnuAmt = annlRvnuAmt;
	}

	public String getWmnOwnInd() {
		return wmnOwnInd;
	}

	public void setWmnOwnInd(String wmnOwnInd) {
		this.wmnOwnInd = wmnOwnInd;
	}

	public String getAdjCmtyRtInd() {
		return adjCmtyRtInd;
	}

	public void setAdjCmtyRtInd(String adjCmtyRtInd) {
		this.adjCmtyRtInd = adjCmtyRtInd;
	}

	public Long getOnshrRstrcTypId() {
		return onshrRstrcTypId;
	}

	public void setOnshrRstrcTypId(Long onshrRstrcTypId) {
		this.onshrRstrcTypId = onshrRstrcTypId;
	}

	public Long getRptYrId() {
		return rptYrId;
	}

	public void setRptYrId(Long rptYrId) {
		this.rptYrId = rptYrId;
	}

	public Long getEeCntMethId() {
		return eeCntMethId;
	}

	public void setEeCntMethId(Long eeCntMethId) {
		this.eeCntMethId = eeCntMethId;
	}

	public BigDecimal getRptYrVal() {
		return rptYrVal;
	}

	public void setRptYrVal(BigDecimal rptYrVal) {
		this.rptYrVal = rptYrVal;
	}

	public Integer getEeCnt() {
		return eeCnt;
	}

	public void setEeCnt(Integer eeCnt) {
		this.eeCnt = eeCnt;
	}

	public Long getCmnctTypId() {
		return cmnctTypId;
	}

	public void setCmnctTypId(Long cmnctTypId) {
		this.cmnctTypId = cmnctTypId;
	}

	public Long getCntcRoleId() {
		return cntcRoleId;
	}

	public void setCntcRoleId(Long cntcRoleId) {
		this.cntcRoleId = cntcRoleId;
	}

	public Long getIsoCntryTelId() {
		return isoCntryTelId;
	}

	public void setIsoCntryTelId(Long isoCntryTelId) {
		this.isoCntryTelId = isoCntryTelId;
	}

	public String getAreaCd() {
		return areaCd;
	}

	public void setAreaCd(String areaCd) {
		this.areaCd = areaCd;
	}

	public String getXchgNbr() {
		return xchgNbr;
	}

	public void setXchgNbr(String xchgNbr) {
		this.xchgNbr = xchgNbr;
	}

	public String getTelNbr() {
		return telNbr;
	}

	public void setTelNbr(String telNbr) {
		this.telNbr = telNbr;
	}

	public String getExtNbr() {
		return extNbr;
	}

	public void setExtNbr(String extNbr) {
		this.extNbr = extNbr;
	}

	public String getPriTelInd() {
		return priTelInd;
	}

	public void setPriTelInd(String priTelInd) {
		this.priTelInd = priTelInd;
	}

	public String getTin() {
		return tin;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}

	public Long getTaxIdTypId() {
		return taxIdTypId;
	}

	public void setTaxIdTypId(Long taxIdTypId) {
		this.taxIdTypId = taxIdTypId;
	}

	public String getDelInd() {
		return delInd;
	}

	public void setDelInd(String delInd) {
		this.delInd = delInd;
	}

	public String getSpecialFields() {
		return specialFields;
	}

	public void setSpecialFields(String specialFields) {
		this.specialFields = specialFields;
	}


}