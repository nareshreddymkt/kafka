package com.optum.cdi.core.model.v20180129;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

public class ClaimTransaction {

	public ClaimTransaction() {
	}

	private String clmId;
	private Integer clmVerNbr;
	private Long srcSysId;
	private String creatUserId;
	private Timestamp creatTmstmp;
	private String updtUserId;
	private Timestamp updtTmstmp;
	private Long audId;
	private String srcClmVerNbr;
	private String srcClmVerAdjNbr;
	private String origClmId;
	private String sbscrIndvId;
	private Long sbscrSrcSysId;
	private Date sbscrEffDtlDt;
	private String ptntIndvId;
	private Long ptntSrcSysId;
	private Date ptntEffDtlDt;
	private String rndrProvId;
	private Long rndrProvSrcSysId;
	private Date rndrProvEffDtlDt;
	private Integer rndrNpiVal;
	private Long rndrProvTypId;
	private Long rndrProvClssTypId;
	private Long rndrProvSpclTypId;
	private String bilProvId;
	private Long bilProvSrcSysId;
	private Date bilProvEffDtlDt;
	private Integer bilNpiVal;
	private Long bilProvTypId;
	private Long bilProvClssTypId;
	private Long bilProvSpclTypId;
	private String refProvId;
	private Long refProvSrcSysId;
	private Date refProvEffDtlDt;
	private Integer refNpiVal;
	private Long refProvTypId;
	private Long refProvClssTypId;
	private Long refProvSpclTypId;
	private String faclProvId;
	private Long faclProvSrcSysId;
	private Date faclProvEffDtlDt;
	private Integer faclNpiVal;
	private Long faclProvTypId;
	private Long faclProvClssTypId;
	private Long faclProvSpclTypId;
	private String atdProvId;
	private Long atdProvSrcSysId;
	private Date atdProvEffDtlDt;
	private Integer atdNpiVal;
	private Long atdProvTypId;
	private Long atdProvClssTypId;
	private Long atdProvSpclTypId;
	private String operProvId;
	private Long operProvSrcSysId;
	private Date operProvEffDtlDt;
	private Integer operNpiVal;
	private Long operProvTypId;
	private Long operProvClssTypId;
	private Long operProvSpclTypId;
	private String srvcLocProvId;
	private Long srvcLocProvSrcSysId;
	private Date srvcLocProvEffDtlDt;
	private Long srvcLocProvAdrTypId;
	private String srvcLocProvLocId;
	private Date srvcLocProvPracLocEffDtlDt;
	private Date strtSrvcDt;
	private Date endSrvcDt;
	private Date clmRecptDt;
	private Date clmAdjdDt;
	private Timestamp admisDttm;
	private Timestamp dschrgDttm;
	private Date accDt;
	private Date initTrtDt;
	private Date lstSeenDt;
	private Date sympDt;
	private Date mnfstDt;
	private Date dsblStrtDt;
	private Date dsblEndDt;
	private Date stmtBegnDt;
	private Date stmtEndDt;
	private Date lstWrkDt;
	private Date authRtnWrkDt;
	private Timestamp clmSbmtDttm;
	private Date prscDt;
	private Date rlnqCareDt;
	private Date clmPdDt;
	private String ptntSgnSrcInd;
	private String hspcPtntInd;
	private String provSgnInd;
	private String clmEnctrInd;
	private String cobSpctInd;
	private Long clmTransStsId;
	private Timestamp clmTransStsEffDttm;
	private Long clmTypId;
	private Long clmTransProcStsId;
	private Long admisSrcId;
	private Long ptntStsId;
	private Long prcMethTypId;
	private Long clmFreqTypId;
	private Long clmTransTypId;
	private Long benLvlCausId;
	private Long admisTypId;
	private Long spclPgmId;
	private Long dschrgStsId;
	private Long ptntSgnSrcId;
	private Long plnPrtcpId;
	private Long clmDnlRsnId;
	private Long dlayRsnId;
	private Long plsrvId;
	private Long rlseOfInfoId;
	private Long adjdCobLvlId;
	private String oonClmBilProvInd;
	private String oonClmRndrProvInd;
	private String medcrAsgnInd;
	private String benAsgnInd;
	private String medRecNbr;
	private String ptntAcctNbr;
	private String chkNbr;
	private Long clmBilTypId;
	private String clmBilTypCd;
	private Long clmSbmtMethId;
	private Long clmFlId;
	private Long relCaus1Id;
	private Long relCaus2Id;
	private Long relCausCntryId;
	private Long relCausStId;
	private Long admitDiagId;
	private Long admitDiagLvlTypId;
	private Integer admitDiagPrrSeqNbr;
	private String admitDiagPrsOnAdmisInd;
	private String diag1TypCd;
	private Long diag1Id;
	private String diag1Cd;
	private Long diag1LvlTypId;
	private String diag1LvlTypCd;
	private Integer diag1PrrSeqNbr;
	private String diag1PrsOnAdmisInd;
	private String diag2TypCd;
	private Long diag2Id;
	private String diag2Cd;
	private Long diag2LvlTypId;
	private String diag2LvlTypCd;
	private Integer diag2PrrSeqNbr;
	private String diag2PrsOnAdmisInd;
	private String diag3TypCd;
	private Long diag3Id;
	private String diag3Cd;
	private Long diag3LvlTypId;
	private String diag3LvlTypCd;
	private Integer diag3PrrSeqNbr;
	private String diag3PrsOnAdmisInd;
	private String diag4TypCd;
	private Long diag4Id;
	private String diag4Cd;
	private Long diag4LvlTypId;
	private String diag4LvlTypCd;
	private Integer diag4PrrSeqNbr;
	private String diag4PrsOnAdmisInd;
	private String diag5TypCd;
	private Long diag5Id;
	private String diag5Cd;
	private Long diag5LvlTypId;
	private String diag5LvlTypCd;
	private Integer diag5PrrSeqNbr;
	private String diag5PrsOnAdmisInd;
	private String diag6TypCd;
	private Long diag6Id;
	private String diag6Cd;
	private Long diag6LvlTypId;
	private String diag6LvlTypCd;
	private Integer diag6PrrSeqNbr;
	private String diag6PrsOnAdmisInd;
	private String diag7TypCd;
	private Long diag7Id;
	private String diag7Cd;
	private Long diag7LvlTypId;
	private String diag7LvlTypCd;
	private Integer diag7PrrSeqNbr;
	private String diag7PrsOnAdmisInd;
	private String diag8TypCd;
	private Long diag8Id;
	private String diag8Cd;
	private Long diag8LvlTypId;
	private String diag8LvlTypCd;
	private Integer diag8PrrSeqNbr;
	private String diag8PrsOnAdmisInd;
	private String diag9TypCd;
	private Long diag9Id;
	private String diag9Cd;
	private Long diag9LvlTypId;
	private String diag9LvlTypCd;
	private String diag9PrrSeqNbr;
	private String diag9PrsOnAdmisInd;
	private String diag10TypCd;
	private Long diag10Id;
	private String diag10Cd;
	private Long diag10LvlTypId;
	private String diag10LvlTypCd;
	private Integer diag10PrrSeqNbr;
	private String diag10PrsOnAdmisInd;
	private String diag11TypCd;
	private Long diag11Id;
	private String diag11Cd;
	private Long diag11LvlTypId;
	private String diag11LvlTypCd;
	private Integer diag11PrrSeqNbr;
	private String diag11PrsOnAdmisInd;
	private String diag12TypCd;
	private Long diag12Id;
	private String diag12Cd;
	private Long diag12LvlTypId;
	private String diag12LvlTypCd;
	private Integer diag12PrrSeqNbr;
	private String diag12PrsOnAdmisInd;
	private String diag13TypCd;
	private Long diag13Id;
	private String diag13Cd;
	private Long diag13LvlTypId;
	private String diag13LvlTypCd;
	private Integer diag13PrrSeqNbr;
	private String diag13PrsOnAdmisInd;
	private String diag14TypCd;
	private Long diag14Id;
	private String diag14Cd;
	private Long diag14LvlTypId;
	private String diag14LvlTypCd;
	private Integer diag14PrrSeqNbr;
	private String diag14PrsOnAdmisInd;
	private String diag15TypCd;
	private Long diag15Id;
	private String diag15Cd;
	private Long diag15LvlTypId;
	private String diag15LvlTypCd;
	private Integer diag15PrrSeqNbr;
	private String diag15PrsOnAdmisInd;
	private String diag16TypCd;
	private Long diag16Id;
	private String diag16Cd;
	private Long diag16LvlTypId;
	private String diag16LvlTypCd;
	private Integer diag16PrrSeqNbr;
	private String diag16PrsOnAdmisInd;
	private String diag17TypCd;
	private Long diag17Id;
	private String diag17Cd;
	private Long diag17LvlTypId;
	private String diag17LvlTypCd;
	private Integer diag17PrrSeqNbr;
	private String diag17PrsOnAdmisInd;
	private String diag18TypCd;
	private Long diag18Id;
	private String diag18Cd;
	private Long diag18LvlTypId;
	private String diag18LvlTypCd;
	private Integer diag18PrrSeqNbr;
	private String diag18PrsOnAdmisInd;
	private String diag19TypCd;
	private Long diag19Id;
	private String diag19Cd;
	private Long diag19LvlTypId;
	private String diag19LvlTypCd;
	private Integer diag19PrrSeqNbr;
	private String diag19PrsOnAdmisInd;
	private String diag20TypCd;
	private Long diag20Id;
	private String diag20Cd;
	private Long diag20LvlTypId;
	private String diag20LvlTypCd;
	private Integer diag20PrrSeqNbr;
	private String diag20PrsOnAdmisInd;
	private String diag21TypCd;
	private Long diag21Id;
	private String diag21Cd;
	private Long diag21LvlTypId;
	private String diag21LvlTypCd;
	private Integer diag21PrrSeqNbr;
	private String diag21PrsOnAdmisInd;
	private String diag22TypCd;
	private Long diag22Id;
	private String diag22Cd;
	private Long diag22LvlTypId;
	private String diag22LvlTypCd;
	private Integer diag22PrrSeqNbr;
	private String diag22PrsOnAdmisInd;
	private String diag23TypCd;
	private Long diag23Id;
	private String diag23Cd;
	private Long diag23LvlTypId;
	private String diag23LvlTypCd;
	private Integer diag23PrrSeqNbr;
	private String diag23PrsOnAdmisInd;
	private String diag24TypCd;
	private Long diag24Id;
	private String diag24Cd;
	private Long diag24LvlTypId;
	private String diag24LvlTypCd;
	private Integer diag24PrrSeqNbr;
	private String diag24PrsOnAdmisInd;
	private String diag25TypCd;
	private Long diag25Id;
	private String diag25Cd;
	private Long diag25LvlTypId;
	private String diag25LvlTypCd;
	private Integer diag25PrrSeqNbr;
	private String diag25PrsOnAdmisInd;
	private String diag26TypCd;
	private Long diag26Id;
	private String diag26Cd;
	private Long diag26LvlTypId;
	private String diag26LvlTypCd;
	private Integer diag26PrrSeqNbr;
	private String diag26PrsOnAdmisInd;
	private String diag27TypCd;
	private Long diag27Id;
	private String diag27Cd;
	private Long diag27LvlTypId;
	private String diag27LvlTypCd;
	private Integer diag27PrrSeqNbr;
	private String diag27PrsOnAdmisInd;
	private String diag28TypCd;
	private Long diag28Id;
	private String diag28Cd;
	private Long diag28LvlTypId;
	private String diag28LvlTypCd;
	private Integer diag28PrrSeqNbr;
	private String diag28PrsOnAdmisInd;
	private String diag29TypCd;
	private Long diag29Id;
	private String diag29Cd;
	private Long diag29LvlTypId;
	private String diag29LvlTypCd;
	private Integer diag29PrrSeqNbr;
	private String diag29PrsOnAdmisInd;
	private String diag30TypCd;
	private Long diag30Id;
	private String diag30Cd;
	private Long diag30LvlTypId;
	private String diag30LvlTypCd;
	private Integer diag30PrrSeqNbr;
	private String diag30PrsOnAdmisInd;
	private String diag31TypCd;
	private Long diag31Id;
	private String diag31Cd;
	private Long diag31LvlTypId;
	private String diag31LvlTypCd;
	private Integer diag31PrrSeqNbr;
	private String diag31PrsOnAdmisInd;
	private String diag32TypCd;
	private Long diag32Id;
	private String diag32Cd;
	private Long diag32LvlTypId;
	private String diag32LvlTypCd;
	private Integer diag32PrrSeqNbr;
	private String diag32PrsOnAdmisInd;
	private String diag33TypCd;
	private Long diag33Id;
	private String diag33Cd;
	private Long diag33LvlTypId;
	private String diag33LvlTypCd;
	private Integer diag33PrrSeqNbr;
	private String diag33PrsOnAdmisInd;
	private String diag34TypCd;
	private Long diag34Id;
	private String diag34Cd;
	private Long diag34LvlTypId;
	private String diag34LvlTypCd;
	private Integer diag34PrrSeqNbr;
	private String diag34PrsOnAdmisInd;
	private String diag35TypCd;
	private Long diag35Id;
	private String diag35Cd;
	private Long diag35LvlTypId;
	private String diag35LvlTypCd;
	private Integer diag35PrrSeqNbr;
	private String diag35PrsOnAdmisInd;
	private String diag36TypCd;
	private Long diag36Id;
	private String diag36Cd;
	private Long diag36LvlTypId;
	private String diag36LvlTypCd;
	private Integer diag36PrrSeqNbr;
	private String diag36PrsOnAdmisInd;
	private String diag37TypCd;
	private Long diag37Id;
	private String diag37Cd;
	private Long diag37LvlTypId;
	private String diag37LvlTypCd;
	private Integer diag37PrrSeqNbr;
	private String diag37PrsOnAdmisInd;
	private String diag38TypCd;
	private Long diag38Id;
	private String diag38Cd;
	private Long diag38LvlTypId;
	private String diag38LvlTypCd;
	private Integer diag38PrrSeqNbr;
	private String diag38PrsOnAdmisInd;
	private String diag39TypCd;
	private Long diag39Id;
	private String diag39Cd;
	private Long diag39LvlTypId;
	private String diag39LvlTypCd;
	private Integer diag39PrrSeqNbr;
	private String diag39PrsOnAdmisInd;
	private String diag40TypCd;
	private Long diag40Id;
	private String diag40Cd;
	private Long diag40LvlTypId;
	private String diag40LvlTypCd;
	private Integer diag40PrrSeqNbr;
	private String diag40PrsOnAdmisInd;
	private String diag41TypCd;
	private Long diag41Id;
	private String diag41Cd;
	private Long diag41LvlTypId;
	private String diag41LvlTypCd;
	private Integer diag41PrrSeqNbr;
	private String diag41PrsOnAdmisInd;
	private String diag42TypCd;
	private Long diag42Id;
	private String diag42Cd;
	private Long diag42LvlTypId;
	private String diag42LvlTypCd;
	private Integer diag42PrrSeqNbr;
	private String diag42PrsOnAdmisInd;
	private String diag43TypCd;
	private Long diag43Id;
	private String diag43Cd;
	private Long diag43LvlTypId;
	private String diag43LvlTypCd;
	private Integer diag43PrrSeqNbr;
	private String diag43PrsOnAdmisInd;
	private String diag44TypCd;
	private Long diag44Id;
	private String diag44Cd;
	private Long diag44LvlTypId;
	private String diag44LvlTypCd;
	private Integer diag44PrrSeqNbr;
	private String diag44PrsOnAdmisInd;
	private String diag45TypCd;
	private Long diag45Id;
	private String diag45Cd;
	private Long diag45LvlTypId;
	private String diag45LvlTypCd;
	private Integer diag45PrrSeqNbr;
	private String diag45PrsOnAdmisInd;
	private String diag46TypCd;
	private Long diag46Id;
	private String diag46Cd;
	private Long diag46LvlTypId;
	private String diag46LvlTypCd;
	private Integer diag46PrrSeqNbr;
	private String diag46PrsOnAdmisInd;
	private String diag47TypCd;
	private Long diag47Id;
	private String diag47Cd;
	private Long diag47LvlTypId;
	private String diag47LvlTypCd;
	private Integer diag47PrrSeqNbr;
	private String diag47PrsOnAdmisInd;
	private String diag48TypCd;
	private Long diag48Id;
	private String diag48Cd;
	private Long diag48LvlTypId;
	private String diag48LvlTypCd;
	private Integer diag48PrrSeqNbr;
	private String diag48PrsOnAdmisInd;
	private String diag49TypCd;
	private Long diag49Id;
	private String diag49Cd;
	private Long diag49LvlTypId;
	private String diag49LvlTypCd;
	private Integer diag49PrrSeqNbr;
	private String diag49PrsOnAdmisInd;
	private String diag50TypCd;
	private Long diag50Id;
	private String diag50Cd;
	private Long diag50LvlTypId;
	private String diag50LvlTypCd;
	private Integer diag50PrrSeqNbr;
	private String diag50PrsOnAdmisInd;
	private Long icdProc1Id;
	private String icdProc1VerCd;
	private String icdProc1Cd;
	private Date icdProc1Dt;
	private String prinProc1Ind;
	private Long icdProc2Id;
	private String icdProc2VerCd;
	private String icdProc2Cd;
	private Date icdProc2Dt;
	private String prinProc2Ind;
	private Long icdProc3Id;
	private String icdProc3VerCd;
	private String icdProc3Cd;
	private Date icdProc3Dt;
	private String prinProc3Ind;
	private Long icdProc4Id;
	private String icdProc4VerCd;
	private String icdProc4Cd;
	private Date icdProc4Dt;
	private String prinProc4Ind;
	private Long icdProc5Id;
	private String icdProc5VerCd;
	private String icdProc5Cd;
	private Date icdProc5Dt;
	private String prinProc5Ind;
	private Long icdProc6Id;
	private String icdProc6VerCd;
	private String icdProc6Cd;
	private Date icdProc6Dt;
	private String prinProc6Ind;
	private Long icdProc7Id;
	private String icdProc7VerCd;
	private String icdProc7Cd;
	private Date icdProc7Dt;
	private String prinProc7Ind;
	private Long icdProc8Id;
	private String icdProc8VerCd;
	private String icdProc8Cd;
	private Date icdProc8Dt;
	private String prinProc8Ind;
	private Long icdProc9Id;
	private String icdProc9VerCd;
	private String icdProc9Cd;
	private Date icdProc9Dt;
	private String prinProc9Ind;
	private Long icdProc10Id;
	private String icdProc10VerCd;
	private String icdProc10Cd;
	private Date icdProc10Dt;
	private String prinProc10Ind;
	private Long icdProc11Id;
	private String icdProc11VerCd;
	private String icdProc11Cd;
	private Date icdProc11Dt;
	private String prinProc11Ind;
	private Long icdProc12Id;
	private String icdProc12VerCd;
	private String icdProc12Cd;
	private Date icdProc12Dt;
	private String prinProc12Ind;
	private Long icdProc13Id;
	private String icdProc13VerCd;
	private String icdProc13Cd;
	private Date icdProc13Dt;
	private String prinProc13Ind;
	private Long icdProc14Id;
	private String icdProc14VerCd;
	private String icdProc14Cd;
	private Date icdProc14Dt;
	private String prinProc14Ind;
	private Long icdProc15Id;
	private String icdProc15VerCd;
	private String icdProc15Cd;
	private Date icdProc15Dt;
	private String prinProc15Ind;
	private Long icdProc16Id;
	private String icdProc16VerCd;
	private String icdProc16Cd;
	private Date icdProc16Dt;
	private String prinProc16Ind;
	private Long icdProc17Id;
	private String icdProc17VerCd;
	private String icdProc17Cd;
	private Date icdProc17Dt;
	private String prinProc17Ind;
	private Long icdProc18Id;
	private String icdProc18VerCd;
	private String icdProc18Cd;
	private Date icdProc18Dt;
	private String prinProc18Ind;
	private Long icdProc19Id;
	private String icdProc19VerCd;
	private String icdProc19Cd;
	private Date icdProc19Dt;
	private String prinProc19Ind;
	private Long icdProc20Id;
	private String icdProc20VerCd;
	private String icdProc20Cd;
	private Date icdProc20Dt;
	private String prinProc20Ind;
	private Long icdProc21Id;
	private String icdProc21VerCd;
	private String icdProc21Cd;
	private Date icdProc21Dt;
	private String prinProc21Ind;
	private Long icdProc22Id;
	private String icdProc22VerCd;
	private String icdProc22Cd;
	private Date icdProc22Dt;
	private String prinProc22Ind;
	private Long icdProc23Id;
	private String icdProc23VerCd;
	private String icdProc23Cd;
	private Date icdProc23Dt;
	private String prinProc23Ind;
	private Long icdProc24Id;
	private String icdProc24VerCd;
	private String icdProc24Cd;
	private Date icdProc24Dt;
	private String prinProc24Ind;
	private Long icdProc25Id;
	private String icdProc25VerCd;
	private String icdProc25Cd;
	private Date icdProc25Dt;
	private String prinProc25Ind;
	private Long icdProc26Id;
	private String icdProc26VerCd;
	private String icdProc26Cd;
	private Date icdProc26Dt;
	private String prinProc26Ind;
	private Long icdProc27Id;
	private String icdProc27VerCd;
	private String icdProc27Cd;
	private Date icdProc27Dt;
	private String prinProc27Ind;
	private Long icdProc28Id;
	private String icdProc28VerCd;
	private String icdProc28Cd;
	private Date icdProc28Dt;
	private String prinProc28Ind;
	private Long icdProc29Id;
	private String icdProc29VerCd;
	private String icdProc29Cd;
	private Date icdProc29Dt;
	private String prinProc29Ind;
	private Long icdProc30Id;
	private String icdProc30VerCd;
	private String icdProc30Cd;
	private Date icdProc30Dt;
	private String prinProc30Ind;
	private Long bilDrgTypId;
	private Long bilDrgId;
	private String bilDrgCd;
	private Long bilDrgVerId;
	private BigDecimal bilDrgRelWgtVal;
	private BigDecimal bilDrgGmlosVal;
	private BigDecimal bilDrgAlosVal;
	private Long pdDrgTypId;
	private Long pdDrgId;
	private String pdDrgCd;
	private Long pdDrgVerId;
	private BigDecimal pdDrgRelWgtVal;
	private BigDecimal pdDrgGmlosVal;
	private BigDecimal pdDrgAlosVal;
	private BigDecimal clmDrgAmt;
	private Long cond1Id;
	private String cond1Cd;
	private Long cond2Id;
	private String cond2Cd;
	private Long cond3Id;
	private String cond3Cd;
	private Long cond4Id;
	private String cond4Cd;
	private Long cond5Id;
	private String cond5Cd;
	private Long cond6Id;
	private String cond6Cd;
	private Long cond7Id;
	private String cond7Cd;
	private Long cond8Id;
	private String cond8Cd;
	private Long cond9Id;
	private String cond9Cd;
	private Long cond10Id;
	private String cond10Cd;
	private Long cond11Id;
	private String cond11Cd;
	private Long cond12Id;
	private String cond12Cd;
	private Long cond13Id;
	private String cond13Cd;
	private Long cond14Id;
	private String cond14Cd;
	private Long cond15Id;
	private String cond15Cd;
	private Long cond16Id;
	private String cond16Cd;
	private Long cond17Id;
	private String cond17Cd;
	private Long cond18Id;
	private String cond18Cd;
	private Long cond19Id;
	private String cond19Cd;
	private Long cond20Id;
	private String cond20Cd;
	private BigDecimal totBilChrgAmt;
	private BigDecimal totCopayAmt;
	private BigDecimal totSurchrgTaxAmt;
	private BigDecimal totPrrPayAmt;
	private BigDecimal totClmAllwAmt;
	private BigDecimal totOtsdLabChrgAmt;
	private BigDecimal totBenCoinsAmt;
	private BigDecimal totPtntPdAmt;
	private BigDecimal totBalDueAmt;
	private BigDecimal totCrDrCrdAmt;
	private BigDecimal totContrAmt;
	private BigDecimal totCobSvAmt;
	private BigDecimal totRprcSvAmt;
	private BigDecimal totEndStgRnlDsesAmt;
	private BigDecimal totClmPdAmt;
	private BigDecimal totPtntRespAmt;
	private BigDecimal totNonPayProfCmpntAmt;
	private BigDecimal totNcAmt;
	private BigDecimal totDedAmt;
	private BigDecimal totCovAmt;
	private BigDecimal totIntAmt;
	private BigDecimal totDscntAmt;
	private BigDecimal totEstDueAmt;
	private BigDecimal totOiPdAmt;
	private BigDecimal totMedcrPdAmt;
	private BigDecimal totMedcrCoinsAmt;
	private BigDecimal totMedcrDedAmt;
	private BigDecimal totCovIptntDayCnt;
	private BigDecimal totNonCovIptntDayCnt;
	private Long bcbsItsId;
	private String bcbsItsCd;
	private String bcbsItsSccfNbr;
	private Long clmAdjdPltfmId;
	private Timestamp clmAdjDttm;
	private Long clmPayeAsgnId;
	private String clrhseTracNbr;
	private String clinLabAmnd1Nbr;
	private String clinLabAmnd2Nbr;
	private String clinLabAmnd3Nbr;
	private String eeClmInd;
	private Date estBthDt;
	private Date lstMnstrlDt;
	private Date lstXrayDt;
	private String mmgrCertNbr;
	private Long srvcAuthXcptId;
	private Date simIllDt;
	private Long surchrgTaxId;
	private String pcpRespInd;
	private String surgThruErInd;
	private Long clmStsCatgy1Id;
	private String clmStsCatgy1Cd;
	private Long clmSts1Id;
	private String clmSts1Cd;
	private Long clmStsCatgy2Id;
	private String clmStsCatgy2Cd;
	private Long clmSts2Id;
	private String clmSts2Cd;
	private Long clmStsCatgy3Id;
	private String clmStsCatgy3Cd;
	private Long clmSts3Id;
	private String clmSts3Cd;
	private Long clmStsCatgy4Id;
	private String clmStsCatgy4Cd;
	private Long clmSts4Id;
	private String clmSts4Cd;
	private Long clmStsCatgy5Id;
	private String clmStsCatgy5Cd;
	private Long clmSts5Id;
	private String clmSts5Cd;
	private Long clmStsCatgy6Id;
	private String clmStsCatgy6Cd;
	private Long clmSts6Id;
	private String clmSts6Cd;
	private Long clmStsCatgy7Id;
	private String clmStsCatgy7Cd;
	private Long clmSts7Id;
	private String clmSts7Cd;
	private Long clmStsCatgy8Id;
	private String clmStsCatgy8Cd;
	private Long clmSts8Id;
	private String clmSts8Cd;
	private Long authTypId;
	private String refInd;
	private String authNbr;
	private String actvInd;
	private String delInd;
	private String specialFields;

	public String getClmId() {
		return clmId;
	}

	public void setClmId(String clmId) {
		this.clmId = clmId;
	}

	public Integer getClmVerNbr() {
		return clmVerNbr;
	}

	public void setClmVerNbr(Integer clmVerNbr) {
		this.clmVerNbr = clmVerNbr;
	}

	public Long getSrcSysId() {
		return srcSysId;
	}

	public void setSrcSysId(Long srcSysId) {
		this.srcSysId = srcSysId;
	}

	public String getCreatUserId() {
		return creatUserId;
	}

	public void setCreatUserId(String creatUserId) {
		this.creatUserId = creatUserId;
	}

	public Timestamp getCreatTmstmp() {
		return creatTmstmp;
	}

	public void setCreatTmstmp(Timestamp creatTmstmp) {
		this.creatTmstmp = creatTmstmp;
	}

	public String getUpdtUserId() {
		return updtUserId;
	}

	public void setUpdtUserId(String updtUserId) {
		this.updtUserId = updtUserId;
	}

	public Timestamp getUpdtTmstmp() {
		return updtTmstmp;
	}

	public void setUpdtTmstmp(Timestamp updtTmstmp) {
		this.updtTmstmp = updtTmstmp;
	}

	public Long getAudId() {
		return audId;
	}

	public void setAudId(Long audId) {
		this.audId = audId;
	}

	public String getSrcClmVerNbr() {
		return srcClmVerNbr;
	}

	public void setSrcClmVerNbr(String srcClmVerNbr) {
		this.srcClmVerNbr = srcClmVerNbr;
	}

	public String getSrcClmVerAdjNbr() {
		return srcClmVerAdjNbr;
	}

	public void setSrcClmVerAdjNbr(String srcClmVerAdjNbr) {
		this.srcClmVerAdjNbr = srcClmVerAdjNbr;
	}

	public String getOrigClmId() {
		return origClmId;
	}

	public void setOrigClmId(String origClmId) {
		this.origClmId = origClmId;
	}

	public String getSbscrIndvId() {
		return sbscrIndvId;
	}

	public void setSbscrIndvId(String sbscrIndvId) {
		this.sbscrIndvId = sbscrIndvId;
	}

	public Long getSbscrSrcSysId() {
		return sbscrSrcSysId;
	}

	public void setSbscrSrcSysId(Long sbscrSrcSysId) {
		this.sbscrSrcSysId = sbscrSrcSysId;
	}

	public Date getSbscrEffDtlDt() {
		return sbscrEffDtlDt;
	}

	public void setSbscrEffDtlDt(Date sbscrEffDtlDt) {
		this.sbscrEffDtlDt = sbscrEffDtlDt;
	}

	public String getPtntIndvId() {
		return ptntIndvId;
	}

	public void setPtntIndvId(String ptntIndvId) {
		this.ptntIndvId = ptntIndvId;
	}

	public Long getPtntSrcSysId() {
		return ptntSrcSysId;
	}

	public void setPtntSrcSysId(Long ptntSrcSysId) {
		this.ptntSrcSysId = ptntSrcSysId;
	}

	public Date getPtntEffDtlDt() {
		return ptntEffDtlDt;
	}

	public void setPtntEffDtlDt(Date ptntEffDtlDt) {
		this.ptntEffDtlDt = ptntEffDtlDt;
	}

	public String getRndrProvId() {
		return rndrProvId;
	}

	public void setRndrProvId(String rndrProvId) {
		this.rndrProvId = rndrProvId;
	}

	public Long getRndrProvSrcSysId() {
		return rndrProvSrcSysId;
	}

	public void setRndrProvSrcSysId(Long rndrProvSrcSysId) {
		this.rndrProvSrcSysId = rndrProvSrcSysId;
	}

	public Date getRndrProvEffDtlDt() {
		return rndrProvEffDtlDt;
	}

	public void setRndrProvEffDtlDt(Date rndrProvEffDtlDt) {
		this.rndrProvEffDtlDt = rndrProvEffDtlDt;
	}

	public Integer getRndrNpiVal() {
		return rndrNpiVal;
	}

	public void setRndrNpiVal(Integer rndrNpiVal) {
		this.rndrNpiVal = rndrNpiVal;
	}

	public Long getRndrProvTypId() {
		return rndrProvTypId;
	}

	public void setRndrProvTypId(Long rndrProvTypId) {
		this.rndrProvTypId = rndrProvTypId;
	}

	public Long getRndrProvClssTypId() {
		return rndrProvClssTypId;
	}

	public void setRndrProvClssTypId(Long rndrProvClssTypId) {
		this.rndrProvClssTypId = rndrProvClssTypId;
	}

	public Long getRndrProvSpclTypId() {
		return rndrProvSpclTypId;
	}

	public void setRndrProvSpclTypId(Long rndrProvSpclTypId) {
		this.rndrProvSpclTypId = rndrProvSpclTypId;
	}

	public String getBilProvId() {
		return bilProvId;
	}

	public void setBilProvId(String bilProvId) {
		this.bilProvId = bilProvId;
	}

	public Long getBilProvSrcSysId() {
		return bilProvSrcSysId;
	}

	public void setBilProvSrcSysId(Long bilProvSrcSysId) {
		this.bilProvSrcSysId = bilProvSrcSysId;
	}

	public Date getBilProvEffDtlDt() {
		return bilProvEffDtlDt;
	}

	public void setBilProvEffDtlDt(Date bilProvEffDtlDt) {
		this.bilProvEffDtlDt = bilProvEffDtlDt;
	}

	public Integer getBilNpiVal() {
		return bilNpiVal;
	}

	public void setBilNpiVal(Integer bilNpiVal) {
		this.bilNpiVal = bilNpiVal;
	}

	public Long getBilProvTypId() {
		return bilProvTypId;
	}

	public void setBilProvTypId(Long bilProvTypId) {
		this.bilProvTypId = bilProvTypId;
	}

	public Long getBilProvClssTypId() {
		return bilProvClssTypId;
	}

	public void setBilProvClssTypId(Long bilProvClssTypId) {
		this.bilProvClssTypId = bilProvClssTypId;
	}

	public Long getBilProvSpclTypId() {
		return bilProvSpclTypId;
	}

	public void setBilProvSpclTypId(Long bilProvSpclTypId) {
		this.bilProvSpclTypId = bilProvSpclTypId;
	}

	public String getRefProvId() {
		return refProvId;
	}

	public void setRefProvId(String refProvId) {
		this.refProvId = refProvId;
	}

	public Long getRefProvSrcSysId() {
		return refProvSrcSysId;
	}

	public void setRefProvSrcSysId(Long refProvSrcSysId) {
		this.refProvSrcSysId = refProvSrcSysId;
	}

	public Date getRefProvEffDtlDt() {
		return refProvEffDtlDt;
	}

	public void setRefProvEffDtlDt(Date refProvEffDtlDt) {
		this.refProvEffDtlDt = refProvEffDtlDt;
	}

	public Integer getRefNpiVal() {
		return refNpiVal;
	}

	public void setRefNpiVal(Integer refNpiVal) {
		this.refNpiVal = refNpiVal;
	}

	public Long getRefProvTypId() {
		return refProvTypId;
	}

	public void setRefProvTypId(Long refProvTypId) {
		this.refProvTypId = refProvTypId;
	}

	public Long getRefProvClssTypId() {
		return refProvClssTypId;
	}

	public void setRefProvClssTypId(Long refProvClssTypId) {
		this.refProvClssTypId = refProvClssTypId;
	}

	public Long getRefProvSpclTypId() {
		return refProvSpclTypId;
	}

	public void setRefProvSpclTypId(Long refProvSpclTypId) {
		this.refProvSpclTypId = refProvSpclTypId;
	}

	public String getFaclProvId() {
		return faclProvId;
	}

	public void setFaclProvId(String faclProvId) {
		this.faclProvId = faclProvId;
	}

	public Long getFaclProvSrcSysId() {
		return faclProvSrcSysId;
	}

	public void setFaclProvSrcSysId(Long faclProvSrcSysId) {
		this.faclProvSrcSysId = faclProvSrcSysId;
	}

	public Date getFaclProvEffDtlDt() {
		return faclProvEffDtlDt;
	}

	public void setFaclProvEffDtlDt(Date faclProvEffDtlDt) {
		this.faclProvEffDtlDt = faclProvEffDtlDt;
	}

	public Integer getFaclNpiVal() {
		return faclNpiVal;
	}

	public void setFaclNpiVal(Integer faclNpiVal) {
		this.faclNpiVal = faclNpiVal;
	}

	public Long getFaclProvTypId() {
		return faclProvTypId;
	}

	public void setFaclProvTypId(Long faclProvTypId) {
		this.faclProvTypId = faclProvTypId;
	}

	public Long getFaclProvClssTypId() {
		return faclProvClssTypId;
	}

	public void setFaclProvClssTypId(Long faclProvClssTypId) {
		this.faclProvClssTypId = faclProvClssTypId;
	}

	public Long getFaclProvSpclTypId() {
		return faclProvSpclTypId;
	}

	public void setFaclProvSpclTypId(Long faclProvSpclTypId) {
		this.faclProvSpclTypId = faclProvSpclTypId;
	}

	public String getAtdProvId() {
		return atdProvId;
	}

	public void setAtdProvId(String atdProvId) {
		this.atdProvId = atdProvId;
	}

	public Long getAtdProvSrcSysId() {
		return atdProvSrcSysId;
	}

	public void setAtdProvSrcSysId(Long atdProvSrcSysId) {
		this.atdProvSrcSysId = atdProvSrcSysId;
	}

	public Date getAtdProvEffDtlDt() {
		return atdProvEffDtlDt;
	}

	public void setAtdProvEffDtlDt(Date atdProvEffDtlDt) {
		this.atdProvEffDtlDt = atdProvEffDtlDt;
	}

	public Integer getAtdNpiVal() {
		return atdNpiVal;
	}

	public void setAtdNpiVal(Integer atdNpiVal) {
		this.atdNpiVal = atdNpiVal;
	}

	public Long getAtdProvTypId() {
		return atdProvTypId;
	}

	public void setAtdProvTypId(Long atdProvTypId) {
		this.atdProvTypId = atdProvTypId;
	}

	public Long getAtdProvClssTypId() {
		return atdProvClssTypId;
	}

	public void setAtdProvClssTypId(Long atdProvClssTypId) {
		this.atdProvClssTypId = atdProvClssTypId;
	}

	public Long getAtdProvSpclTypId() {
		return atdProvSpclTypId;
	}

	public void setAtdProvSpclTypId(Long atdProvSpclTypId) {
		this.atdProvSpclTypId = atdProvSpclTypId;
	}

	public String getOperProvId() {
		return operProvId;
	}

	public void setOperProvId(String operProvId) {
		this.operProvId = operProvId;
	}

	public Long getOperProvSrcSysId() {
		return operProvSrcSysId;
	}

	public void setOperProvSrcSysId(Long operProvSrcSysId) {
		this.operProvSrcSysId = operProvSrcSysId;
	}

	public Date getOperProvEffDtlDt() {
		return operProvEffDtlDt;
	}

	public void setOperProvEffDtlDt(Date operProvEffDtlDt) {
		this.operProvEffDtlDt = operProvEffDtlDt;
	}

	public Integer getOperNpiVal() {
		return operNpiVal;
	}

	public void setOperNpiVal(Integer operNpiVal) {
		this.operNpiVal = operNpiVal;
	}

	public Long getOperProvTypId() {
		return operProvTypId;
	}

	public void setOperProvTypId(Long operProvTypId) {
		this.operProvTypId = operProvTypId;
	}

	public Long getOperProvClssTypId() {
		return operProvClssTypId;
	}

	public void setOperProvClssTypId(Long operProvClssTypId) {
		this.operProvClssTypId = operProvClssTypId;
	}

	public Long getOperProvSpclTypId() {
		return operProvSpclTypId;
	}

	public void setOperProvSpclTypId(Long operProvSpclTypId) {
		this.operProvSpclTypId = operProvSpclTypId;
	}

	public String getSrvcLocProvId() {
		return srvcLocProvId;
	}

	public void setSrvcLocProvId(String srvcLocProvId) {
		this.srvcLocProvId = srvcLocProvId;
	}

	public Long getSrvcLocProvSrcSysId() {
		return srvcLocProvSrcSysId;
	}

	public void setSrvcLocProvSrcSysId(Long srvcLocProvSrcSysId) {
		this.srvcLocProvSrcSysId = srvcLocProvSrcSysId;
	}

	public Date getSrvcLocProvEffDtlDt() {
		return srvcLocProvEffDtlDt;
	}

	public void setSrvcLocProvEffDtlDt(Date srvcLocProvEffDtlDt) {
		this.srvcLocProvEffDtlDt = srvcLocProvEffDtlDt;
	}

	public Long getSrvcLocProvAdrTypId() {
		return srvcLocProvAdrTypId;
	}

	public void setSrvcLocProvAdrTypId(Long srvcLocProvAdrTypId) {
		this.srvcLocProvAdrTypId = srvcLocProvAdrTypId;
	}

	public String getSrvcLocProvLocId() {
		return srvcLocProvLocId;
	}

	public void setSrvcLocProvLocId(String srvcLocProvLocId) {
		this.srvcLocProvLocId = srvcLocProvLocId;
	}

	public Date getSrvcLocProvPracLocEffDtlDt() {
		return srvcLocProvPracLocEffDtlDt;
	}

	public void setSrvcLocProvPracLocEffDtlDt(Date srvcLocProvPracLocEffDtlDt) {
		this.srvcLocProvPracLocEffDtlDt = srvcLocProvPracLocEffDtlDt;
	}

	public Date getStrtSrvcDt() {
		return strtSrvcDt;
	}

	public void setStrtSrvcDt(Date strtSrvcDt) {
		this.strtSrvcDt = strtSrvcDt;
	}

	public Date getEndSrvcDt() {
		return endSrvcDt;
	}

	public void setEndSrvcDt(Date endSrvcDt) {
		this.endSrvcDt = endSrvcDt;
	}

	public Date getClmRecptDt() {
		return clmRecptDt;
	}

	public void setClmRecptDt(Date clmRecptDt) {
		this.clmRecptDt = clmRecptDt;
	}

	public Date getClmAdjdDt() {
		return clmAdjdDt;
	}

	public void setClmAdjdDt(Date clmAdjdDt) {
		this.clmAdjdDt = clmAdjdDt;
	}

	public Timestamp getAdmisDttm() {
		return admisDttm;
	}

	public void setAdmisDttm(Timestamp admisDttm) {
		this.admisDttm = admisDttm;
	}

	public Timestamp getDschrgDttm() {
		return dschrgDttm;
	}

	public void setDschrgDttm(Timestamp dschrgDttm) {
		this.dschrgDttm = dschrgDttm;
	}

	public Date getAccDt() {
		return accDt;
	}

	public void setAccDt(Date accDt) {
		this.accDt = accDt;
	}

	public Date getInitTrtDt() {
		return initTrtDt;
	}

	public void setInitTrtDt(Date initTrtDt) {
		this.initTrtDt = initTrtDt;
	}

	public Date getLstSeenDt() {
		return lstSeenDt;
	}

	public void setLstSeenDt(Date lstSeenDt) {
		this.lstSeenDt = lstSeenDt;
	}

	public Date getSympDt() {
		return sympDt;
	}

	public void setSympDt(Date sympDt) {
		this.sympDt = sympDt;
	}

	public Date getMnfstDt() {
		return mnfstDt;
	}

	public void setMnfstDt(Date mnfstDt) {
		this.mnfstDt = mnfstDt;
	}

	public Date getDsblStrtDt() {
		return dsblStrtDt;
	}

	public void setDsblStrtDt(Date dsblStrtDt) {
		this.dsblStrtDt = dsblStrtDt;
	}

	public Date getDsblEndDt() {
		return dsblEndDt;
	}

	public void setDsblEndDt(Date dsblEndDt) {
		this.dsblEndDt = dsblEndDt;
	}

	public Date getStmtBegnDt() {
		return stmtBegnDt;
	}

	public void setStmtBegnDt(Date stmtBegnDt) {
		this.stmtBegnDt = stmtBegnDt;
	}

	public Date getStmtEndDt() {
		return stmtEndDt;
	}

	public void setStmtEndDt(Date stmtEndDt) {
		this.stmtEndDt = stmtEndDt;
	}

	public Date getLstWrkDt() {
		return lstWrkDt;
	}

	public void setLstWrkDt(Date lstWrkDt) {
		this.lstWrkDt = lstWrkDt;
	}

	public Date getAuthRtnWrkDt() {
		return authRtnWrkDt;
	}

	public void setAuthRtnWrkDt(Date authRtnWrkDt) {
		this.authRtnWrkDt = authRtnWrkDt;
	}

	public Timestamp getClmSbmtDttm() {
		return clmSbmtDttm;
	}

	public void setClmSbmtDttm(Timestamp clmSbmtDttm) {
		this.clmSbmtDttm = clmSbmtDttm;
	}

	public Date getPrscDt() {
		return prscDt;
	}

	public void setPrscDt(Date prscDt) {
		this.prscDt = prscDt;
	}

	public Date getRlnqCareDt() {
		return rlnqCareDt;
	}

	public void setRlnqCareDt(Date rlnqCareDt) {
		this.rlnqCareDt = rlnqCareDt;
	}

	public Date getClmPdDt() {
		return clmPdDt;
	}

	public void setClmPdDt(Date clmPdDt) {
		this.clmPdDt = clmPdDt;
	}

	public String getPtntSgnSrcInd() {
		return ptntSgnSrcInd;
	}

	public void setPtntSgnSrcInd(String ptntSgnSrcInd) {
		this.ptntSgnSrcInd = ptntSgnSrcInd;
	}

	public String getHspcPtntInd() {
		return hspcPtntInd;
	}

	public void setHspcPtntInd(String hspcPtntInd) {
		this.hspcPtntInd = hspcPtntInd;
	}

	public String getProvSgnInd() {
		return provSgnInd;
	}

	public void setProvSgnInd(String provSgnInd) {
		this.provSgnInd = provSgnInd;
	}

	public String getClmEnctrInd() {
		return clmEnctrInd;
	}

	public void setClmEnctrInd(String clmEnctrInd) {
		this.clmEnctrInd = clmEnctrInd;
	}

	public String getCobSpctInd() {
		return cobSpctInd;
	}

	public void setCobSpctInd(String cobSpctInd) {
		this.cobSpctInd = cobSpctInd;
	}

	public Long getClmTransStsId() {
		return clmTransStsId;
	}

	public void setClmTransStsId(Long clmTransStsId) {
		this.clmTransStsId = clmTransStsId;
	}

	public Timestamp getClmTransStsEffDttm() {
		return clmTransStsEffDttm;
	}

	public void setClmTransStsEffDttm(Timestamp clmTransStsEffDttm) {
		this.clmTransStsEffDttm = clmTransStsEffDttm;
	}

	public Long getClmTypId() {
		return clmTypId;
	}

	public void setClmTypId(Long clmTypId) {
		this.clmTypId = clmTypId;
	}

	public Long getClmTransProcStsId() {
		return clmTransProcStsId;
	}

	public void setClmTransProcStsId(Long clmTransProcStsId) {
		this.clmTransProcStsId = clmTransProcStsId;
	}

	public Long getAdmisSrcId() {
		return admisSrcId;
	}

	public void setAdmisSrcId(Long admisSrcId) {
		this.admisSrcId = admisSrcId;
	}

	public Long getPtntStsId() {
		return ptntStsId;
	}

	public void setPtntStsId(Long ptntStsId) {
		this.ptntStsId = ptntStsId;
	}

	public Long getPrcMethTypId() {
		return prcMethTypId;
	}

	public void setPrcMethTypId(Long prcMethTypId) {
		this.prcMethTypId = prcMethTypId;
	}

	public Long getClmFreqTypId() {
		return clmFreqTypId;
	}

	public void setClmFreqTypId(Long clmFreqTypId) {
		this.clmFreqTypId = clmFreqTypId;
	}

	public Long getClmTransTypId() {
		return clmTransTypId;
	}

	public void setClmTransTypId(Long clmTransTypId) {
		this.clmTransTypId = clmTransTypId;
	}

	public Long getBenLvlCausId() {
		return benLvlCausId;
	}

	public void setBenLvlCausId(Long benLvlCausId) {
		this.benLvlCausId = benLvlCausId;
	}

	public Long getAdmisTypId() {
		return admisTypId;
	}

	public void setAdmisTypId(Long admisTypId) {
		this.admisTypId = admisTypId;
	}

	public Long getSpclPgmId() {
		return spclPgmId;
	}

	public void setSpclPgmId(Long spclPgmId) {
		this.spclPgmId = spclPgmId;
	}

	public Long getDschrgStsId() {
		return dschrgStsId;
	}

	public void setDschrgStsId(Long dschrgStsId) {
		this.dschrgStsId = dschrgStsId;
	}

	public Long getPtntSgnSrcId() {
		return ptntSgnSrcId;
	}

	public void setPtntSgnSrcId(Long ptntSgnSrcId) {
		this.ptntSgnSrcId = ptntSgnSrcId;
	}

	public Long getPlnPrtcpId() {
		return plnPrtcpId;
	}

	public void setPlnPrtcpId(Long plnPrtcpId) {
		this.plnPrtcpId = plnPrtcpId;
	}

	public Long getClmDnlRsnId() {
		return clmDnlRsnId;
	}

	public void setClmDnlRsnId(Long clmDnlRsnId) {
		this.clmDnlRsnId = clmDnlRsnId;
	}

	public Long getDlayRsnId() {
		return dlayRsnId;
	}

	public void setDlayRsnId(Long dlayRsnId) {
		this.dlayRsnId = dlayRsnId;
	}

	public Long getPlsrvId() {
		return plsrvId;
	}

	public void setPlsrvId(Long plsrvId) {
		this.plsrvId = plsrvId;
	}

	public Long getRlseOfInfoId() {
		return rlseOfInfoId;
	}

	public void setRlseOfInfoId(Long rlseOfInfoId) {
		this.rlseOfInfoId = rlseOfInfoId;
	}

	public Long getAdjdCobLvlId() {
		return adjdCobLvlId;
	}

	public void setAdjdCobLvlId(Long adjdCobLvlId) {
		this.adjdCobLvlId = adjdCobLvlId;
	}

	public String getOonClmBilProvInd() {
		return oonClmBilProvInd;
	}

	public void setOonClmBilProvInd(String oonClmBilProvInd) {
		this.oonClmBilProvInd = oonClmBilProvInd;
	}

	public String getOonClmRndrProvInd() {
		return oonClmRndrProvInd;
	}

	public void setOonClmRndrProvInd(String oonClmRndrProvInd) {
		this.oonClmRndrProvInd = oonClmRndrProvInd;
	}

	public String getMedcrAsgnInd() {
		return medcrAsgnInd;
	}

	public void setMedcrAsgnInd(String medcrAsgnInd) {
		this.medcrAsgnInd = medcrAsgnInd;
	}

	public String getBenAsgnInd() {
		return benAsgnInd;
	}

	public void setBenAsgnInd(String benAsgnInd) {
		this.benAsgnInd = benAsgnInd;
	}

	public String getMedRecNbr() {
		return medRecNbr;
	}

	public void setMedRecNbr(String medRecNbr) {
		this.medRecNbr = medRecNbr;
	}

	public String getPtntAcctNbr() {
		return ptntAcctNbr;
	}

	public void setPtntAcctNbr(String ptntAcctNbr) {
		this.ptntAcctNbr = ptntAcctNbr;
	}

	public String getChkNbr() {
		return chkNbr;
	}

	public void setChkNbr(String chkNbr) {
		this.chkNbr = chkNbr;
	}

	public Long getClmBilTypId() {
		return clmBilTypId;
	}

	public void setClmBilTypId(Long clmBilTypId) {
		this.clmBilTypId = clmBilTypId;
	}

	public String getClmBilTypCd() {
		return clmBilTypCd;
	}

	public void setClmBilTypCd(String clmBilTypCd) {
		this.clmBilTypCd = clmBilTypCd;
	}

	public Long getClmSbmtMethId() {
		return clmSbmtMethId;
	}

	public void setClmSbmtMethId(Long clmSbmtMethId) {
		this.clmSbmtMethId = clmSbmtMethId;
	}

	public Long getClmFlId() {
		return clmFlId;
	}

	public void setClmFlId(Long clmFlId) {
		this.clmFlId = clmFlId;
	}

	public Long getRelCaus1Id() {
		return relCaus1Id;
	}

	public void setRelCaus1Id(Long relCaus1Id) {
		this.relCaus1Id = relCaus1Id;
	}

	public Long getRelCaus2Id() {
		return relCaus2Id;
	}

	public void setRelCaus2Id(Long relCaus2Id) {
		this.relCaus2Id = relCaus2Id;
	}

	public Long getRelCausCntryId() {
		return relCausCntryId;
	}

	public void setRelCausCntryId(Long relCausCntryId) {
		this.relCausCntryId = relCausCntryId;
	}

	public Long getRelCausStId() {
		return relCausStId;
	}

	public void setRelCausStId(Long relCausStId) {
		this.relCausStId = relCausStId;
	}

	public Long getAdmitDiagId() {
		return admitDiagId;
	}

	public void setAdmitDiagId(Long admitDiagId) {
		this.admitDiagId = admitDiagId;
	}

	public Long getAdmitDiagLvlTypId() {
		return admitDiagLvlTypId;
	}

	public void setAdmitDiagLvlTypId(Long admitDiagLvlTypId) {
		this.admitDiagLvlTypId = admitDiagLvlTypId;
	}

	public Integer getAdmitDiagPrrSeqNbr() {
		return admitDiagPrrSeqNbr;
	}

	public void setAdmitDiagPrrSeqNbr(Integer admitDiagPrrSeqNbr) {
		this.admitDiagPrrSeqNbr = admitDiagPrrSeqNbr;
	}

	public String getAdmitDiagPrsOnAdmisInd() {
		return admitDiagPrsOnAdmisInd;
	}

	public void setAdmitDiagPrsOnAdmisInd(String admitDiagPrsOnAdmisInd) {
		this.admitDiagPrsOnAdmisInd = admitDiagPrsOnAdmisInd;
	}

	public String getDiag1TypCd() {
		return diag1TypCd;
	}

	public void setDiag1TypCd(String diag1TypCd) {
		this.diag1TypCd = diag1TypCd;
	}

	public Long getDiag1Id() {
		return diag1Id;
	}

	public void setDiag1Id(Long diag1Id) {
		this.diag1Id = diag1Id;
	}

	public String getDiag1Cd() {
		return diag1Cd;
	}

	public void setDiag1Cd(String diag1Cd) {
		this.diag1Cd = diag1Cd;
	}

	public Long getDiag1LvlTypId() {
		return diag1LvlTypId;
	}

	public void setDiag1LvlTypId(Long diag1LvlTypId) {
		this.diag1LvlTypId = diag1LvlTypId;
	}

	public String getDiag1LvlTypCd() {
		return diag1LvlTypCd;
	}

	public void setDiag1LvlTypCd(String diag1LvlTypCd) {
		this.diag1LvlTypCd = diag1LvlTypCd;
	}

	public Integer getDiag1PrrSeqNbr() {
		return diag1PrrSeqNbr;
	}

	public void setDiag1PrrSeqNbr(Integer diag1PrrSeqNbr) {
		this.diag1PrrSeqNbr = diag1PrrSeqNbr;
	}

	public String getDiag1PrsOnAdmisInd() {
		return diag1PrsOnAdmisInd;
	}

	public void setDiag1PrsOnAdmisInd(String diag1PrsOnAdmisInd) {
		this.diag1PrsOnAdmisInd = diag1PrsOnAdmisInd;
	}

	public String getDiag2TypCd() {
		return diag2TypCd;
	}

	public void setDiag2TypCd(String diag2TypCd) {
		this.diag2TypCd = diag2TypCd;
	}

	public Long getDiag2Id() {
		return diag2Id;
	}

	public void setDiag2Id(Long diag2Id) {
		this.diag2Id = diag2Id;
	}

	public String getDiag2Cd() {
		return diag2Cd;
	}

	public void setDiag2Cd(String diag2Cd) {
		this.diag2Cd = diag2Cd;
	}

	public Long getDiag2LvlTypId() {
		return diag2LvlTypId;
	}

	public void setDiag2LvlTypId(Long diag2LvlTypId) {
		this.diag2LvlTypId = diag2LvlTypId;
	}

	public String getDiag2LvlTypCd() {
		return diag2LvlTypCd;
	}

	public void setDiag2LvlTypCd(String diag2LvlTypCd) {
		this.diag2LvlTypCd = diag2LvlTypCd;
	}

	public Integer getDiag2PrrSeqNbr() {
		return diag2PrrSeqNbr;
	}

	public void setDiag2PrrSeqNbr(Integer diag2PrrSeqNbr) {
		this.diag2PrrSeqNbr = diag2PrrSeqNbr;
	}

	public String getDiag2PrsOnAdmisInd() {
		return diag2PrsOnAdmisInd;
	}

	public void setDiag2PrsOnAdmisInd(String diag2PrsOnAdmisInd) {
		this.diag2PrsOnAdmisInd = diag2PrsOnAdmisInd;
	}

	public String getDiag3TypCd() {
		return diag3TypCd;
	}

	public void setDiag3TypCd(String diag3TypCd) {
		this.diag3TypCd = diag3TypCd;
	}

	public Long getDiag3Id() {
		return diag3Id;
	}

	public void setDiag3Id(Long diag3Id) {
		this.diag3Id = diag3Id;
	}

	public String getDiag3Cd() {
		return diag3Cd;
	}

	public void setDiag3Cd(String diag3Cd) {
		this.diag3Cd = diag3Cd;
	}

	public Long getDiag3LvlTypId() {
		return diag3LvlTypId;
	}

	public void setDiag3LvlTypId(Long diag3LvlTypId) {
		this.diag3LvlTypId = diag3LvlTypId;
	}

	public String getDiag3LvlTypCd() {
		return diag3LvlTypCd;
	}

	public void setDiag3LvlTypCd(String diag3LvlTypCd) {
		this.diag3LvlTypCd = diag3LvlTypCd;
	}

	public Integer getDiag3PrrSeqNbr() {
		return diag3PrrSeqNbr;
	}

	public void setDiag3PrrSeqNbr(Integer diag3PrrSeqNbr) {
		this.diag3PrrSeqNbr = diag3PrrSeqNbr;
	}

	public String getDiag3PrsOnAdmisInd() {
		return diag3PrsOnAdmisInd;
	}

	public void setDiag3PrsOnAdmisInd(String diag3PrsOnAdmisInd) {
		this.diag3PrsOnAdmisInd = diag3PrsOnAdmisInd;
	}

	public String getDiag4TypCd() {
		return diag4TypCd;
	}

	public void setDiag4TypCd(String diag4TypCd) {
		this.diag4TypCd = diag4TypCd;
	}

	public Long getDiag4Id() {
		return diag4Id;
	}

	public void setDiag4Id(Long diag4Id) {
		this.diag4Id = diag4Id;
	}

	public String getDiag4Cd() {
		return diag4Cd;
	}

	public void setDiag4Cd(String diag4Cd) {
		this.diag4Cd = diag4Cd;
	}

	public Long getDiag4LvlTypId() {
		return diag4LvlTypId;
	}

	public void setDiag4LvlTypId(Long diag4LvlTypId) {
		this.diag4LvlTypId = diag4LvlTypId;
	}

	public String getDiag4LvlTypCd() {
		return diag4LvlTypCd;
	}

	public void setDiag4LvlTypCd(String diag4LvlTypCd) {
		this.diag4LvlTypCd = diag4LvlTypCd;
	}

	public Integer getDiag4PrrSeqNbr() {
		return diag4PrrSeqNbr;
	}

	public void setDiag4PrrSeqNbr(Integer diag4PrrSeqNbr) {
		this.diag4PrrSeqNbr = diag4PrrSeqNbr;
	}

	public String getDiag4PrsOnAdmisInd() {
		return diag4PrsOnAdmisInd;
	}

	public void setDiag4PrsOnAdmisInd(String diag4PrsOnAdmisInd) {
		this.diag4PrsOnAdmisInd = diag4PrsOnAdmisInd;
	}

	public String getDiag5TypCd() {
		return diag5TypCd;
	}

	public void setDiag5TypCd(String diag5TypCd) {
		this.diag5TypCd = diag5TypCd;
	}

	public Long getDiag5Id() {
		return diag5Id;
	}

	public void setDiag5Id(Long diag5Id) {
		this.diag5Id = diag5Id;
	}

	public String getDiag5Cd() {
		return diag5Cd;
	}

	public void setDiag5Cd(String diag5Cd) {
		this.diag5Cd = diag5Cd;
	}

	public Long getDiag5LvlTypId() {
		return diag5LvlTypId;
	}

	public void setDiag5LvlTypId(Long diag5LvlTypId) {
		this.diag5LvlTypId = diag5LvlTypId;
	}

	public String getDiag5LvlTypCd() {
		return diag5LvlTypCd;
	}

	public void setDiag5LvlTypCd(String diag5LvlTypCd) {
		this.diag5LvlTypCd = diag5LvlTypCd;
	}

	public Integer getDiag5PrrSeqNbr() {
		return diag5PrrSeqNbr;
	}

	public void setDiag5PrrSeqNbr(Integer diag5PrrSeqNbr) {
		this.diag5PrrSeqNbr = diag5PrrSeqNbr;
	}

	public String getDiag5PrsOnAdmisInd() {
		return diag5PrsOnAdmisInd;
	}

	public void setDiag5PrsOnAdmisInd(String diag5PrsOnAdmisInd) {
		this.diag5PrsOnAdmisInd = diag5PrsOnAdmisInd;
	}

	public String getDiag6TypCd() {
		return diag6TypCd;
	}

	public void setDiag6TypCd(String diag6TypCd) {
		this.diag6TypCd = diag6TypCd;
	}

	public Long getDiag6Id() {
		return diag6Id;
	}

	public void setDiag6Id(Long diag6Id) {
		this.diag6Id = diag6Id;
	}

	public String getDiag6Cd() {
		return diag6Cd;
	}

	public void setDiag6Cd(String diag6Cd) {
		this.diag6Cd = diag6Cd;
	}

	public Long getDiag6LvlTypId() {
		return diag6LvlTypId;
	}

	public void setDiag6LvlTypId(Long diag6LvlTypId) {
		this.diag6LvlTypId = diag6LvlTypId;
	}

	public String getDiag6LvlTypCd() {
		return diag6LvlTypCd;
	}

	public void setDiag6LvlTypCd(String diag6LvlTypCd) {
		this.diag6LvlTypCd = diag6LvlTypCd;
	}

	public Integer getDiag6PrrSeqNbr() {
		return diag6PrrSeqNbr;
	}

	public void setDiag6PrrSeqNbr(Integer diag6PrrSeqNbr) {
		this.diag6PrrSeqNbr = diag6PrrSeqNbr;
	}

	public String getDiag6PrsOnAdmisInd() {
		return diag6PrsOnAdmisInd;
	}

	public void setDiag6PrsOnAdmisInd(String diag6PrsOnAdmisInd) {
		this.diag6PrsOnAdmisInd = diag6PrsOnAdmisInd;
	}

	public String getDiag7TypCd() {
		return diag7TypCd;
	}

	public void setDiag7TypCd(String diag7TypCd) {
		this.diag7TypCd = diag7TypCd;
	}

	public Long getDiag7Id() {
		return diag7Id;
	}

	public void setDiag7Id(Long diag7Id) {
		this.diag7Id = diag7Id;
	}

	public String getDiag7Cd() {
		return diag7Cd;
	}

	public void setDiag7Cd(String diag7Cd) {
		this.diag7Cd = diag7Cd;
	}

	public Long getDiag7LvlTypId() {
		return diag7LvlTypId;
	}

	public void setDiag7LvlTypId(Long diag7LvlTypId) {
		this.diag7LvlTypId = diag7LvlTypId;
	}

	public String getDiag7LvlTypCd() {
		return diag7LvlTypCd;
	}

	public void setDiag7LvlTypCd(String diag7LvlTypCd) {
		this.diag7LvlTypCd = diag7LvlTypCd;
	}

	public Integer getDiag7PrrSeqNbr() {
		return diag7PrrSeqNbr;
	}

	public void setDiag7PrrSeqNbr(Integer diag7PrrSeqNbr) {
		this.diag7PrrSeqNbr = diag7PrrSeqNbr;
	}

	public String getDiag7PrsOnAdmisInd() {
		return diag7PrsOnAdmisInd;
	}

	public void setDiag7PrsOnAdmisInd(String diag7PrsOnAdmisInd) {
		this.diag7PrsOnAdmisInd = diag7PrsOnAdmisInd;
	}

	public String getDiag8TypCd() {
		return diag8TypCd;
	}

	public void setDiag8TypCd(String diag8TypCd) {
		this.diag8TypCd = diag8TypCd;
	}

	public Long getDiag8Id() {
		return diag8Id;
	}

	public void setDiag8Id(Long diag8Id) {
		this.diag8Id = diag8Id;
	}

	public String getDiag8Cd() {
		return diag8Cd;
	}

	public void setDiag8Cd(String diag8Cd) {
		this.diag8Cd = diag8Cd;
	}

	public Long getDiag8LvlTypId() {
		return diag8LvlTypId;
	}

	public void setDiag8LvlTypId(Long diag8LvlTypId) {
		this.diag8LvlTypId = diag8LvlTypId;
	}

	public String getDiag8LvlTypCd() {
		return diag8LvlTypCd;
	}

	public void setDiag8LvlTypCd(String diag8LvlTypCd) {
		this.diag8LvlTypCd = diag8LvlTypCd;
	}

	public Integer getDiag8PrrSeqNbr() {
		return diag8PrrSeqNbr;
	}

	public void setDiag8PrrSeqNbr(Integer diag8PrrSeqNbr) {
		this.diag8PrrSeqNbr = diag8PrrSeqNbr;
	}

	public String getDiag8PrsOnAdmisInd() {
		return diag8PrsOnAdmisInd;
	}

	public void setDiag8PrsOnAdmisInd(String diag8PrsOnAdmisInd) {
		this.diag8PrsOnAdmisInd = diag8PrsOnAdmisInd;
	}

	public String getDiag9TypCd() {
		return diag9TypCd;
	}

	public void setDiag9TypCd(String diag9TypCd) {
		this.diag9TypCd = diag9TypCd;
	}

	public Long getDiag9Id() {
		return diag9Id;
	}

	public void setDiag9Id(Long diag9Id) {
		this.diag9Id = diag9Id;
	}

	public String getDiag9Cd() {
		return diag9Cd;
	}

	public void setDiag9Cd(String diag9Cd) {
		this.diag9Cd = diag9Cd;
	}

	public Long getDiag9LvlTypId() {
		return diag9LvlTypId;
	}

	public void setDiag9LvlTypId(Long diag9LvlTypId) {
		this.diag9LvlTypId = diag9LvlTypId;
	}

	public String getDiag9LvlTypCd() {
		return diag9LvlTypCd;
	}

	public void setDiag9LvlTypCd(String diag9LvlTypCd) {
		this.diag9LvlTypCd = diag9LvlTypCd;
	}

	public String getDiag9PrrSeqNbr() {
		return diag9PrrSeqNbr;
	}

	public void setDiag9PrrSeqNbr(String diag9PrrSeqNbr) {
		this.diag9PrrSeqNbr = diag9PrrSeqNbr;
	}

	public String getDiag9PrsOnAdmisInd() {
		return diag9PrsOnAdmisInd;
	}

	public void setDiag9PrsOnAdmisInd(String diag9PrsOnAdmisInd) {
		this.diag9PrsOnAdmisInd = diag9PrsOnAdmisInd;
	}

	public String getDiag10TypCd() {
		return diag10TypCd;
	}

	public void setDiag10TypCd(String diag10TypCd) {
		this.diag10TypCd = diag10TypCd;
	}

	public Long getDiag10Id() {
		return diag10Id;
	}

	public void setDiag10Id(Long diag10Id) {
		this.diag10Id = diag10Id;
	}

	public String getDiag10Cd() {
		return diag10Cd;
	}

	public void setDiag10Cd(String diag10Cd) {
		this.diag10Cd = diag10Cd;
	}

	public Long getDiag10LvlTypId() {
		return diag10LvlTypId;
	}

	public void setDiag10LvlTypId(Long diag10LvlTypId) {
		this.diag10LvlTypId = diag10LvlTypId;
	}

	public String getDiag10LvlTypCd() {
		return diag10LvlTypCd;
	}

	public void setDiag10LvlTypCd(String diag10LvlTypCd) {
		this.diag10LvlTypCd = diag10LvlTypCd;
	}

	public Integer getDiag10PrrSeqNbr() {
		return diag10PrrSeqNbr;
	}

	public void setDiag10PrrSeqNbr(Integer diag10PrrSeqNbr) {
		this.diag10PrrSeqNbr = diag10PrrSeqNbr;
	}

	public String getDiag10PrsOnAdmisInd() {
		return diag10PrsOnAdmisInd;
	}

	public void setDiag10PrsOnAdmisInd(String diag10PrsOnAdmisInd) {
		this.diag10PrsOnAdmisInd = diag10PrsOnAdmisInd;
	}

	public String getDiag11TypCd() {
		return diag11TypCd;
	}

	public void setDiag11TypCd(String diag11TypCd) {
		this.diag11TypCd = diag11TypCd;
	}

	public Long getDiag11Id() {
		return diag11Id;
	}

	public void setDiag11Id(Long diag11Id) {
		this.diag11Id = diag11Id;
	}

	public String getDiag11Cd() {
		return diag11Cd;
	}

	public void setDiag11Cd(String diag11Cd) {
		this.diag11Cd = diag11Cd;
	}

	public Long getDiag11LvlTypId() {
		return diag11LvlTypId;
	}

	public void setDiag11LvlTypId(Long diag11LvlTypId) {
		this.diag11LvlTypId = diag11LvlTypId;
	}

	public String getDiag11LvlTypCd() {
		return diag11LvlTypCd;
	}

	public void setDiag11LvlTypCd(String diag11LvlTypCd) {
		this.diag11LvlTypCd = diag11LvlTypCd;
	}

	public Integer getDiag11PrrSeqNbr() {
		return diag11PrrSeqNbr;
	}

	public void setDiag11PrrSeqNbr(Integer diag11PrrSeqNbr) {
		this.diag11PrrSeqNbr = diag11PrrSeqNbr;
	}

	public String getDiag11PrsOnAdmisInd() {
		return diag11PrsOnAdmisInd;
	}

	public void setDiag11PrsOnAdmisInd(String diag11PrsOnAdmisInd) {
		this.diag11PrsOnAdmisInd = diag11PrsOnAdmisInd;
	}

	public String getDiag12TypCd() {
		return diag12TypCd;
	}

	public void setDiag12TypCd(String diag12TypCd) {
		this.diag12TypCd = diag12TypCd;
	}

	public Long getDiag12Id() {
		return diag12Id;
	}

	public void setDiag12Id(Long diag12Id) {
		this.diag12Id = diag12Id;
	}

	public String getDiag12Cd() {
		return diag12Cd;
	}

	public void setDiag12Cd(String diag12Cd) {
		this.diag12Cd = diag12Cd;
	}

	public Long getDiag12LvlTypId() {
		return diag12LvlTypId;
	}

	public void setDiag12LvlTypId(Long diag12LvlTypId) {
		this.diag12LvlTypId = diag12LvlTypId;
	}

	public String getDiag12LvlTypCd() {
		return diag12LvlTypCd;
	}

	public void setDiag12LvlTypCd(String diag12LvlTypCd) {
		this.diag12LvlTypCd = diag12LvlTypCd;
	}

	public Integer getDiag12PrrSeqNbr() {
		return diag12PrrSeqNbr;
	}

	public void setDiag12PrrSeqNbr(Integer diag12PrrSeqNbr) {
		this.diag12PrrSeqNbr = diag12PrrSeqNbr;
	}

	public String getDiag12PrsOnAdmisInd() {
		return diag12PrsOnAdmisInd;
	}

	public void setDiag12PrsOnAdmisInd(String diag12PrsOnAdmisInd) {
		this.diag12PrsOnAdmisInd = diag12PrsOnAdmisInd;
	}

	public String getDiag13TypCd() {
		return diag13TypCd;
	}

	public void setDiag13TypCd(String diag13TypCd) {
		this.diag13TypCd = diag13TypCd;
	}

	public Long getDiag13Id() {
		return diag13Id;
	}

	public void setDiag13Id(Long diag13Id) {
		this.diag13Id = diag13Id;
	}

	public String getDiag13Cd() {
		return diag13Cd;
	}

	public void setDiag13Cd(String diag13Cd) {
		this.diag13Cd = diag13Cd;
	}

	public Long getDiag13LvlTypId() {
		return diag13LvlTypId;
	}

	public void setDiag13LvlTypId(Long diag13LvlTypId) {
		this.diag13LvlTypId = diag13LvlTypId;
	}

	public String getDiag13LvlTypCd() {
		return diag13LvlTypCd;
	}

	public void setDiag13LvlTypCd(String diag13LvlTypCd) {
		this.diag13LvlTypCd = diag13LvlTypCd;
	}

	public Integer getDiag13PrrSeqNbr() {
		return diag13PrrSeqNbr;
	}

	public void setDiag13PrrSeqNbr(Integer diag13PrrSeqNbr) {
		this.diag13PrrSeqNbr = diag13PrrSeqNbr;
	}

	public String getDiag13PrsOnAdmisInd() {
		return diag13PrsOnAdmisInd;
	}

	public void setDiag13PrsOnAdmisInd(String diag13PrsOnAdmisInd) {
		this.diag13PrsOnAdmisInd = diag13PrsOnAdmisInd;
	}

	public String getDiag14TypCd() {
		return diag14TypCd;
	}

	public void setDiag14TypCd(String diag14TypCd) {
		this.diag14TypCd = diag14TypCd;
	}

	public Long getDiag14Id() {
		return diag14Id;
	}

	public void setDiag14Id(Long diag14Id) {
		this.diag14Id = diag14Id;
	}

	public String getDiag14Cd() {
		return diag14Cd;
	}

	public void setDiag14Cd(String diag14Cd) {
		this.diag14Cd = diag14Cd;
	}

	public Long getDiag14LvlTypId() {
		return diag14LvlTypId;
	}

	public void setDiag14LvlTypId(Long diag14LvlTypId) {
		this.diag14LvlTypId = diag14LvlTypId;
	}

	public String getDiag14LvlTypCd() {
		return diag14LvlTypCd;
	}

	public void setDiag14LvlTypCd(String diag14LvlTypCd) {
		this.diag14LvlTypCd = diag14LvlTypCd;
	}

	public Integer getDiag14PrrSeqNbr() {
		return diag14PrrSeqNbr;
	}

	public void setDiag14PrrSeqNbr(Integer diag14PrrSeqNbr) {
		this.diag14PrrSeqNbr = diag14PrrSeqNbr;
	}

	public String getDiag14PrsOnAdmisInd() {
		return diag14PrsOnAdmisInd;
	}

	public void setDiag14PrsOnAdmisInd(String diag14PrsOnAdmisInd) {
		this.diag14PrsOnAdmisInd = diag14PrsOnAdmisInd;
	}

	public String getDiag15TypCd() {
		return diag15TypCd;
	}

	public void setDiag15TypCd(String diag15TypCd) {
		this.diag15TypCd = diag15TypCd;
	}

	public Long getDiag15Id() {
		return diag15Id;
	}

	public void setDiag15Id(Long diag15Id) {
		this.diag15Id = diag15Id;
	}

	public String getDiag15Cd() {
		return diag15Cd;
	}

	public void setDiag15Cd(String diag15Cd) {
		this.diag15Cd = diag15Cd;
	}

	public Long getDiag15LvlTypId() {
		return diag15LvlTypId;
	}

	public void setDiag15LvlTypId(Long diag15LvlTypId) {
		this.diag15LvlTypId = diag15LvlTypId;
	}

	public String getDiag15LvlTypCd() {
		return diag15LvlTypCd;
	}

	public void setDiag15LvlTypCd(String diag15LvlTypCd) {
		this.diag15LvlTypCd = diag15LvlTypCd;
	}

	public Integer getDiag15PrrSeqNbr() {
		return diag15PrrSeqNbr;
	}

	public void setDiag15PrrSeqNbr(Integer diag15PrrSeqNbr) {
		this.diag15PrrSeqNbr = diag15PrrSeqNbr;
	}

	public String getDiag15PrsOnAdmisInd() {
		return diag15PrsOnAdmisInd;
	}

	public void setDiag15PrsOnAdmisInd(String diag15PrsOnAdmisInd) {
		this.diag15PrsOnAdmisInd = diag15PrsOnAdmisInd;
	}

	public String getDiag16TypCd() {
		return diag16TypCd;
	}

	public void setDiag16TypCd(String diag16TypCd) {
		this.diag16TypCd = diag16TypCd;
	}

	public Long getDiag16Id() {
		return diag16Id;
	}

	public void setDiag16Id(Long diag16Id) {
		this.diag16Id = diag16Id;
	}

	public String getDiag16Cd() {
		return diag16Cd;
	}

	public void setDiag16Cd(String diag16Cd) {
		this.diag16Cd = diag16Cd;
	}

	public Long getDiag16LvlTypId() {
		return diag16LvlTypId;
	}

	public void setDiag16LvlTypId(Long diag16LvlTypId) {
		this.diag16LvlTypId = diag16LvlTypId;
	}

	public String getDiag16LvlTypCd() {
		return diag16LvlTypCd;
	}

	public void setDiag16LvlTypCd(String diag16LvlTypCd) {
		this.diag16LvlTypCd = diag16LvlTypCd;
	}

	public Integer getDiag16PrrSeqNbr() {
		return diag16PrrSeqNbr;
	}

	public void setDiag16PrrSeqNbr(Integer diag16PrrSeqNbr) {
		this.diag16PrrSeqNbr = diag16PrrSeqNbr;
	}

	public String getDiag16PrsOnAdmisInd() {
		return diag16PrsOnAdmisInd;
	}

	public void setDiag16PrsOnAdmisInd(String diag16PrsOnAdmisInd) {
		this.diag16PrsOnAdmisInd = diag16PrsOnAdmisInd;
	}

	public String getDiag17TypCd() {
		return diag17TypCd;
	}

	public void setDiag17TypCd(String diag17TypCd) {
		this.diag17TypCd = diag17TypCd;
	}

	public Long getDiag17Id() {
		return diag17Id;
	}

	public void setDiag17Id(Long diag17Id) {
		this.diag17Id = diag17Id;
	}

	public String getDiag17Cd() {
		return diag17Cd;
	}

	public void setDiag17Cd(String diag17Cd) {
		this.diag17Cd = diag17Cd;
	}

	public Long getDiag17LvlTypId() {
		return diag17LvlTypId;
	}

	public void setDiag17LvlTypId(Long diag17LvlTypId) {
		this.diag17LvlTypId = diag17LvlTypId;
	}

	public String getDiag17LvlTypCd() {
		return diag17LvlTypCd;
	}

	public void setDiag17LvlTypCd(String diag17LvlTypCd) {
		this.diag17LvlTypCd = diag17LvlTypCd;
	}

	public Integer getDiag17PrrSeqNbr() {
		return diag17PrrSeqNbr;
	}

	public void setDiag17PrrSeqNbr(Integer diag17PrrSeqNbr) {
		this.diag17PrrSeqNbr = diag17PrrSeqNbr;
	}

	public String getDiag17PrsOnAdmisInd() {
		return diag17PrsOnAdmisInd;
	}

	public void setDiag17PrsOnAdmisInd(String diag17PrsOnAdmisInd) {
		this.diag17PrsOnAdmisInd = diag17PrsOnAdmisInd;
	}

	public String getDiag18TypCd() {
		return diag18TypCd;
	}

	public void setDiag18TypCd(String diag18TypCd) {
		this.diag18TypCd = diag18TypCd;
	}

	public Long getDiag18Id() {
		return diag18Id;
	}

	public void setDiag18Id(Long diag18Id) {
		this.diag18Id = diag18Id;
	}

	public String getDiag18Cd() {
		return diag18Cd;
	}

	public void setDiag18Cd(String diag18Cd) {
		this.diag18Cd = diag18Cd;
	}

	public Long getDiag18LvlTypId() {
		return diag18LvlTypId;
	}

	public void setDiag18LvlTypId(Long diag18LvlTypId) {
		this.diag18LvlTypId = diag18LvlTypId;
	}

	public String getDiag18LvlTypCd() {
		return diag18LvlTypCd;
	}

	public void setDiag18LvlTypCd(String diag18LvlTypCd) {
		this.diag18LvlTypCd = diag18LvlTypCd;
	}

	public Integer getDiag18PrrSeqNbr() {
		return diag18PrrSeqNbr;
	}

	public void setDiag18PrrSeqNbr(Integer diag18PrrSeqNbr) {
		this.diag18PrrSeqNbr = diag18PrrSeqNbr;
	}

	public String getDiag18PrsOnAdmisInd() {
		return diag18PrsOnAdmisInd;
	}

	public void setDiag18PrsOnAdmisInd(String diag18PrsOnAdmisInd) {
		this.diag18PrsOnAdmisInd = diag18PrsOnAdmisInd;
	}

	public String getDiag19TypCd() {
		return diag19TypCd;
	}

	public void setDiag19TypCd(String diag19TypCd) {
		this.diag19TypCd = diag19TypCd;
	}

	public Long getDiag19Id() {
		return diag19Id;
	}

	public void setDiag19Id(Long diag19Id) {
		this.diag19Id = diag19Id;
	}

	public String getDiag19Cd() {
		return diag19Cd;
	}

	public void setDiag19Cd(String diag19Cd) {
		this.diag19Cd = diag19Cd;
	}

	public Long getDiag19LvlTypId() {
		return diag19LvlTypId;
	}

	public void setDiag19LvlTypId(Long diag19LvlTypId) {
		this.diag19LvlTypId = diag19LvlTypId;
	}

	public String getDiag19LvlTypCd() {
		return diag19LvlTypCd;
	}

	public void setDiag19LvlTypCd(String diag19LvlTypCd) {
		this.diag19LvlTypCd = diag19LvlTypCd;
	}

	public Integer getDiag19PrrSeqNbr() {
		return diag19PrrSeqNbr;
	}

	public void setDiag19PrrSeqNbr(Integer diag19PrrSeqNbr) {
		this.diag19PrrSeqNbr = diag19PrrSeqNbr;
	}

	public String getDiag19PrsOnAdmisInd() {
		return diag19PrsOnAdmisInd;
	}

	public void setDiag19PrsOnAdmisInd(String diag19PrsOnAdmisInd) {
		this.diag19PrsOnAdmisInd = diag19PrsOnAdmisInd;
	}

	public String getDiag20TypCd() {
		return diag20TypCd;
	}

	public void setDiag20TypCd(String diag20TypCd) {
		this.diag20TypCd = diag20TypCd;
	}

	public Long getDiag20Id() {
		return diag20Id;
	}

	public void setDiag20Id(Long diag20Id) {
		this.diag20Id = diag20Id;
	}

	public String getDiag20Cd() {
		return diag20Cd;
	}

	public void setDiag20Cd(String diag20Cd) {
		this.diag20Cd = diag20Cd;
	}

	public Long getDiag20LvlTypId() {
		return diag20LvlTypId;
	}

	public void setDiag20LvlTypId(Long diag20LvlTypId) {
		this.diag20LvlTypId = diag20LvlTypId;
	}

	public String getDiag20LvlTypCd() {
		return diag20LvlTypCd;
	}

	public void setDiag20LvlTypCd(String diag20LvlTypCd) {
		this.diag20LvlTypCd = diag20LvlTypCd;
	}

	public Integer getDiag20PrrSeqNbr() {
		return diag20PrrSeqNbr;
	}

	public void setDiag20PrrSeqNbr(Integer diag20PrrSeqNbr) {
		this.diag20PrrSeqNbr = diag20PrrSeqNbr;
	}

	public String getDiag20PrsOnAdmisInd() {
		return diag20PrsOnAdmisInd;
	}

	public void setDiag20PrsOnAdmisInd(String diag20PrsOnAdmisInd) {
		this.diag20PrsOnAdmisInd = diag20PrsOnAdmisInd;
	}

	public String getDiag21TypCd() {
		return diag21TypCd;
	}

	public void setDiag21TypCd(String diag21TypCd) {
		this.diag21TypCd = diag21TypCd;
	}

	public Long getDiag21Id() {
		return diag21Id;
	}

	public void setDiag21Id(Long diag21Id) {
		this.diag21Id = diag21Id;
	}

	public String getDiag21Cd() {
		return diag21Cd;
	}

	public void setDiag21Cd(String diag21Cd) {
		this.diag21Cd = diag21Cd;
	}

	public Long getDiag21LvlTypId() {
		return diag21LvlTypId;
	}

	public void setDiag21LvlTypId(Long diag21LvlTypId) {
		this.diag21LvlTypId = diag21LvlTypId;
	}

	public String getDiag21LvlTypCd() {
		return diag21LvlTypCd;
	}

	public void setDiag21LvlTypCd(String diag21LvlTypCd) {
		this.diag21LvlTypCd = diag21LvlTypCd;
	}

	public Integer getDiag21PrrSeqNbr() {
		return diag21PrrSeqNbr;
	}

	public void setDiag21PrrSeqNbr(Integer diag21PrrSeqNbr) {
		this.diag21PrrSeqNbr = diag21PrrSeqNbr;
	}

	public String getDiag21PrsOnAdmisInd() {
		return diag21PrsOnAdmisInd;
	}

	public void setDiag21PrsOnAdmisInd(String diag21PrsOnAdmisInd) {
		this.diag21PrsOnAdmisInd = diag21PrsOnAdmisInd;
	}

	public String getDiag22TypCd() {
		return diag22TypCd;
	}

	public void setDiag22TypCd(String diag22TypCd) {
		this.diag22TypCd = diag22TypCd;
	}

	public Long getDiag22Id() {
		return diag22Id;
	}

	public void setDiag22Id(Long diag22Id) {
		this.diag22Id = diag22Id;
	}

	public String getDiag22Cd() {
		return diag22Cd;
	}

	public void setDiag22Cd(String diag22Cd) {
		this.diag22Cd = diag22Cd;
	}

	public Long getDiag22LvlTypId() {
		return diag22LvlTypId;
	}

	public void setDiag22LvlTypId(Long diag22LvlTypId) {
		this.diag22LvlTypId = diag22LvlTypId;
	}

	public String getDiag22LvlTypCd() {
		return diag22LvlTypCd;
	}

	public void setDiag22LvlTypCd(String diag22LvlTypCd) {
		this.diag22LvlTypCd = diag22LvlTypCd;
	}

	public Integer getDiag22PrrSeqNbr() {
		return diag22PrrSeqNbr;
	}

	public void setDiag22PrrSeqNbr(Integer diag22PrrSeqNbr) {
		this.diag22PrrSeqNbr = diag22PrrSeqNbr;
	}

	public String getDiag22PrsOnAdmisInd() {
		return diag22PrsOnAdmisInd;
	}

	public void setDiag22PrsOnAdmisInd(String diag22PrsOnAdmisInd) {
		this.diag22PrsOnAdmisInd = diag22PrsOnAdmisInd;
	}

	public String getDiag23TypCd() {
		return diag23TypCd;
	}

	public void setDiag23TypCd(String diag23TypCd) {
		this.diag23TypCd = diag23TypCd;
	}

	public Long getDiag23Id() {
		return diag23Id;
	}

	public void setDiag23Id(Long diag23Id) {
		this.diag23Id = diag23Id;
	}

	public String getDiag23Cd() {
		return diag23Cd;
	}

	public void setDiag23Cd(String diag23Cd) {
		this.diag23Cd = diag23Cd;
	}

	public Long getDiag23LvlTypId() {
		return diag23LvlTypId;
	}

	public void setDiag23LvlTypId(Long diag23LvlTypId) {
		this.diag23LvlTypId = diag23LvlTypId;
	}

	public String getDiag23LvlTypCd() {
		return diag23LvlTypCd;
	}

	public void setDiag23LvlTypCd(String diag23LvlTypCd) {
		this.diag23LvlTypCd = diag23LvlTypCd;
	}

	public Integer getDiag23PrrSeqNbr() {
		return diag23PrrSeqNbr;
	}

	public void setDiag23PrrSeqNbr(Integer diag23PrrSeqNbr) {
		this.diag23PrrSeqNbr = diag23PrrSeqNbr;
	}

	public String getDiag23PrsOnAdmisInd() {
		return diag23PrsOnAdmisInd;
	}

	public void setDiag23PrsOnAdmisInd(String diag23PrsOnAdmisInd) {
		this.diag23PrsOnAdmisInd = diag23PrsOnAdmisInd;
	}

	public String getDiag24TypCd() {
		return diag24TypCd;
	}

	public void setDiag24TypCd(String diag24TypCd) {
		this.diag24TypCd = diag24TypCd;
	}

	public Long getDiag24Id() {
		return diag24Id;
	}

	public void setDiag24Id(Long diag24Id) {
		this.diag24Id = diag24Id;
	}

	public String getDiag24Cd() {
		return diag24Cd;
	}

	public void setDiag24Cd(String diag24Cd) {
		this.diag24Cd = diag24Cd;
	}

	public Long getDiag24LvlTypId() {
		return diag24LvlTypId;
	}

	public void setDiag24LvlTypId(Long diag24LvlTypId) {
		this.diag24LvlTypId = diag24LvlTypId;
	}

	public String getDiag24LvlTypCd() {
		return diag24LvlTypCd;
	}

	public void setDiag24LvlTypCd(String diag24LvlTypCd) {
		this.diag24LvlTypCd = diag24LvlTypCd;
	}

	public Integer getDiag24PrrSeqNbr() {
		return diag24PrrSeqNbr;
	}

	public void setDiag24PrrSeqNbr(Integer diag24PrrSeqNbr) {
		this.diag24PrrSeqNbr = diag24PrrSeqNbr;
	}

	public String getDiag24PrsOnAdmisInd() {
		return diag24PrsOnAdmisInd;
	}

	public void setDiag24PrsOnAdmisInd(String diag24PrsOnAdmisInd) {
		this.diag24PrsOnAdmisInd = diag24PrsOnAdmisInd;
	}

	public String getDiag25TypCd() {
		return diag25TypCd;
	}

	public void setDiag25TypCd(String diag25TypCd) {
		this.diag25TypCd = diag25TypCd;
	}

	public Long getDiag25Id() {
		return diag25Id;
	}

	public void setDiag25Id(Long diag25Id) {
		this.diag25Id = diag25Id;
	}

	public String getDiag25Cd() {
		return diag25Cd;
	}

	public void setDiag25Cd(String diag25Cd) {
		this.diag25Cd = diag25Cd;
	}

	public Long getDiag25LvlTypId() {
		return diag25LvlTypId;
	}

	public void setDiag25LvlTypId(Long diag25LvlTypId) {
		this.diag25LvlTypId = diag25LvlTypId;
	}

	public String getDiag25LvlTypCd() {
		return diag25LvlTypCd;
	}

	public void setDiag25LvlTypCd(String diag25LvlTypCd) {
		this.diag25LvlTypCd = diag25LvlTypCd;
	}

	public Integer getDiag25PrrSeqNbr() {
		return diag25PrrSeqNbr;
	}

	public void setDiag25PrrSeqNbr(Integer diag25PrrSeqNbr) {
		this.diag25PrrSeqNbr = diag25PrrSeqNbr;
	}

	public String getDiag25PrsOnAdmisInd() {
		return diag25PrsOnAdmisInd;
	}

	public void setDiag25PrsOnAdmisInd(String diag25PrsOnAdmisInd) {
		this.diag25PrsOnAdmisInd = diag25PrsOnAdmisInd;
	}

	public String getDiag26TypCd() {
		return diag26TypCd;
	}

	public void setDiag26TypCd(String diag26TypCd) {
		this.diag26TypCd = diag26TypCd;
	}

	public Long getDiag26Id() {
		return diag26Id;
	}

	public void setDiag26Id(Long diag26Id) {
		this.diag26Id = diag26Id;
	}

	public String getDiag26Cd() {
		return diag26Cd;
	}

	public void setDiag26Cd(String diag26Cd) {
		this.diag26Cd = diag26Cd;
	}

	public Long getDiag26LvlTypId() {
		return diag26LvlTypId;
	}

	public void setDiag26LvlTypId(Long diag26LvlTypId) {
		this.diag26LvlTypId = diag26LvlTypId;
	}

	public String getDiag26LvlTypCd() {
		return diag26LvlTypCd;
	}

	public void setDiag26LvlTypCd(String diag26LvlTypCd) {
		this.diag26LvlTypCd = diag26LvlTypCd;
	}

	public Integer getDiag26PrrSeqNbr() {
		return diag26PrrSeqNbr;
	}

	public void setDiag26PrrSeqNbr(Integer diag26PrrSeqNbr) {
		this.diag26PrrSeqNbr = diag26PrrSeqNbr;
	}

	public String getDiag26PrsOnAdmisInd() {
		return diag26PrsOnAdmisInd;
	}

	public void setDiag26PrsOnAdmisInd(String diag26PrsOnAdmisInd) {
		this.diag26PrsOnAdmisInd = diag26PrsOnAdmisInd;
	}

	public String getDiag27TypCd() {
		return diag27TypCd;
	}

	public void setDiag27TypCd(String diag27TypCd) {
		this.diag27TypCd = diag27TypCd;
	}

	public Long getDiag27Id() {
		return diag27Id;
	}

	public void setDiag27Id(Long diag27Id) {
		this.diag27Id = diag27Id;
	}

	public String getDiag27Cd() {
		return diag27Cd;
	}

	public void setDiag27Cd(String diag27Cd) {
		this.diag27Cd = diag27Cd;
	}

	public Long getDiag27LvlTypId() {
		return diag27LvlTypId;
	}

	public void setDiag27LvlTypId(Long diag27LvlTypId) {
		this.diag27LvlTypId = diag27LvlTypId;
	}

	public String getDiag27LvlTypCd() {
		return diag27LvlTypCd;
	}

	public void setDiag27LvlTypCd(String diag27LvlTypCd) {
		this.diag27LvlTypCd = diag27LvlTypCd;
	}

	public Integer getDiag27PrrSeqNbr() {
		return diag27PrrSeqNbr;
	}

	public void setDiag27PrrSeqNbr(Integer diag27PrrSeqNbr) {
		this.diag27PrrSeqNbr = diag27PrrSeqNbr;
	}

	public String getDiag27PrsOnAdmisInd() {
		return diag27PrsOnAdmisInd;
	}

	public void setDiag27PrsOnAdmisInd(String diag27PrsOnAdmisInd) {
		this.diag27PrsOnAdmisInd = diag27PrsOnAdmisInd;
	}

	public String getDiag28TypCd() {
		return diag28TypCd;
	}

	public void setDiag28TypCd(String diag28TypCd) {
		this.diag28TypCd = diag28TypCd;
	}

	public Long getDiag28Id() {
		return diag28Id;
	}

	public void setDiag28Id(Long diag28Id) {
		this.diag28Id = diag28Id;
	}

	public String getDiag28Cd() {
		return diag28Cd;
	}

	public void setDiag28Cd(String diag28Cd) {
		this.diag28Cd = diag28Cd;
	}

	public Long getDiag28LvlTypId() {
		return diag28LvlTypId;
	}

	public void setDiag28LvlTypId(Long diag28LvlTypId) {
		this.diag28LvlTypId = diag28LvlTypId;
	}

	public String getDiag28LvlTypCd() {
		return diag28LvlTypCd;
	}

	public void setDiag28LvlTypCd(String diag28LvlTypCd) {
		this.diag28LvlTypCd = diag28LvlTypCd;
	}

	public Integer getDiag28PrrSeqNbr() {
		return diag28PrrSeqNbr;
	}

	public void setDiag28PrrSeqNbr(Integer diag28PrrSeqNbr) {
		this.diag28PrrSeqNbr = diag28PrrSeqNbr;
	}

	public String getDiag28PrsOnAdmisInd() {
		return diag28PrsOnAdmisInd;
	}

	public void setDiag28PrsOnAdmisInd(String diag28PrsOnAdmisInd) {
		this.diag28PrsOnAdmisInd = diag28PrsOnAdmisInd;
	}

	public String getDiag29TypCd() {
		return diag29TypCd;
	}

	public void setDiag29TypCd(String diag29TypCd) {
		this.diag29TypCd = diag29TypCd;
	}

	public Long getDiag29Id() {
		return diag29Id;
	}

	public void setDiag29Id(Long diag29Id) {
		this.diag29Id = diag29Id;
	}

	public String getDiag29Cd() {
		return diag29Cd;
	}

	public void setDiag29Cd(String diag29Cd) {
		this.diag29Cd = diag29Cd;
	}

	public Long getDiag29LvlTypId() {
		return diag29LvlTypId;
	}

	public void setDiag29LvlTypId(Long diag29LvlTypId) {
		this.diag29LvlTypId = diag29LvlTypId;
	}

	public String getDiag29LvlTypCd() {
		return diag29LvlTypCd;
	}

	public void setDiag29LvlTypCd(String diag29LvlTypCd) {
		this.diag29LvlTypCd = diag29LvlTypCd;
	}

	public Integer getDiag29PrrSeqNbr() {
		return diag29PrrSeqNbr;
	}

	public void setDiag29PrrSeqNbr(Integer diag29PrrSeqNbr) {
		this.diag29PrrSeqNbr = diag29PrrSeqNbr;
	}

	public String getDiag29PrsOnAdmisInd() {
		return diag29PrsOnAdmisInd;
	}

	public void setDiag29PrsOnAdmisInd(String diag29PrsOnAdmisInd) {
		this.diag29PrsOnAdmisInd = diag29PrsOnAdmisInd;
	}

	public String getDiag30TypCd() {
		return diag30TypCd;
	}

	public void setDiag30TypCd(String diag30TypCd) {
		this.diag30TypCd = diag30TypCd;
	}

	public Long getDiag30Id() {
		return diag30Id;
	}

	public void setDiag30Id(Long diag30Id) {
		this.diag30Id = diag30Id;
	}

	public String getDiag30Cd() {
		return diag30Cd;
	}

	public void setDiag30Cd(String diag30Cd) {
		this.diag30Cd = diag30Cd;
	}

	public Long getDiag30LvlTypId() {
		return diag30LvlTypId;
	}

	public void setDiag30LvlTypId(Long diag30LvlTypId) {
		this.diag30LvlTypId = diag30LvlTypId;
	}

	public String getDiag30LvlTypCd() {
		return diag30LvlTypCd;
	}

	public void setDiag30LvlTypCd(String diag30LvlTypCd) {
		this.diag30LvlTypCd = diag30LvlTypCd;
	}

	public Integer getDiag30PrrSeqNbr() {
		return diag30PrrSeqNbr;
	}

	public void setDiag30PrrSeqNbr(Integer diag30PrrSeqNbr) {
		this.diag30PrrSeqNbr = diag30PrrSeqNbr;
	}

	public String getDiag30PrsOnAdmisInd() {
		return diag30PrsOnAdmisInd;
	}

	public void setDiag30PrsOnAdmisInd(String diag30PrsOnAdmisInd) {
		this.diag30PrsOnAdmisInd = diag30PrsOnAdmisInd;
	}

	public String getDiag31TypCd() {
		return diag31TypCd;
	}

	public void setDiag31TypCd(String diag31TypCd) {
		this.diag31TypCd = diag31TypCd;
	}

	public Long getDiag31Id() {
		return diag31Id;
	}

	public void setDiag31Id(Long diag31Id) {
		this.diag31Id = diag31Id;
	}

	public String getDiag31Cd() {
		return diag31Cd;
	}

	public void setDiag31Cd(String diag31Cd) {
		this.diag31Cd = diag31Cd;
	}

	public Long getDiag31LvlTypId() {
		return diag31LvlTypId;
	}

	public void setDiag31LvlTypId(Long diag31LvlTypId) {
		this.diag31LvlTypId = diag31LvlTypId;
	}

	public String getDiag31LvlTypCd() {
		return diag31LvlTypCd;
	}

	public void setDiag31LvlTypCd(String diag31LvlTypCd) {
		this.diag31LvlTypCd = diag31LvlTypCd;
	}

	public Integer getDiag31PrrSeqNbr() {
		return diag31PrrSeqNbr;
	}

	public void setDiag31PrrSeqNbr(Integer diag31PrrSeqNbr) {
		this.diag31PrrSeqNbr = diag31PrrSeqNbr;
	}

	public String getDiag31PrsOnAdmisInd() {
		return diag31PrsOnAdmisInd;
	}

	public void setDiag31PrsOnAdmisInd(String diag31PrsOnAdmisInd) {
		this.diag31PrsOnAdmisInd = diag31PrsOnAdmisInd;
	}

	public String getDiag32TypCd() {
		return diag32TypCd;
	}

	public void setDiag32TypCd(String diag32TypCd) {
		this.diag32TypCd = diag32TypCd;
	}

	public Long getDiag32Id() {
		return diag32Id;
	}

	public void setDiag32Id(Long diag32Id) {
		this.diag32Id = diag32Id;
	}

	public String getDiag32Cd() {
		return diag32Cd;
	}

	public void setDiag32Cd(String diag32Cd) {
		this.diag32Cd = diag32Cd;
	}

	public Long getDiag32LvlTypId() {
		return diag32LvlTypId;
	}

	public void setDiag32LvlTypId(Long diag32LvlTypId) {
		this.diag32LvlTypId = diag32LvlTypId;
	}

	public String getDiag32LvlTypCd() {
		return diag32LvlTypCd;
	}

	public void setDiag32LvlTypCd(String diag32LvlTypCd) {
		this.diag32LvlTypCd = diag32LvlTypCd;
	}

	public Integer getDiag32PrrSeqNbr() {
		return diag32PrrSeqNbr;
	}

	public void setDiag32PrrSeqNbr(Integer diag32PrrSeqNbr) {
		this.diag32PrrSeqNbr = diag32PrrSeqNbr;
	}

	public String getDiag32PrsOnAdmisInd() {
		return diag32PrsOnAdmisInd;
	}

	public void setDiag32PrsOnAdmisInd(String diag32PrsOnAdmisInd) {
		this.diag32PrsOnAdmisInd = diag32PrsOnAdmisInd;
	}

	public String getDiag33TypCd() {
		return diag33TypCd;
	}

	public void setDiag33TypCd(String diag33TypCd) {
		this.diag33TypCd = diag33TypCd;
	}

	public Long getDiag33Id() {
		return diag33Id;
	}

	public void setDiag33Id(Long diag33Id) {
		this.diag33Id = diag33Id;
	}

	public String getDiag33Cd() {
		return diag33Cd;
	}

	public void setDiag33Cd(String diag33Cd) {
		this.diag33Cd = diag33Cd;
	}

	public Long getDiag33LvlTypId() {
		return diag33LvlTypId;
	}

	public void setDiag33LvlTypId(Long diag33LvlTypId) {
		this.diag33LvlTypId = diag33LvlTypId;
	}

	public String getDiag33LvlTypCd() {
		return diag33LvlTypCd;
	}

	public void setDiag33LvlTypCd(String diag33LvlTypCd) {
		this.diag33LvlTypCd = diag33LvlTypCd;
	}

	public Integer getDiag33PrrSeqNbr() {
		return diag33PrrSeqNbr;
	}

	public void setDiag33PrrSeqNbr(Integer diag33PrrSeqNbr) {
		this.diag33PrrSeqNbr = diag33PrrSeqNbr;
	}

	public String getDiag33PrsOnAdmisInd() {
		return diag33PrsOnAdmisInd;
	}

	public void setDiag33PrsOnAdmisInd(String diag33PrsOnAdmisInd) {
		this.diag33PrsOnAdmisInd = diag33PrsOnAdmisInd;
	}

	public String getDiag34TypCd() {
		return diag34TypCd;
	}

	public void setDiag34TypCd(String diag34TypCd) {
		this.diag34TypCd = diag34TypCd;
	}

	public Long getDiag34Id() {
		return diag34Id;
	}

	public void setDiag34Id(Long diag34Id) {
		this.diag34Id = diag34Id;
	}

	public String getDiag34Cd() {
		return diag34Cd;
	}

	public void setDiag34Cd(String diag34Cd) {
		this.diag34Cd = diag34Cd;
	}

	public Long getDiag34LvlTypId() {
		return diag34LvlTypId;
	}

	public void setDiag34LvlTypId(Long diag34LvlTypId) {
		this.diag34LvlTypId = diag34LvlTypId;
	}

	public String getDiag34LvlTypCd() {
		return diag34LvlTypCd;
	}

	public void setDiag34LvlTypCd(String diag34LvlTypCd) {
		this.diag34LvlTypCd = diag34LvlTypCd;
	}

	public Integer getDiag34PrrSeqNbr() {
		return diag34PrrSeqNbr;
	}

	public void setDiag34PrrSeqNbr(Integer diag34PrrSeqNbr) {
		this.diag34PrrSeqNbr = diag34PrrSeqNbr;
	}

	public String getDiag34PrsOnAdmisInd() {
		return diag34PrsOnAdmisInd;
	}

	public void setDiag34PrsOnAdmisInd(String diag34PrsOnAdmisInd) {
		this.diag34PrsOnAdmisInd = diag34PrsOnAdmisInd;
	}

	public String getDiag35TypCd() {
		return diag35TypCd;
	}

	public void setDiag35TypCd(String diag35TypCd) {
		this.diag35TypCd = diag35TypCd;
	}

	public Long getDiag35Id() {
		return diag35Id;
	}

	public void setDiag35Id(Long diag35Id) {
		this.diag35Id = diag35Id;
	}

	public String getDiag35Cd() {
		return diag35Cd;
	}

	public void setDiag35Cd(String diag35Cd) {
		this.diag35Cd = diag35Cd;
	}

	public Long getDiag35LvlTypId() {
		return diag35LvlTypId;
	}

	public void setDiag35LvlTypId(Long diag35LvlTypId) {
		this.diag35LvlTypId = diag35LvlTypId;
	}

	public String getDiag35LvlTypCd() {
		return diag35LvlTypCd;
	}

	public void setDiag35LvlTypCd(String diag35LvlTypCd) {
		this.diag35LvlTypCd = diag35LvlTypCd;
	}

	public Integer getDiag35PrrSeqNbr() {
		return diag35PrrSeqNbr;
	}

	public void setDiag35PrrSeqNbr(Integer diag35PrrSeqNbr) {
		this.diag35PrrSeqNbr = diag35PrrSeqNbr;
	}

	public String getDiag35PrsOnAdmisInd() {
		return diag35PrsOnAdmisInd;
	}

	public void setDiag35PrsOnAdmisInd(String diag35PrsOnAdmisInd) {
		this.diag35PrsOnAdmisInd = diag35PrsOnAdmisInd;
	}

	public String getDiag36TypCd() {
		return diag36TypCd;
	}

	public void setDiag36TypCd(String diag36TypCd) {
		this.diag36TypCd = diag36TypCd;
	}

	public Long getDiag36Id() {
		return diag36Id;
	}

	public void setDiag36Id(Long diag36Id) {
		this.diag36Id = diag36Id;
	}

	public String getDiag36Cd() {
		return diag36Cd;
	}

	public void setDiag36Cd(String diag36Cd) {
		this.diag36Cd = diag36Cd;
	}

	public Long getDiag36LvlTypId() {
		return diag36LvlTypId;
	}

	public void setDiag36LvlTypId(Long diag36LvlTypId) {
		this.diag36LvlTypId = diag36LvlTypId;
	}

	public String getDiag36LvlTypCd() {
		return diag36LvlTypCd;
	}

	public void setDiag36LvlTypCd(String diag36LvlTypCd) {
		this.diag36LvlTypCd = diag36LvlTypCd;
	}

	public Integer getDiag36PrrSeqNbr() {
		return diag36PrrSeqNbr;
	}

	public void setDiag36PrrSeqNbr(Integer diag36PrrSeqNbr) {
		this.diag36PrrSeqNbr = diag36PrrSeqNbr;
	}

	public String getDiag36PrsOnAdmisInd() {
		return diag36PrsOnAdmisInd;
	}

	public void setDiag36PrsOnAdmisInd(String diag36PrsOnAdmisInd) {
		this.diag36PrsOnAdmisInd = diag36PrsOnAdmisInd;
	}

	public String getDiag37TypCd() {
		return diag37TypCd;
	}

	public void setDiag37TypCd(String diag37TypCd) {
		this.diag37TypCd = diag37TypCd;
	}

	public Long getDiag37Id() {
		return diag37Id;
	}

	public void setDiag37Id(Long diag37Id) {
		this.diag37Id = diag37Id;
	}

	public String getDiag37Cd() {
		return diag37Cd;
	}

	public void setDiag37Cd(String diag37Cd) {
		this.diag37Cd = diag37Cd;
	}

	public Long getDiag37LvlTypId() {
		return diag37LvlTypId;
	}

	public void setDiag37LvlTypId(Long diag37LvlTypId) {
		this.diag37LvlTypId = diag37LvlTypId;
	}

	public String getDiag37LvlTypCd() {
		return diag37LvlTypCd;
	}

	public void setDiag37LvlTypCd(String diag37LvlTypCd) {
		this.diag37LvlTypCd = diag37LvlTypCd;
	}

	public Integer getDiag37PrrSeqNbr() {
		return diag37PrrSeqNbr;
	}

	public void setDiag37PrrSeqNbr(Integer diag37PrrSeqNbr) {
		this.diag37PrrSeqNbr = diag37PrrSeqNbr;
	}

	public String getDiag37PrsOnAdmisInd() {
		return diag37PrsOnAdmisInd;
	}

	public void setDiag37PrsOnAdmisInd(String diag37PrsOnAdmisInd) {
		this.diag37PrsOnAdmisInd = diag37PrsOnAdmisInd;
	}

	public String getDiag38TypCd() {
		return diag38TypCd;
	}

	public void setDiag38TypCd(String diag38TypCd) {
		this.diag38TypCd = diag38TypCd;
	}

	public Long getDiag38Id() {
		return diag38Id;
	}

	public void setDiag38Id(Long diag38Id) {
		this.diag38Id = diag38Id;
	}

	public String getDiag38Cd() {
		return diag38Cd;
	}

	public void setDiag38Cd(String diag38Cd) {
		this.diag38Cd = diag38Cd;
	}

	public Long getDiag38LvlTypId() {
		return diag38LvlTypId;
	}

	public void setDiag38LvlTypId(Long diag38LvlTypId) {
		this.diag38LvlTypId = diag38LvlTypId;
	}

	public String getDiag38LvlTypCd() {
		return diag38LvlTypCd;
	}

	public void setDiag38LvlTypCd(String diag38LvlTypCd) {
		this.diag38LvlTypCd = diag38LvlTypCd;
	}

	public Integer getDiag38PrrSeqNbr() {
		return diag38PrrSeqNbr;
	}

	public void setDiag38PrrSeqNbr(Integer diag38PrrSeqNbr) {
		this.diag38PrrSeqNbr = diag38PrrSeqNbr;
	}

	public String getDiag38PrsOnAdmisInd() {
		return diag38PrsOnAdmisInd;
	}

	public void setDiag38PrsOnAdmisInd(String diag38PrsOnAdmisInd) {
		this.diag38PrsOnAdmisInd = diag38PrsOnAdmisInd;
	}

	public String getDiag39TypCd() {
		return diag39TypCd;
	}

	public void setDiag39TypCd(String diag39TypCd) {
		this.diag39TypCd = diag39TypCd;
	}

	public Long getDiag39Id() {
		return diag39Id;
	}

	public void setDiag39Id(Long diag39Id) {
		this.diag39Id = diag39Id;
	}

	public String getDiag39Cd() {
		return diag39Cd;
	}

	public void setDiag39Cd(String diag39Cd) {
		this.diag39Cd = diag39Cd;
	}

	public Long getDiag39LvlTypId() {
		return diag39LvlTypId;
	}

	public void setDiag39LvlTypId(Long diag39LvlTypId) {
		this.diag39LvlTypId = diag39LvlTypId;
	}

	public String getDiag39LvlTypCd() {
		return diag39LvlTypCd;
	}

	public void setDiag39LvlTypCd(String diag39LvlTypCd) {
		this.diag39LvlTypCd = diag39LvlTypCd;
	}

	public Integer getDiag39PrrSeqNbr() {
		return diag39PrrSeqNbr;
	}

	public void setDiag39PrrSeqNbr(Integer diag39PrrSeqNbr) {
		this.diag39PrrSeqNbr = diag39PrrSeqNbr;
	}

	public String getDiag39PrsOnAdmisInd() {
		return diag39PrsOnAdmisInd;
	}

	public void setDiag39PrsOnAdmisInd(String diag39PrsOnAdmisInd) {
		this.diag39PrsOnAdmisInd = diag39PrsOnAdmisInd;
	}

	public String getDiag40TypCd() {
		return diag40TypCd;
	}

	public void setDiag40TypCd(String diag40TypCd) {
		this.diag40TypCd = diag40TypCd;
	}

	public Long getDiag40Id() {
		return diag40Id;
	}

	public void setDiag40Id(Long diag40Id) {
		this.diag40Id = diag40Id;
	}

	public String getDiag40Cd() {
		return diag40Cd;
	}

	public void setDiag40Cd(String diag40Cd) {
		this.diag40Cd = diag40Cd;
	}

	public Long getDiag40LvlTypId() {
		return diag40LvlTypId;
	}

	public void setDiag40LvlTypId(Long diag40LvlTypId) {
		this.diag40LvlTypId = diag40LvlTypId;
	}

	public String getDiag40LvlTypCd() {
		return diag40LvlTypCd;
	}

	public void setDiag40LvlTypCd(String diag40LvlTypCd) {
		this.diag40LvlTypCd = diag40LvlTypCd;
	}

	public Integer getDiag40PrrSeqNbr() {
		return diag40PrrSeqNbr;
	}

	public void setDiag40PrrSeqNbr(Integer diag40PrrSeqNbr) {
		this.diag40PrrSeqNbr = diag40PrrSeqNbr;
	}

	public String getDiag40PrsOnAdmisInd() {
		return diag40PrsOnAdmisInd;
	}

	public void setDiag40PrsOnAdmisInd(String diag40PrsOnAdmisInd) {
		this.diag40PrsOnAdmisInd = diag40PrsOnAdmisInd;
	}

	public String getDiag41TypCd() {
		return diag41TypCd;
	}

	public void setDiag41TypCd(String diag41TypCd) {
		this.diag41TypCd = diag41TypCd;
	}

	public Long getDiag41Id() {
		return diag41Id;
	}

	public void setDiag41Id(Long diag41Id) {
		this.diag41Id = diag41Id;
	}

	public String getDiag41Cd() {
		return diag41Cd;
	}

	public void setDiag41Cd(String diag41Cd) {
		this.diag41Cd = diag41Cd;
	}

	public Long getDiag41LvlTypId() {
		return diag41LvlTypId;
	}

	public void setDiag41LvlTypId(Long diag41LvlTypId) {
		this.diag41LvlTypId = diag41LvlTypId;
	}

	public String getDiag41LvlTypCd() {
		return diag41LvlTypCd;
	}

	public void setDiag41LvlTypCd(String diag41LvlTypCd) {
		this.diag41LvlTypCd = diag41LvlTypCd;
	}

	public Integer getDiag41PrrSeqNbr() {
		return diag41PrrSeqNbr;
	}

	public void setDiag41PrrSeqNbr(Integer diag41PrrSeqNbr) {
		this.diag41PrrSeqNbr = diag41PrrSeqNbr;
	}

	public String getDiag41PrsOnAdmisInd() {
		return diag41PrsOnAdmisInd;
	}

	public void setDiag41PrsOnAdmisInd(String diag41PrsOnAdmisInd) {
		this.diag41PrsOnAdmisInd = diag41PrsOnAdmisInd;
	}

	public String getDiag42TypCd() {
		return diag42TypCd;
	}

	public void setDiag42TypCd(String diag42TypCd) {
		this.diag42TypCd = diag42TypCd;
	}

	public Long getDiag42Id() {
		return diag42Id;
	}

	public void setDiag42Id(Long diag42Id) {
		this.diag42Id = diag42Id;
	}

	public String getDiag42Cd() {
		return diag42Cd;
	}

	public void setDiag42Cd(String diag42Cd) {
		this.diag42Cd = diag42Cd;
	}

	public Long getDiag42LvlTypId() {
		return diag42LvlTypId;
	}

	public void setDiag42LvlTypId(Long diag42LvlTypId) {
		this.diag42LvlTypId = diag42LvlTypId;
	}

	public String getDiag42LvlTypCd() {
		return diag42LvlTypCd;
	}

	public void setDiag42LvlTypCd(String diag42LvlTypCd) {
		this.diag42LvlTypCd = diag42LvlTypCd;
	}

	public Integer getDiag42PrrSeqNbr() {
		return diag42PrrSeqNbr;
	}

	public void setDiag42PrrSeqNbr(Integer diag42PrrSeqNbr) {
		this.diag42PrrSeqNbr = diag42PrrSeqNbr;
	}

	public String getDiag42PrsOnAdmisInd() {
		return diag42PrsOnAdmisInd;
	}

	public void setDiag42PrsOnAdmisInd(String diag42PrsOnAdmisInd) {
		this.diag42PrsOnAdmisInd = diag42PrsOnAdmisInd;
	}

	public String getDiag43TypCd() {
		return diag43TypCd;
	}

	public void setDiag43TypCd(String diag43TypCd) {
		this.diag43TypCd = diag43TypCd;
	}

	public Long getDiag43Id() {
		return diag43Id;
	}

	public void setDiag43Id(Long diag43Id) {
		this.diag43Id = diag43Id;
	}

	public String getDiag43Cd() {
		return diag43Cd;
	}

	public void setDiag43Cd(String diag43Cd) {
		this.diag43Cd = diag43Cd;
	}

	public Long getDiag43LvlTypId() {
		return diag43LvlTypId;
	}

	public void setDiag43LvlTypId(Long diag43LvlTypId) {
		this.diag43LvlTypId = diag43LvlTypId;
	}

	public String getDiag43LvlTypCd() {
		return diag43LvlTypCd;
	}

	public void setDiag43LvlTypCd(String diag43LvlTypCd) {
		this.diag43LvlTypCd = diag43LvlTypCd;
	}

	public Integer getDiag43PrrSeqNbr() {
		return diag43PrrSeqNbr;
	}

	public void setDiag43PrrSeqNbr(Integer diag43PrrSeqNbr) {
		this.diag43PrrSeqNbr = diag43PrrSeqNbr;
	}

	public String getDiag43PrsOnAdmisInd() {
		return diag43PrsOnAdmisInd;
	}

	public void setDiag43PrsOnAdmisInd(String diag43PrsOnAdmisInd) {
		this.diag43PrsOnAdmisInd = diag43PrsOnAdmisInd;
	}

	public String getDiag44TypCd() {
		return diag44TypCd;
	}

	public void setDiag44TypCd(String diag44TypCd) {
		this.diag44TypCd = diag44TypCd;
	}

	public Long getDiag44Id() {
		return diag44Id;
	}

	public void setDiag44Id(Long diag44Id) {
		this.diag44Id = diag44Id;
	}

	public String getDiag44Cd() {
		return diag44Cd;
	}

	public void setDiag44Cd(String diag44Cd) {
		this.diag44Cd = diag44Cd;
	}

	public Long getDiag44LvlTypId() {
		return diag44LvlTypId;
	}

	public void setDiag44LvlTypId(Long diag44LvlTypId) {
		this.diag44LvlTypId = diag44LvlTypId;
	}

	public String getDiag44LvlTypCd() {
		return diag44LvlTypCd;
	}

	public void setDiag44LvlTypCd(String diag44LvlTypCd) {
		this.diag44LvlTypCd = diag44LvlTypCd;
	}

	public Integer getDiag44PrrSeqNbr() {
		return diag44PrrSeqNbr;
	}

	public void setDiag44PrrSeqNbr(Integer diag44PrrSeqNbr) {
		this.diag44PrrSeqNbr = diag44PrrSeqNbr;
	}

	public String getDiag44PrsOnAdmisInd() {
		return diag44PrsOnAdmisInd;
	}

	public void setDiag44PrsOnAdmisInd(String diag44PrsOnAdmisInd) {
		this.diag44PrsOnAdmisInd = diag44PrsOnAdmisInd;
	}

	public String getDiag45TypCd() {
		return diag45TypCd;
	}

	public void setDiag45TypCd(String diag45TypCd) {
		this.diag45TypCd = diag45TypCd;
	}

	public Long getDiag45Id() {
		return diag45Id;
	}

	public void setDiag45Id(Long diag45Id) {
		this.diag45Id = diag45Id;
	}

	public String getDiag45Cd() {
		return diag45Cd;
	}

	public void setDiag45Cd(String diag45Cd) {
		this.diag45Cd = diag45Cd;
	}

	public Long getDiag45LvlTypId() {
		return diag45LvlTypId;
	}

	public void setDiag45LvlTypId(Long diag45LvlTypId) {
		this.diag45LvlTypId = diag45LvlTypId;
	}

	public String getDiag45LvlTypCd() {
		return diag45LvlTypCd;
	}

	public void setDiag45LvlTypCd(String diag45LvlTypCd) {
		this.diag45LvlTypCd = diag45LvlTypCd;
	}

	public Integer getDiag45PrrSeqNbr() {
		return diag45PrrSeqNbr;
	}

	public void setDiag45PrrSeqNbr(Integer diag45PrrSeqNbr) {
		this.diag45PrrSeqNbr = diag45PrrSeqNbr;
	}

	public String getDiag45PrsOnAdmisInd() {
		return diag45PrsOnAdmisInd;
	}

	public void setDiag45PrsOnAdmisInd(String diag45PrsOnAdmisInd) {
		this.diag45PrsOnAdmisInd = diag45PrsOnAdmisInd;
	}

	public String getDiag46TypCd() {
		return diag46TypCd;
	}

	public void setDiag46TypCd(String diag46TypCd) {
		this.diag46TypCd = diag46TypCd;
	}

	public Long getDiag46Id() {
		return diag46Id;
	}

	public void setDiag46Id(Long diag46Id) {
		this.diag46Id = diag46Id;
	}

	public String getDiag46Cd() {
		return diag46Cd;
	}

	public void setDiag46Cd(String diag46Cd) {
		this.diag46Cd = diag46Cd;
	}

	public Long getDiag46LvlTypId() {
		return diag46LvlTypId;
	}

	public void setDiag46LvlTypId(Long diag46LvlTypId) {
		this.diag46LvlTypId = diag46LvlTypId;
	}

	public String getDiag46LvlTypCd() {
		return diag46LvlTypCd;
	}

	public void setDiag46LvlTypCd(String diag46LvlTypCd) {
		this.diag46LvlTypCd = diag46LvlTypCd;
	}

	public Integer getDiag46PrrSeqNbr() {
		return diag46PrrSeqNbr;
	}

	public void setDiag46PrrSeqNbr(Integer diag46PrrSeqNbr) {
		this.diag46PrrSeqNbr = diag46PrrSeqNbr;
	}

	public String getDiag46PrsOnAdmisInd() {
		return diag46PrsOnAdmisInd;
	}

	public void setDiag46PrsOnAdmisInd(String diag46PrsOnAdmisInd) {
		this.diag46PrsOnAdmisInd = diag46PrsOnAdmisInd;
	}

	public String getDiag47TypCd() {
		return diag47TypCd;
	}

	public void setDiag47TypCd(String diag47TypCd) {
		this.diag47TypCd = diag47TypCd;
	}

	public Long getDiag47Id() {
		return diag47Id;
	}

	public void setDiag47Id(Long diag47Id) {
		this.diag47Id = diag47Id;
	}

	public String getDiag47Cd() {
		return diag47Cd;
	}

	public void setDiag47Cd(String diag47Cd) {
		this.diag47Cd = diag47Cd;
	}

	public Long getDiag47LvlTypId() {
		return diag47LvlTypId;
	}

	public void setDiag47LvlTypId(Long diag47LvlTypId) {
		this.diag47LvlTypId = diag47LvlTypId;
	}

	public String getDiag47LvlTypCd() {
		return diag47LvlTypCd;
	}

	public void setDiag47LvlTypCd(String diag47LvlTypCd) {
		this.diag47LvlTypCd = diag47LvlTypCd;
	}

	public Integer getDiag47PrrSeqNbr() {
		return diag47PrrSeqNbr;
	}

	public void setDiag47PrrSeqNbr(Integer diag47PrrSeqNbr) {
		this.diag47PrrSeqNbr = diag47PrrSeqNbr;
	}

	public String getDiag47PrsOnAdmisInd() {
		return diag47PrsOnAdmisInd;
	}

	public void setDiag47PrsOnAdmisInd(String diag47PrsOnAdmisInd) {
		this.diag47PrsOnAdmisInd = diag47PrsOnAdmisInd;
	}

	public String getDiag48TypCd() {
		return diag48TypCd;
	}

	public void setDiag48TypCd(String diag48TypCd) {
		this.diag48TypCd = diag48TypCd;
	}

	public Long getDiag48Id() {
		return diag48Id;
	}

	public void setDiag48Id(Long diag48Id) {
		this.diag48Id = diag48Id;
	}

	public String getDiag48Cd() {
		return diag48Cd;
	}

	public void setDiag48Cd(String diag48Cd) {
		this.diag48Cd = diag48Cd;
	}

	public Long getDiag48LvlTypId() {
		return diag48LvlTypId;
	}

	public void setDiag48LvlTypId(Long diag48LvlTypId) {
		this.diag48LvlTypId = diag48LvlTypId;
	}

	public String getDiag48LvlTypCd() {
		return diag48LvlTypCd;
	}

	public void setDiag48LvlTypCd(String diag48LvlTypCd) {
		this.diag48LvlTypCd = diag48LvlTypCd;
	}

	public Integer getDiag48PrrSeqNbr() {
		return diag48PrrSeqNbr;
	}

	public void setDiag48PrrSeqNbr(Integer diag48PrrSeqNbr) {
		this.diag48PrrSeqNbr = diag48PrrSeqNbr;
	}

	public String getDiag48PrsOnAdmisInd() {
		return diag48PrsOnAdmisInd;
	}

	public void setDiag48PrsOnAdmisInd(String diag48PrsOnAdmisInd) {
		this.diag48PrsOnAdmisInd = diag48PrsOnAdmisInd;
	}

	public String getDiag49TypCd() {
		return diag49TypCd;
	}

	public void setDiag49TypCd(String diag49TypCd) {
		this.diag49TypCd = diag49TypCd;
	}

	public Long getDiag49Id() {
		return diag49Id;
	}

	public void setDiag49Id(Long diag49Id) {
		this.diag49Id = diag49Id;
	}

	public String getDiag49Cd() {
		return diag49Cd;
	}

	public void setDiag49Cd(String diag49Cd) {
		this.diag49Cd = diag49Cd;
	}

	public Long getDiag49LvlTypId() {
		return diag49LvlTypId;
	}

	public void setDiag49LvlTypId(Long diag49LvlTypId) {
		this.diag49LvlTypId = diag49LvlTypId;
	}

	public String getDiag49LvlTypCd() {
		return diag49LvlTypCd;
	}

	public void setDiag49LvlTypCd(String diag49LvlTypCd) {
		this.diag49LvlTypCd = diag49LvlTypCd;
	}

	public Integer getDiag49PrrSeqNbr() {
		return diag49PrrSeqNbr;
	}

	public void setDiag49PrrSeqNbr(Integer diag49PrrSeqNbr) {
		this.diag49PrrSeqNbr = diag49PrrSeqNbr;
	}

	public String getDiag49PrsOnAdmisInd() {
		return diag49PrsOnAdmisInd;
	}

	public void setDiag49PrsOnAdmisInd(String diag49PrsOnAdmisInd) {
		this.diag49PrsOnAdmisInd = diag49PrsOnAdmisInd;
	}

	public String getDiag50TypCd() {
		return diag50TypCd;
	}

	public void setDiag50TypCd(String diag50TypCd) {
		this.diag50TypCd = diag50TypCd;
	}

	public Long getDiag50Id() {
		return diag50Id;
	}

	public void setDiag50Id(Long diag50Id) {
		this.diag50Id = diag50Id;
	}

	public String getDiag50Cd() {
		return diag50Cd;
	}

	public void setDiag50Cd(String diag50Cd) {
		this.diag50Cd = diag50Cd;
	}

	public Long getDiag50LvlTypId() {
		return diag50LvlTypId;
	}

	public void setDiag50LvlTypId(Long diag50LvlTypId) {
		this.diag50LvlTypId = diag50LvlTypId;
	}

	public String getDiag50LvlTypCd() {
		return diag50LvlTypCd;
	}

	public void setDiag50LvlTypCd(String diag50LvlTypCd) {
		this.diag50LvlTypCd = diag50LvlTypCd;
	}

	public Integer getDiag50PrrSeqNbr() {
		return diag50PrrSeqNbr;
	}

	public void setDiag50PrrSeqNbr(Integer diag50PrrSeqNbr) {
		this.diag50PrrSeqNbr = diag50PrrSeqNbr;
	}

	public String getDiag50PrsOnAdmisInd() {
		return diag50PrsOnAdmisInd;
	}

	public void setDiag50PrsOnAdmisInd(String diag50PrsOnAdmisInd) {
		this.diag50PrsOnAdmisInd = diag50PrsOnAdmisInd;
	}

	public Long getIcdProc1Id() {
		return icdProc1Id;
	}

	public void setIcdProc1Id(Long icdProc1Id) {
		this.icdProc1Id = icdProc1Id;
	}

	public String getIcdProc1VerCd() {
		return icdProc1VerCd;
	}

	public void setIcdProc1VerCd(String icdProc1VerCd) {
		this.icdProc1VerCd = icdProc1VerCd;
	}

	public String getIcdProc1Cd() {
		return icdProc1Cd;
	}

	public void setIcdProc1Cd(String icdProc1Cd) {
		this.icdProc1Cd = icdProc1Cd;
	}

	public Date getIcdProc1Dt() {
		return icdProc1Dt;
	}

	public void setIcdProc1Dt(Date icdProc1Dt) {
		this.icdProc1Dt = icdProc1Dt;
	}

	public String getPrinProc1Ind() {
		return prinProc1Ind;
	}

	public void setPrinProc1Ind(String prinProc1Ind) {
		this.prinProc1Ind = prinProc1Ind;
	}

	public Long getIcdProc2Id() {
		return icdProc2Id;
	}

	public void setIcdProc2Id(Long icdProc2Id) {
		this.icdProc2Id = icdProc2Id;
	}

	public String getIcdProc2VerCd() {
		return icdProc2VerCd;
	}

	public void setIcdProc2VerCd(String icdProc2VerCd) {
		this.icdProc2VerCd = icdProc2VerCd;
	}

	public String getIcdProc2Cd() {
		return icdProc2Cd;
	}

	public void setIcdProc2Cd(String icdProc2Cd) {
		this.icdProc2Cd = icdProc2Cd;
	}

	public Date getIcdProc2Dt() {
		return icdProc2Dt;
	}

	public void setIcdProc2Dt(Date icdProc2Dt) {
		this.icdProc2Dt = icdProc2Dt;
	}

	public String getPrinProc2Ind() {
		return prinProc2Ind;
	}

	public void setPrinProc2Ind(String prinProc2Ind) {
		this.prinProc2Ind = prinProc2Ind;
	}

	public Long getIcdProc3Id() {
		return icdProc3Id;
	}

	public void setIcdProc3Id(Long icdProc3Id) {
		this.icdProc3Id = icdProc3Id;
	}

	public String getIcdProc3VerCd() {
		return icdProc3VerCd;
	}

	public void setIcdProc3VerCd(String icdProc3VerCd) {
		this.icdProc3VerCd = icdProc3VerCd;
	}

	public String getIcdProc3Cd() {
		return icdProc3Cd;
	}

	public void setIcdProc3Cd(String icdProc3Cd) {
		this.icdProc3Cd = icdProc3Cd;
	}

	public Date getIcdProc3Dt() {
		return icdProc3Dt;
	}

	public void setIcdProc3Dt(Date icdProc3Dt) {
		this.icdProc3Dt = icdProc3Dt;
	}

	public String getPrinProc3Ind() {
		return prinProc3Ind;
	}

	public void setPrinProc3Ind(String prinProc3Ind) {
		this.prinProc3Ind = prinProc3Ind;
	}

	public Long getIcdProc4Id() {
		return icdProc4Id;
	}

	public void setIcdProc4Id(Long icdProc4Id) {
		this.icdProc4Id = icdProc4Id;
	}

	public String getIcdProc4VerCd() {
		return icdProc4VerCd;
	}

	public void setIcdProc4VerCd(String icdProc4VerCd) {
		this.icdProc4VerCd = icdProc4VerCd;
	}

	public String getIcdProc4Cd() {
		return icdProc4Cd;
	}

	public void setIcdProc4Cd(String icdProc4Cd) {
		this.icdProc4Cd = icdProc4Cd;
	}

	public Date getIcdProc4Dt() {
		return icdProc4Dt;
	}

	public void setIcdProc4Dt(Date icdProc4Dt) {
		this.icdProc4Dt = icdProc4Dt;
	}

	public String getPrinProc4Ind() {
		return prinProc4Ind;
	}

	public void setPrinProc4Ind(String prinProc4Ind) {
		this.prinProc4Ind = prinProc4Ind;
	}

	public Long getIcdProc5Id() {
		return icdProc5Id;
	}

	public void setIcdProc5Id(Long icdProc5Id) {
		this.icdProc5Id = icdProc5Id;
	}

	public String getIcdProc5VerCd() {
		return icdProc5VerCd;
	}

	public void setIcdProc5VerCd(String icdProc5VerCd) {
		this.icdProc5VerCd = icdProc5VerCd;
	}

	public String getIcdProc5Cd() {
		return icdProc5Cd;
	}

	public void setIcdProc5Cd(String icdProc5Cd) {
		this.icdProc5Cd = icdProc5Cd;
	}

	public Date getIcdProc5Dt() {
		return icdProc5Dt;
	}

	public void setIcdProc5Dt(Date icdProc5Dt) {
		this.icdProc5Dt = icdProc5Dt;
	}

	public String getPrinProc5Ind() {
		return prinProc5Ind;
	}

	public void setPrinProc5Ind(String prinProc5Ind) {
		this.prinProc5Ind = prinProc5Ind;
	}

	public Long getIcdProc6Id() {
		return icdProc6Id;
	}

	public void setIcdProc6Id(Long icdProc6Id) {
		this.icdProc6Id = icdProc6Id;
	}

	public String getIcdProc6VerCd() {
		return icdProc6VerCd;
	}

	public void setIcdProc6VerCd(String icdProc6VerCd) {
		this.icdProc6VerCd = icdProc6VerCd;
	}

	public String getIcdProc6Cd() {
		return icdProc6Cd;
	}

	public void setIcdProc6Cd(String icdProc6Cd) {
		this.icdProc6Cd = icdProc6Cd;
	}

	public Date getIcdProc6Dt() {
		return icdProc6Dt;
	}

	public void setIcdProc6Dt(Date icdProc6Dt) {
		this.icdProc6Dt = icdProc6Dt;
	}

	public String getPrinProc6Ind() {
		return prinProc6Ind;
	}

	public void setPrinProc6Ind(String prinProc6Ind) {
		this.prinProc6Ind = prinProc6Ind;
	}

	public Long getIcdProc7Id() {
		return icdProc7Id;
	}

	public void setIcdProc7Id(Long icdProc7Id) {
		this.icdProc7Id = icdProc7Id;
	}

	public String getIcdProc7VerCd() {
		return icdProc7VerCd;
	}

	public void setIcdProc7VerCd(String icdProc7VerCd) {
		this.icdProc7VerCd = icdProc7VerCd;
	}

	public String getIcdProc7Cd() {
		return icdProc7Cd;
	}

	public void setIcdProc7Cd(String icdProc7Cd) {
		this.icdProc7Cd = icdProc7Cd;
	}

	public Date getIcdProc7Dt() {
		return icdProc7Dt;
	}

	public void setIcdProc7Dt(Date icdProc7Dt) {
		this.icdProc7Dt = icdProc7Dt;
	}

	public String getPrinProc7Ind() {
		return prinProc7Ind;
	}

	public void setPrinProc7Ind(String prinProc7Ind) {
		this.prinProc7Ind = prinProc7Ind;
	}

	public Long getIcdProc8Id() {
		return icdProc8Id;
	}

	public void setIcdProc8Id(Long icdProc8Id) {
		this.icdProc8Id = icdProc8Id;
	}

	public String getIcdProc8VerCd() {
		return icdProc8VerCd;
	}

	public void setIcdProc8VerCd(String icdProc8VerCd) {
		this.icdProc8VerCd = icdProc8VerCd;
	}

	public String getIcdProc8Cd() {
		return icdProc8Cd;
	}

	public void setIcdProc8Cd(String icdProc8Cd) {
		this.icdProc8Cd = icdProc8Cd;
	}

	public Date getIcdProc8Dt() {
		return icdProc8Dt;
	}

	public void setIcdProc8Dt(Date icdProc8Dt) {
		this.icdProc8Dt = icdProc8Dt;
	}

	public String getPrinProc8Ind() {
		return prinProc8Ind;
	}

	public void setPrinProc8Ind(String prinProc8Ind) {
		this.prinProc8Ind = prinProc8Ind;
	}

	public Long getIcdProc9Id() {
		return icdProc9Id;
	}

	public void setIcdProc9Id(Long icdProc9Id) {
		this.icdProc9Id = icdProc9Id;
	}

	public String getIcdProc9VerCd() {
		return icdProc9VerCd;
	}

	public void setIcdProc9VerCd(String icdProc9VerCd) {
		this.icdProc9VerCd = icdProc9VerCd;
	}

	public String getIcdProc9Cd() {
		return icdProc9Cd;
	}

	public void setIcdProc9Cd(String icdProc9Cd) {
		this.icdProc9Cd = icdProc9Cd;
	}

	public Date getIcdProc9Dt() {
		return icdProc9Dt;
	}

	public void setIcdProc9Dt(Date icdProc9Dt) {
		this.icdProc9Dt = icdProc9Dt;
	}

	public String getPrinProc9Ind() {
		return prinProc9Ind;
	}

	public void setPrinProc9Ind(String prinProc9Ind) {
		this.prinProc9Ind = prinProc9Ind;
	}

	public Long getIcdProc10Id() {
		return icdProc10Id;
	}

	public void setIcdProc10Id(Long icdProc10Id) {
		this.icdProc10Id = icdProc10Id;
	}

	public String getIcdProc10VerCd() {
		return icdProc10VerCd;
	}

	public void setIcdProc10VerCd(String icdProc10VerCd) {
		this.icdProc10VerCd = icdProc10VerCd;
	}

	public String getIcdProc10Cd() {
		return icdProc10Cd;
	}

	public void setIcdProc10Cd(String icdProc10Cd) {
		this.icdProc10Cd = icdProc10Cd;
	}

	public Date getIcdProc10Dt() {
		return icdProc10Dt;
	}

	public void setIcdProc10Dt(Date icdProc10Dt) {
		this.icdProc10Dt = icdProc10Dt;
	}

	public String getPrinProc10Ind() {
		return prinProc10Ind;
	}

	public void setPrinProc10Ind(String prinProc10Ind) {
		this.prinProc10Ind = prinProc10Ind;
	}

	public Long getIcdProc11Id() {
		return icdProc11Id;
	}

	public void setIcdProc11Id(Long icdProc11Id) {
		this.icdProc11Id = icdProc11Id;
	}

	public String getIcdProc11VerCd() {
		return icdProc11VerCd;
	}

	public void setIcdProc11VerCd(String icdProc11VerCd) {
		this.icdProc11VerCd = icdProc11VerCd;
	}

	public String getIcdProc11Cd() {
		return icdProc11Cd;
	}

	public void setIcdProc11Cd(String icdProc11Cd) {
		this.icdProc11Cd = icdProc11Cd;
	}

	public Date getIcdProc11Dt() {
		return icdProc11Dt;
	}

	public void setIcdProc11Dt(Date icdProc11Dt) {
		this.icdProc11Dt = icdProc11Dt;
	}

	public String getPrinProc11Ind() {
		return prinProc11Ind;
	}

	public void setPrinProc11Ind(String prinProc11Ind) {
		this.prinProc11Ind = prinProc11Ind;
	}

	public Long getIcdProc12Id() {
		return icdProc12Id;
	}

	public void setIcdProc12Id(Long icdProc12Id) {
		this.icdProc12Id = icdProc12Id;
	}

	public String getIcdProc12VerCd() {
		return icdProc12VerCd;
	}

	public void setIcdProc12VerCd(String icdProc12VerCd) {
		this.icdProc12VerCd = icdProc12VerCd;
	}

	public String getIcdProc12Cd() {
		return icdProc12Cd;
	}

	public void setIcdProc12Cd(String icdProc12Cd) {
		this.icdProc12Cd = icdProc12Cd;
	}

	public Date getIcdProc12Dt() {
		return icdProc12Dt;
	}

	public void setIcdProc12Dt(Date icdProc12Dt) {
		this.icdProc12Dt = icdProc12Dt;
	}

	public String getPrinProc12Ind() {
		return prinProc12Ind;
	}

	public void setPrinProc12Ind(String prinProc12Ind) {
		this.prinProc12Ind = prinProc12Ind;
	}

	public Long getIcdProc13Id() {
		return icdProc13Id;
	}

	public void setIcdProc13Id(Long icdProc13Id) {
		this.icdProc13Id = icdProc13Id;
	}

	public String getIcdProc13VerCd() {
		return icdProc13VerCd;
	}

	public void setIcdProc13VerCd(String icdProc13VerCd) {
		this.icdProc13VerCd = icdProc13VerCd;
	}

	public String getIcdProc13Cd() {
		return icdProc13Cd;
	}

	public void setIcdProc13Cd(String icdProc13Cd) {
		this.icdProc13Cd = icdProc13Cd;
	}

	public Date getIcdProc13Dt() {
		return icdProc13Dt;
	}

	public void setIcdProc13Dt(Date icdProc13Dt) {
		this.icdProc13Dt = icdProc13Dt;
	}

	public String getPrinProc13Ind() {
		return prinProc13Ind;
	}

	public void setPrinProc13Ind(String prinProc13Ind) {
		this.prinProc13Ind = prinProc13Ind;
	}

	public Long getIcdProc14Id() {
		return icdProc14Id;
	}

	public void setIcdProc14Id(Long icdProc14Id) {
		this.icdProc14Id = icdProc14Id;
	}

	public String getIcdProc14VerCd() {
		return icdProc14VerCd;
	}

	public void setIcdProc14VerCd(String icdProc14VerCd) {
		this.icdProc14VerCd = icdProc14VerCd;
	}

	public String getIcdProc14Cd() {
		return icdProc14Cd;
	}

	public void setIcdProc14Cd(String icdProc14Cd) {
		this.icdProc14Cd = icdProc14Cd;
	}

	public Date getIcdProc14Dt() {
		return icdProc14Dt;
	}

	public void setIcdProc14Dt(Date icdProc14Dt) {
		this.icdProc14Dt = icdProc14Dt;
	}

	public String getPrinProc14Ind() {
		return prinProc14Ind;
	}

	public void setPrinProc14Ind(String prinProc14Ind) {
		this.prinProc14Ind = prinProc14Ind;
	}

	public Long getIcdProc15Id() {
		return icdProc15Id;
	}

	public void setIcdProc15Id(Long icdProc15Id) {
		this.icdProc15Id = icdProc15Id;
	}

	public String getIcdProc15VerCd() {
		return icdProc15VerCd;
	}

	public void setIcdProc15VerCd(String icdProc15VerCd) {
		this.icdProc15VerCd = icdProc15VerCd;
	}

	public String getIcdProc15Cd() {
		return icdProc15Cd;
	}

	public void setIcdProc15Cd(String icdProc15Cd) {
		this.icdProc15Cd = icdProc15Cd;
	}

	public Date getIcdProc15Dt() {
		return icdProc15Dt;
	}

	public void setIcdProc15Dt(Date icdProc15Dt) {
		this.icdProc15Dt = icdProc15Dt;
	}

	public String getPrinProc15Ind() {
		return prinProc15Ind;
	}

	public void setPrinProc15Ind(String prinProc15Ind) {
		this.prinProc15Ind = prinProc15Ind;
	}

	public Long getIcdProc16Id() {
		return icdProc16Id;
	}

	public void setIcdProc16Id(Long icdProc16Id) {
		this.icdProc16Id = icdProc16Id;
	}

	public String getIcdProc16VerCd() {
		return icdProc16VerCd;
	}

	public void setIcdProc16VerCd(String icdProc16VerCd) {
		this.icdProc16VerCd = icdProc16VerCd;
	}

	public String getIcdProc16Cd() {
		return icdProc16Cd;
	}

	public void setIcdProc16Cd(String icdProc16Cd) {
		this.icdProc16Cd = icdProc16Cd;
	}

	public Date getIcdProc16Dt() {
		return icdProc16Dt;
	}

	public void setIcdProc16Dt(Date icdProc16Dt) {
		this.icdProc16Dt = icdProc16Dt;
	}

	public String getPrinProc16Ind() {
		return prinProc16Ind;
	}

	public void setPrinProc16Ind(String prinProc16Ind) {
		this.prinProc16Ind = prinProc16Ind;
	}

	public Long getIcdProc17Id() {
		return icdProc17Id;
	}

	public void setIcdProc17Id(Long icdProc17Id) {
		this.icdProc17Id = icdProc17Id;
	}

	public String getIcdProc17VerCd() {
		return icdProc17VerCd;
	}

	public void setIcdProc17VerCd(String icdProc17VerCd) {
		this.icdProc17VerCd = icdProc17VerCd;
	}

	public String getIcdProc17Cd() {
		return icdProc17Cd;
	}

	public void setIcdProc17Cd(String icdProc17Cd) {
		this.icdProc17Cd = icdProc17Cd;
	}

	public Date getIcdProc17Dt() {
		return icdProc17Dt;
	}

	public void setIcdProc17Dt(Date icdProc17Dt) {
		this.icdProc17Dt = icdProc17Dt;
	}

	public String getPrinProc17Ind() {
		return prinProc17Ind;
	}

	public void setPrinProc17Ind(String prinProc17Ind) {
		this.prinProc17Ind = prinProc17Ind;
	}

	public Long getIcdProc18Id() {
		return icdProc18Id;
	}

	public void setIcdProc18Id(Long icdProc18Id) {
		this.icdProc18Id = icdProc18Id;
	}

	public String getIcdProc18VerCd() {
		return icdProc18VerCd;
	}

	public void setIcdProc18VerCd(String icdProc18VerCd) {
		this.icdProc18VerCd = icdProc18VerCd;
	}

	public String getIcdProc18Cd() {
		return icdProc18Cd;
	}

	public void setIcdProc18Cd(String icdProc18Cd) {
		this.icdProc18Cd = icdProc18Cd;
	}

	public Date getIcdProc18Dt() {
		return icdProc18Dt;
	}

	public void setIcdProc18Dt(Date icdProc18Dt) {
		this.icdProc18Dt = icdProc18Dt;
	}

	public String getPrinProc18Ind() {
		return prinProc18Ind;
	}

	public void setPrinProc18Ind(String prinProc18Ind) {
		this.prinProc18Ind = prinProc18Ind;
	}

	public Long getIcdProc19Id() {
		return icdProc19Id;
	}

	public void setIcdProc19Id(Long icdProc19Id) {
		this.icdProc19Id = icdProc19Id;
	}

	public String getIcdProc19VerCd() {
		return icdProc19VerCd;
	}

	public void setIcdProc19VerCd(String icdProc19VerCd) {
		this.icdProc19VerCd = icdProc19VerCd;
	}

	public String getIcdProc19Cd() {
		return icdProc19Cd;
	}

	public void setIcdProc19Cd(String icdProc19Cd) {
		this.icdProc19Cd = icdProc19Cd;
	}

	public Date getIcdProc19Dt() {
		return icdProc19Dt;
	}

	public void setIcdProc19Dt(Date icdProc19Dt) {
		this.icdProc19Dt = icdProc19Dt;
	}

	public String getPrinProc19Ind() {
		return prinProc19Ind;
	}

	public void setPrinProc19Ind(String prinProc19Ind) {
		this.prinProc19Ind = prinProc19Ind;
	}

	public Long getIcdProc20Id() {
		return icdProc20Id;
	}

	public void setIcdProc20Id(Long icdProc20Id) {
		this.icdProc20Id = icdProc20Id;
	}

	public String getIcdProc20VerCd() {
		return icdProc20VerCd;
	}

	public void setIcdProc20VerCd(String icdProc20VerCd) {
		this.icdProc20VerCd = icdProc20VerCd;
	}

	public String getIcdProc20Cd() {
		return icdProc20Cd;
	}

	public void setIcdProc20Cd(String icdProc20Cd) {
		this.icdProc20Cd = icdProc20Cd;
	}

	public Date getIcdProc20Dt() {
		return icdProc20Dt;
	}

	public void setIcdProc20Dt(Date icdProc20Dt) {
		this.icdProc20Dt = icdProc20Dt;
	}

	public String getPrinProc20Ind() {
		return prinProc20Ind;
	}

	public void setPrinProc20Ind(String prinProc20Ind) {
		this.prinProc20Ind = prinProc20Ind;
	}

	public Long getIcdProc21Id() {
		return icdProc21Id;
	}

	public void setIcdProc21Id(Long icdProc21Id) {
		this.icdProc21Id = icdProc21Id;
	}

	public String getIcdProc21VerCd() {
		return icdProc21VerCd;
	}

	public void setIcdProc21VerCd(String icdProc21VerCd) {
		this.icdProc21VerCd = icdProc21VerCd;
	}

	public String getIcdProc21Cd() {
		return icdProc21Cd;
	}

	public void setIcdProc21Cd(String icdProc21Cd) {
		this.icdProc21Cd = icdProc21Cd;
	}

	public Date getIcdProc21Dt() {
		return icdProc21Dt;
	}

	public void setIcdProc21Dt(Date icdProc21Dt) {
		this.icdProc21Dt = icdProc21Dt;
	}

	public String getPrinProc21Ind() {
		return prinProc21Ind;
	}

	public void setPrinProc21Ind(String prinProc21Ind) {
		this.prinProc21Ind = prinProc21Ind;
	}

	public Long getIcdProc22Id() {
		return icdProc22Id;
	}

	public void setIcdProc22Id(Long icdProc22Id) {
		this.icdProc22Id = icdProc22Id;
	}

	public String getIcdProc22VerCd() {
		return icdProc22VerCd;
	}

	public void setIcdProc22VerCd(String icdProc22VerCd) {
		this.icdProc22VerCd = icdProc22VerCd;
	}

	public String getIcdProc22Cd() {
		return icdProc22Cd;
	}

	public void setIcdProc22Cd(String icdProc22Cd) {
		this.icdProc22Cd = icdProc22Cd;
	}

	public Date getIcdProc22Dt() {
		return icdProc22Dt;
	}

	public void setIcdProc22Dt(Date icdProc22Dt) {
		this.icdProc22Dt = icdProc22Dt;
	}

	public String getPrinProc22Ind() {
		return prinProc22Ind;
	}

	public void setPrinProc22Ind(String prinProc22Ind) {
		this.prinProc22Ind = prinProc22Ind;
	}

	public Long getIcdProc23Id() {
		return icdProc23Id;
	}

	public void setIcdProc23Id(Long icdProc23Id) {
		this.icdProc23Id = icdProc23Id;
	}

	public String getIcdProc23VerCd() {
		return icdProc23VerCd;
	}

	public void setIcdProc23VerCd(String icdProc23VerCd) {
		this.icdProc23VerCd = icdProc23VerCd;
	}

	public String getIcdProc23Cd() {
		return icdProc23Cd;
	}

	public void setIcdProc23Cd(String icdProc23Cd) {
		this.icdProc23Cd = icdProc23Cd;
	}

	public Date getIcdProc23Dt() {
		return icdProc23Dt;
	}

	public void setIcdProc23Dt(Date icdProc23Dt) {
		this.icdProc23Dt = icdProc23Dt;
	}

	public String getPrinProc23Ind() {
		return prinProc23Ind;
	}

	public void setPrinProc23Ind(String prinProc23Ind) {
		this.prinProc23Ind = prinProc23Ind;
	}

	public Long getIcdProc24Id() {
		return icdProc24Id;
	}

	public void setIcdProc24Id(Long icdProc24Id) {
		this.icdProc24Id = icdProc24Id;
	}

	public String getIcdProc24VerCd() {
		return icdProc24VerCd;
	}

	public void setIcdProc24VerCd(String icdProc24VerCd) {
		this.icdProc24VerCd = icdProc24VerCd;
	}

	public String getIcdProc24Cd() {
		return icdProc24Cd;
	}

	public void setIcdProc24Cd(String icdProc24Cd) {
		this.icdProc24Cd = icdProc24Cd;
	}

	public Date getIcdProc24Dt() {
		return icdProc24Dt;
	}

	public void setIcdProc24Dt(Date icdProc24Dt) {
		this.icdProc24Dt = icdProc24Dt;
	}

	public String getPrinProc24Ind() {
		return prinProc24Ind;
	}

	public void setPrinProc24Ind(String prinProc24Ind) {
		this.prinProc24Ind = prinProc24Ind;
	}

	public Long getIcdProc25Id() {
		return icdProc25Id;
	}

	public void setIcdProc25Id(Long icdProc25Id) {
		this.icdProc25Id = icdProc25Id;
	}

	public String getIcdProc25VerCd() {
		return icdProc25VerCd;
	}

	public void setIcdProc25VerCd(String icdProc25VerCd) {
		this.icdProc25VerCd = icdProc25VerCd;
	}

	public String getIcdProc25Cd() {
		return icdProc25Cd;
	}

	public void setIcdProc25Cd(String icdProc25Cd) {
		this.icdProc25Cd = icdProc25Cd;
	}

	public Date getIcdProc25Dt() {
		return icdProc25Dt;
	}

	public void setIcdProc25Dt(Date icdProc25Dt) {
		this.icdProc25Dt = icdProc25Dt;
	}

	public String getPrinProc25Ind() {
		return prinProc25Ind;
	}

	public void setPrinProc25Ind(String prinProc25Ind) {
		this.prinProc25Ind = prinProc25Ind;
	}

	public Long getIcdProc26Id() {
		return icdProc26Id;
	}

	public void setIcdProc26Id(Long icdProc26Id) {
		this.icdProc26Id = icdProc26Id;
	}

	public String getIcdProc26VerCd() {
		return icdProc26VerCd;
	}

	public void setIcdProc26VerCd(String icdProc26VerCd) {
		this.icdProc26VerCd = icdProc26VerCd;
	}

	public String getIcdProc26Cd() {
		return icdProc26Cd;
	}

	public void setIcdProc26Cd(String icdProc26Cd) {
		this.icdProc26Cd = icdProc26Cd;
	}

	public Date getIcdProc26Dt() {
		return icdProc26Dt;
	}

	public void setIcdProc26Dt(Date icdProc26Dt) {
		this.icdProc26Dt = icdProc26Dt;
	}

	public String getPrinProc26Ind() {
		return prinProc26Ind;
	}

	public void setPrinProc26Ind(String prinProc26Ind) {
		this.prinProc26Ind = prinProc26Ind;
	}

	public Long getIcdProc27Id() {
		return icdProc27Id;
	}

	public void setIcdProc27Id(Long icdProc27Id) {
		this.icdProc27Id = icdProc27Id;
	}

	public String getIcdProc27VerCd() {
		return icdProc27VerCd;
	}

	public void setIcdProc27VerCd(String icdProc27VerCd) {
		this.icdProc27VerCd = icdProc27VerCd;
	}

	public String getIcdProc27Cd() {
		return icdProc27Cd;
	}

	public void setIcdProc27Cd(String icdProc27Cd) {
		this.icdProc27Cd = icdProc27Cd;
	}

	public Date getIcdProc27Dt() {
		return icdProc27Dt;
	}

	public void setIcdProc27Dt(Date icdProc27Dt) {
		this.icdProc27Dt = icdProc27Dt;
	}

	public String getPrinProc27Ind() {
		return prinProc27Ind;
	}

	public void setPrinProc27Ind(String prinProc27Ind) {
		this.prinProc27Ind = prinProc27Ind;
	}

	public Long getIcdProc28Id() {
		return icdProc28Id;
	}

	public void setIcdProc28Id(Long icdProc28Id) {
		this.icdProc28Id = icdProc28Id;
	}

	public String getIcdProc28VerCd() {
		return icdProc28VerCd;
	}

	public void setIcdProc28VerCd(String icdProc28VerCd) {
		this.icdProc28VerCd = icdProc28VerCd;
	}

	public String getIcdProc28Cd() {
		return icdProc28Cd;
	}

	public void setIcdProc28Cd(String icdProc28Cd) {
		this.icdProc28Cd = icdProc28Cd;
	}

	public Date getIcdProc28Dt() {
		return icdProc28Dt;
	}

	public void setIcdProc28Dt(Date icdProc28Dt) {
		this.icdProc28Dt = icdProc28Dt;
	}

	public String getPrinProc28Ind() {
		return prinProc28Ind;
	}

	public void setPrinProc28Ind(String prinProc28Ind) {
		this.prinProc28Ind = prinProc28Ind;
	}

	public Long getIcdProc29Id() {
		return icdProc29Id;
	}

	public void setIcdProc29Id(Long icdProc29Id) {
		this.icdProc29Id = icdProc29Id;
	}

	public String getIcdProc29VerCd() {
		return icdProc29VerCd;
	}

	public void setIcdProc29VerCd(String icdProc29VerCd) {
		this.icdProc29VerCd = icdProc29VerCd;
	}

	public String getIcdProc29Cd() {
		return icdProc29Cd;
	}

	public void setIcdProc29Cd(String icdProc29Cd) {
		this.icdProc29Cd = icdProc29Cd;
	}

	public Date getIcdProc29Dt() {
		return icdProc29Dt;
	}

	public void setIcdProc29Dt(Date icdProc29Dt) {
		this.icdProc29Dt = icdProc29Dt;
	}

	public String getPrinProc29Ind() {
		return prinProc29Ind;
	}

	public void setPrinProc29Ind(String prinProc29Ind) {
		this.prinProc29Ind = prinProc29Ind;
	}

	public Long getIcdProc30Id() {
		return icdProc30Id;
	}

	public void setIcdProc30Id(Long icdProc30Id) {
		this.icdProc30Id = icdProc30Id;
	}

	public String getIcdProc30VerCd() {
		return icdProc30VerCd;
	}

	public void setIcdProc30VerCd(String icdProc30VerCd) {
		this.icdProc30VerCd = icdProc30VerCd;
	}

	public String getIcdProc30Cd() {
		return icdProc30Cd;
	}

	public void setIcdProc30Cd(String icdProc30Cd) {
		this.icdProc30Cd = icdProc30Cd;
	}

	public Date getIcdProc30Dt() {
		return icdProc30Dt;
	}

	public void setIcdProc30Dt(Date icdProc30Dt) {
		this.icdProc30Dt = icdProc30Dt;
	}

	public String getPrinProc30Ind() {
		return prinProc30Ind;
	}

	public void setPrinProc30Ind(String prinProc30Ind) {
		this.prinProc30Ind = prinProc30Ind;
	}

	public Long getBilDrgTypId() {
		return bilDrgTypId;
	}

	public void setBilDrgTypId(Long bilDrgTypId) {
		this.bilDrgTypId = bilDrgTypId;
	}

	public Long getBilDrgId() {
		return bilDrgId;
	}

	public void setBilDrgId(Long bilDrgId) {
		this.bilDrgId = bilDrgId;
	}

	public String getBilDrgCd() {
		return bilDrgCd;
	}

	public void setBilDrgCd(String bilDrgCd) {
		this.bilDrgCd = bilDrgCd;
	}

	public Long getBilDrgVerId() {
		return bilDrgVerId;
	}

	public void setBilDrgVerId(Long bilDrgVerId) {
		this.bilDrgVerId = bilDrgVerId;
	}

	public BigDecimal getBilDrgRelWgtVal() {
		return bilDrgRelWgtVal;
	}

	public void setBilDrgRelWgtVal(BigDecimal bilDrgRelWgtVal) {
		this.bilDrgRelWgtVal = bilDrgRelWgtVal;
	}

	public BigDecimal getBilDrgGmlosVal() {
		return bilDrgGmlosVal;
	}

	public void setBilDrgGmlosVal(BigDecimal bilDrgGmlosVal) {
		this.bilDrgGmlosVal = bilDrgGmlosVal;
	}

	public BigDecimal getBilDrgAlosVal() {
		return bilDrgAlosVal;
	}

	public void setBilDrgAlosVal(BigDecimal bilDrgAlosVal) {
		this.bilDrgAlosVal = bilDrgAlosVal;
	}

	public Long getPdDrgTypId() {
		return pdDrgTypId;
	}

	public void setPdDrgTypId(Long pdDrgTypId) {
		this.pdDrgTypId = pdDrgTypId;
	}

	public Long getPdDrgId() {
		return pdDrgId;
	}

	public void setPdDrgId(Long pdDrgId) {
		this.pdDrgId = pdDrgId;
	}

	public String getPdDrgCd() {
		return pdDrgCd;
	}

	public void setPdDrgCd(String pdDrgCd) {
		this.pdDrgCd = pdDrgCd;
	}

	public Long getPdDrgVerId() {
		return pdDrgVerId;
	}

	public void setPdDrgVerId(Long pdDrgVerId) {
		this.pdDrgVerId = pdDrgVerId;
	}

	public BigDecimal getPdDrgRelWgtVal() {
		return pdDrgRelWgtVal;
	}

	public void setPdDrgRelWgtVal(BigDecimal pdDrgRelWgtVal) {
		this.pdDrgRelWgtVal = pdDrgRelWgtVal;
	}

	public BigDecimal getPdDrgGmlosVal() {
		return pdDrgGmlosVal;
	}

	public void setPdDrgGmlosVal(BigDecimal pdDrgGmlosVal) {
		this.pdDrgGmlosVal = pdDrgGmlosVal;
	}

	public BigDecimal getPdDrgAlosVal() {
		return pdDrgAlosVal;
	}

	public void setPdDrgAlosVal(BigDecimal pdDrgAlosVal) {
		this.pdDrgAlosVal = pdDrgAlosVal;
	}

	public BigDecimal getClmDrgAmt() {
		return clmDrgAmt;
	}

	public void setClmDrgAmt(BigDecimal clmDrgAmt) {
		this.clmDrgAmt = clmDrgAmt;
	}

	public Long getCond1Id() {
		return cond1Id;
	}

	public void setCond1Id(Long cond1Id) {
		this.cond1Id = cond1Id;
	}

	public String getCond1Cd() {
		return cond1Cd;
	}

	public void setCond1Cd(String cond1Cd) {
		this.cond1Cd = cond1Cd;
	}

	public Long getCond2Id() {
		return cond2Id;
	}

	public void setCond2Id(Long cond2Id) {
		this.cond2Id = cond2Id;
	}

	public String getCond2Cd() {
		return cond2Cd;
	}

	public void setCond2Cd(String cond2Cd) {
		this.cond2Cd = cond2Cd;
	}

	public Long getCond3Id() {
		return cond3Id;
	}

	public void setCond3Id(Long cond3Id) {
		this.cond3Id = cond3Id;
	}

	public String getCond3Cd() {
		return cond3Cd;
	}

	public void setCond3Cd(String cond3Cd) {
		this.cond3Cd = cond3Cd;
	}

	public Long getCond4Id() {
		return cond4Id;
	}

	public void setCond4Id(Long cond4Id) {
		this.cond4Id = cond4Id;
	}

	public String getCond4Cd() {
		return cond4Cd;
	}

	public void setCond4Cd(String cond4Cd) {
		this.cond4Cd = cond4Cd;
	}

	public Long getCond5Id() {
		return cond5Id;
	}

	public void setCond5Id(Long cond5Id) {
		this.cond5Id = cond5Id;
	}

	public String getCond5Cd() {
		return cond5Cd;
	}

	public void setCond5Cd(String cond5Cd) {
		this.cond5Cd = cond5Cd;
	}

	public Long getCond6Id() {
		return cond6Id;
	}

	public void setCond6Id(Long cond6Id) {
		this.cond6Id = cond6Id;
	}

	public String getCond6Cd() {
		return cond6Cd;
	}

	public void setCond6Cd(String cond6Cd) {
		this.cond6Cd = cond6Cd;
	}

	public Long getCond7Id() {
		return cond7Id;
	}

	public void setCond7Id(Long cond7Id) {
		this.cond7Id = cond7Id;
	}

	public String getCond7Cd() {
		return cond7Cd;
	}

	public void setCond7Cd(String cond7Cd) {
		this.cond7Cd = cond7Cd;
	}

	public Long getCond8Id() {
		return cond8Id;
	}

	public void setCond8Id(Long cond8Id) {
		this.cond8Id = cond8Id;
	}

	public String getCond8Cd() {
		return cond8Cd;
	}

	public void setCond8Cd(String cond8Cd) {
		this.cond8Cd = cond8Cd;
	}

	public Long getCond9Id() {
		return cond9Id;
	}

	public void setCond9Id(Long cond9Id) {
		this.cond9Id = cond9Id;
	}

	public String getCond9Cd() {
		return cond9Cd;
	}

	public void setCond9Cd(String cond9Cd) {
		this.cond9Cd = cond9Cd;
	}

	public Long getCond10Id() {
		return cond10Id;
	}

	public void setCond10Id(Long cond10Id) {
		this.cond10Id = cond10Id;
	}

	public String getCond10Cd() {
		return cond10Cd;
	}

	public void setCond10Cd(String cond10Cd) {
		this.cond10Cd = cond10Cd;
	}

	public Long getCond11Id() {
		return cond11Id;
	}

	public void setCond11Id(Long cond11Id) {
		this.cond11Id = cond11Id;
	}

	public String getCond11Cd() {
		return cond11Cd;
	}

	public void setCond11Cd(String cond11Cd) {
		this.cond11Cd = cond11Cd;
	}

	public Long getCond12Id() {
		return cond12Id;
	}

	public void setCond12Id(Long cond12Id) {
		this.cond12Id = cond12Id;
	}

	public String getCond12Cd() {
		return cond12Cd;
	}

	public void setCond12Cd(String cond12Cd) {
		this.cond12Cd = cond12Cd;
	}

	public Long getCond13Id() {
		return cond13Id;
	}

	public void setCond13Id(Long cond13Id) {
		this.cond13Id = cond13Id;
	}

	public String getCond13Cd() {
		return cond13Cd;
	}

	public void setCond13Cd(String cond13Cd) {
		this.cond13Cd = cond13Cd;
	}

	public Long getCond14Id() {
		return cond14Id;
	}

	public void setCond14Id(Long cond14Id) {
		this.cond14Id = cond14Id;
	}

	public String getCond14Cd() {
		return cond14Cd;
	}

	public void setCond14Cd(String cond14Cd) {
		this.cond14Cd = cond14Cd;
	}

	public Long getCond15Id() {
		return cond15Id;
	}

	public void setCond15Id(Long cond15Id) {
		this.cond15Id = cond15Id;
	}

	public String getCond15Cd() {
		return cond15Cd;
	}

	public void setCond15Cd(String cond15Cd) {
		this.cond15Cd = cond15Cd;
	}

	public Long getCond16Id() {
		return cond16Id;
	}

	public void setCond16Id(Long cond16Id) {
		this.cond16Id = cond16Id;
	}

	public String getCond16Cd() {
		return cond16Cd;
	}

	public void setCond16Cd(String cond16Cd) {
		this.cond16Cd = cond16Cd;
	}

	public Long getCond17Id() {
		return cond17Id;
	}

	public void setCond17Id(Long cond17Id) {
		this.cond17Id = cond17Id;
	}

	public String getCond17Cd() {
		return cond17Cd;
	}

	public void setCond17Cd(String cond17Cd) {
		this.cond17Cd = cond17Cd;
	}

	public Long getCond18Id() {
		return cond18Id;
	}

	public void setCond18Id(Long cond18Id) {
		this.cond18Id = cond18Id;
	}

	public String getCond18Cd() {
		return cond18Cd;
	}

	public void setCond18Cd(String cond18Cd) {
		this.cond18Cd = cond18Cd;
	}

	public Long getCond19Id() {
		return cond19Id;
	}

	public void setCond19Id(Long cond19Id) {
		this.cond19Id = cond19Id;
	}

	public String getCond19Cd() {
		return cond19Cd;
	}

	public void setCond19Cd(String cond19Cd) {
		this.cond19Cd = cond19Cd;
	}

	public Long getCond20Id() {
		return cond20Id;
	}

	public void setCond20Id(Long cond20Id) {
		this.cond20Id = cond20Id;
	}

	public String getCond20Cd() {
		return cond20Cd;
	}

	public void setCond20Cd(String cond20Cd) {
		this.cond20Cd = cond20Cd;
	}

	public BigDecimal getTotBilChrgAmt() {
		return totBilChrgAmt;
	}

	public void setTotBilChrgAmt(BigDecimal totBilChrgAmt) {
		this.totBilChrgAmt = totBilChrgAmt;
	}

	public BigDecimal getTotCopayAmt() {
		return totCopayAmt;
	}

	public void setTotCopayAmt(BigDecimal totCopayAmt) {
		this.totCopayAmt = totCopayAmt;
	}

	public BigDecimal getTotSurchrgTaxAmt() {
		return totSurchrgTaxAmt;
	}

	public void setTotSurchrgTaxAmt(BigDecimal totSurchrgTaxAmt) {
		this.totSurchrgTaxAmt = totSurchrgTaxAmt;
	}

	public BigDecimal getTotPrrPayAmt() {
		return totPrrPayAmt;
	}

	public void setTotPrrPayAmt(BigDecimal totPrrPayAmt) {
		this.totPrrPayAmt = totPrrPayAmt;
	}

	public BigDecimal getTotClmAllwAmt() {
		return totClmAllwAmt;
	}

	public void setTotClmAllwAmt(BigDecimal totClmAllwAmt) {
		this.totClmAllwAmt = totClmAllwAmt;
	}

	public BigDecimal getTotOtsdLabChrgAmt() {
		return totOtsdLabChrgAmt;
	}

	public void setTotOtsdLabChrgAmt(BigDecimal totOtsdLabChrgAmt) {
		this.totOtsdLabChrgAmt = totOtsdLabChrgAmt;
	}

	public BigDecimal getTotBenCoinsAmt() {
		return totBenCoinsAmt;
	}

	public void setTotBenCoinsAmt(BigDecimal totBenCoinsAmt) {
		this.totBenCoinsAmt = totBenCoinsAmt;
	}

	public BigDecimal getTotPtntPdAmt() {
		return totPtntPdAmt;
	}

	public void setTotPtntPdAmt(BigDecimal totPtntPdAmt) {
		this.totPtntPdAmt = totPtntPdAmt;
	}

	public BigDecimal getTotBalDueAmt() {
		return totBalDueAmt;
	}

	public void setTotBalDueAmt(BigDecimal totBalDueAmt) {
		this.totBalDueAmt = totBalDueAmt;
	}

	public BigDecimal getTotCrDrCrdAmt() {
		return totCrDrCrdAmt;
	}

	public void setTotCrDrCrdAmt(BigDecimal totCrDrCrdAmt) {
		this.totCrDrCrdAmt = totCrDrCrdAmt;
	}

	public BigDecimal getTotContrAmt() {
		return totContrAmt;
	}

	public void setTotContrAmt(BigDecimal totContrAmt) {
		this.totContrAmt = totContrAmt;
	}

	public BigDecimal getTotCobSvAmt() {
		return totCobSvAmt;
	}

	public void setTotCobSvAmt(BigDecimal totCobSvAmt) {
		this.totCobSvAmt = totCobSvAmt;
	}

	public BigDecimal getTotRprcSvAmt() {
		return totRprcSvAmt;
	}

	public void setTotRprcSvAmt(BigDecimal totRprcSvAmt) {
		this.totRprcSvAmt = totRprcSvAmt;
	}

	public BigDecimal getTotEndStgRnlDsesAmt() {
		return totEndStgRnlDsesAmt;
	}

	public void setTotEndStgRnlDsesAmt(BigDecimal totEndStgRnlDsesAmt) {
		this.totEndStgRnlDsesAmt = totEndStgRnlDsesAmt;
	}

	public BigDecimal getTotClmPdAmt() {
		return totClmPdAmt;
	}

	public void setTotClmPdAmt(BigDecimal totClmPdAmt) {
		this.totClmPdAmt = totClmPdAmt;
	}

	public BigDecimal getTotPtntRespAmt() {
		return totPtntRespAmt;
	}

	public void setTotPtntRespAmt(BigDecimal totPtntRespAmt) {
		this.totPtntRespAmt = totPtntRespAmt;
	}

	public BigDecimal getTotNonPayProfCmpntAmt() {
		return totNonPayProfCmpntAmt;
	}

	public void setTotNonPayProfCmpntAmt(BigDecimal totNonPayProfCmpntAmt) {
		this.totNonPayProfCmpntAmt = totNonPayProfCmpntAmt;
	}

	public BigDecimal getTotNcAmt() {
		return totNcAmt;
	}

	public void setTotNcAmt(BigDecimal totNcAmt) {
		this.totNcAmt = totNcAmt;
	}

	public BigDecimal getTotDedAmt() {
		return totDedAmt;
	}

	public void setTotDedAmt(BigDecimal totDedAmt) {
		this.totDedAmt = totDedAmt;
	}

	public BigDecimal getTotCovAmt() {
		return totCovAmt;
	}

	public void setTotCovAmt(BigDecimal totCovAmt) {
		this.totCovAmt = totCovAmt;
	}

	public BigDecimal getTotIntAmt() {
		return totIntAmt;
	}

	public void setTotIntAmt(BigDecimal totIntAmt) {
		this.totIntAmt = totIntAmt;
	}

	public BigDecimal getTotDscntAmt() {
		return totDscntAmt;
	}

	public void setTotDscntAmt(BigDecimal totDscntAmt) {
		this.totDscntAmt = totDscntAmt;
	}

	public BigDecimal getTotEstDueAmt() {
		return totEstDueAmt;
	}

	public void setTotEstDueAmt(BigDecimal totEstDueAmt) {
		this.totEstDueAmt = totEstDueAmt;
	}

	public BigDecimal getTotOiPdAmt() {
		return totOiPdAmt;
	}

	public void setTotOiPdAmt(BigDecimal totOiPdAmt) {
		this.totOiPdAmt = totOiPdAmt;
	}

	public BigDecimal getTotMedcrPdAmt() {
		return totMedcrPdAmt;
	}

	public void setTotMedcrPdAmt(BigDecimal totMedcrPdAmt) {
		this.totMedcrPdAmt = totMedcrPdAmt;
	}

	public BigDecimal getTotMedcrCoinsAmt() {
		return totMedcrCoinsAmt;
	}

	public void setTotMedcrCoinsAmt(BigDecimal totMedcrCoinsAmt) {
		this.totMedcrCoinsAmt = totMedcrCoinsAmt;
	}

	public BigDecimal getTotMedcrDedAmt() {
		return totMedcrDedAmt;
	}

	public void setTotMedcrDedAmt(BigDecimal totMedcrDedAmt) {
		this.totMedcrDedAmt = totMedcrDedAmt;
	}

	public BigDecimal getTotCovIptntDayCnt() {
		return totCovIptntDayCnt;
	}

	public void setTotCovIptntDayCnt(BigDecimal totCovIptntDayCnt) {
		this.totCovIptntDayCnt = totCovIptntDayCnt;
	}

	public BigDecimal getTotNonCovIptntDayCnt() {
		return totNonCovIptntDayCnt;
	}

	public void setTotNonCovIptntDayCnt(BigDecimal totNonCovIptntDayCnt) {
		this.totNonCovIptntDayCnt = totNonCovIptntDayCnt;
	}

	public Long getBcbsItsId() {
		return bcbsItsId;
	}

	public void setBcbsItsId(Long bcbsItsId) {
		this.bcbsItsId = bcbsItsId;
	}

	public String getBcbsItsCd() {
		return bcbsItsCd;
	}

	public void setBcbsItsCd(String bcbsItsCd) {
		this.bcbsItsCd = bcbsItsCd;
	}

	public String getBcbsItsSccfNbr() {
		return bcbsItsSccfNbr;
	}

	public void setBcbsItsSccfNbr(String bcbsItsSccfNbr) {
		this.bcbsItsSccfNbr = bcbsItsSccfNbr;
	}

	public Long getClmAdjdPltfmId() {
		return clmAdjdPltfmId;
	}

	public void setClmAdjdPltfmId(Long clmAdjdPltfmId) {
		this.clmAdjdPltfmId = clmAdjdPltfmId;
	}

	public Timestamp getClmAdjDttm() {
		return clmAdjDttm;
	}

	public void setClmAdjDttm(Timestamp clmAdjDttm) {
		this.clmAdjDttm = clmAdjDttm;
	}

	public Long getClmPayeAsgnId() {
		return clmPayeAsgnId;
	}

	public void setClmPayeAsgnId(Long clmPayeAsgnId) {
		this.clmPayeAsgnId = clmPayeAsgnId;
	}

	public String getClrhseTracNbr() {
		return clrhseTracNbr;
	}

	public void setClrhseTracNbr(String clrhseTracNbr) {
		this.clrhseTracNbr = clrhseTracNbr;
	}

	public String getClinLabAmnd1Nbr() {
		return clinLabAmnd1Nbr;
	}

	public void setClinLabAmnd1Nbr(String clinLabAmnd1Nbr) {
		this.clinLabAmnd1Nbr = clinLabAmnd1Nbr;
	}

	public String getClinLabAmnd2Nbr() {
		return clinLabAmnd2Nbr;
	}

	public void setClinLabAmnd2Nbr(String clinLabAmnd2Nbr) {
		this.clinLabAmnd2Nbr = clinLabAmnd2Nbr;
	}

	public String getClinLabAmnd3Nbr() {
		return clinLabAmnd3Nbr;
	}

	public void setClinLabAmnd3Nbr(String clinLabAmnd3Nbr) {
		this.clinLabAmnd3Nbr = clinLabAmnd3Nbr;
	}

	public String getEeClmInd() {
		return eeClmInd;
	}

	public void setEeClmInd(String eeClmInd) {
		this.eeClmInd = eeClmInd;
	}

	public Date getEstBthDt() {
		return estBthDt;
	}

	public void setEstBthDt(Date estBthDt) {
		this.estBthDt = estBthDt;
	}

	public Date getLstMnstrlDt() {
		return lstMnstrlDt;
	}

	public void setLstMnstrlDt(Date lstMnstrlDt) {
		this.lstMnstrlDt = lstMnstrlDt;
	}

	public Date getLstXrayDt() {
		return lstXrayDt;
	}

	public void setLstXrayDt(Date lstXrayDt) {
		this.lstXrayDt = lstXrayDt;
	}

	public String getMmgrCertNbr() {
		return mmgrCertNbr;
	}

	public void setMmgrCertNbr(String mmgrCertNbr) {
		this.mmgrCertNbr = mmgrCertNbr;
	}

	public Long getSrvcAuthXcptId() {
		return srvcAuthXcptId;
	}

	public void setSrvcAuthXcptId(Long srvcAuthXcptId) {
		this.srvcAuthXcptId = srvcAuthXcptId;
	}

	public Date getSimIllDt() {
		return simIllDt;
	}

	public void setSimIllDt(Date simIllDt) {
		this.simIllDt = simIllDt;
	}

	public Long getSurchrgTaxId() {
		return surchrgTaxId;
	}

	public void setSurchrgTaxId(Long surchrgTaxId) {
		this.surchrgTaxId = surchrgTaxId;
	}

	public String getPcpRespInd() {
		return pcpRespInd;
	}

	public void setPcpRespInd(String pcpRespInd) {
		this.pcpRespInd = pcpRespInd;
	}

	public String getSurgThruErInd() {
		return surgThruErInd;
	}

	public void setSurgThruErInd(String surgThruErInd) {
		this.surgThruErInd = surgThruErInd;
	}

	public Long getClmStsCatgy1Id() {
		return clmStsCatgy1Id;
	}

	public void setClmStsCatgy1Id(Long clmStsCatgy1Id) {
		this.clmStsCatgy1Id = clmStsCatgy1Id;
	}

	public String getClmStsCatgy1Cd() {
		return clmStsCatgy1Cd;
	}

	public void setClmStsCatgy1Cd(String clmStsCatgy1Cd) {
		this.clmStsCatgy1Cd = clmStsCatgy1Cd;
	}

	public Long getClmSts1Id() {
		return clmSts1Id;
	}

	public void setClmSts1Id(Long clmSts1Id) {
		this.clmSts1Id = clmSts1Id;
	}

	public String getClmSts1Cd() {
		return clmSts1Cd;
	}

	public void setClmSts1Cd(String clmSts1Cd) {
		this.clmSts1Cd = clmSts1Cd;
	}

	public Long getClmStsCatgy2Id() {
		return clmStsCatgy2Id;
	}

	public void setClmStsCatgy2Id(Long clmStsCatgy2Id) {
		this.clmStsCatgy2Id = clmStsCatgy2Id;
	}

	public String getClmStsCatgy2Cd() {
		return clmStsCatgy2Cd;
	}

	public void setClmStsCatgy2Cd(String clmStsCatgy2Cd) {
		this.clmStsCatgy2Cd = clmStsCatgy2Cd;
	}

	public Long getClmSts2Id() {
		return clmSts2Id;
	}

	public void setClmSts2Id(Long clmSts2Id) {
		this.clmSts2Id = clmSts2Id;
	}

	public String getClmSts2Cd() {
		return clmSts2Cd;
	}

	public void setClmSts2Cd(String clmSts2Cd) {
		this.clmSts2Cd = clmSts2Cd;
	}

	public Long getClmStsCatgy3Id() {
		return clmStsCatgy3Id;
	}

	public void setClmStsCatgy3Id(Long clmStsCatgy3Id) {
		this.clmStsCatgy3Id = clmStsCatgy3Id;
	}

	public String getClmStsCatgy3Cd() {
		return clmStsCatgy3Cd;
	}

	public void setClmStsCatgy3Cd(String clmStsCatgy3Cd) {
		this.clmStsCatgy3Cd = clmStsCatgy3Cd;
	}

	public Long getClmSts3Id() {
		return clmSts3Id;
	}

	public void setClmSts3Id(Long clmSts3Id) {
		this.clmSts3Id = clmSts3Id;
	}

	public String getClmSts3Cd() {
		return clmSts3Cd;
	}

	public void setClmSts3Cd(String clmSts3Cd) {
		this.clmSts3Cd = clmSts3Cd;
	}

	public Long getClmStsCatgy4Id() {
		return clmStsCatgy4Id;
	}

	public void setClmStsCatgy4Id(Long clmStsCatgy4Id) {
		this.clmStsCatgy4Id = clmStsCatgy4Id;
	}

	public String getClmStsCatgy4Cd() {
		return clmStsCatgy4Cd;
	}

	public void setClmStsCatgy4Cd(String clmStsCatgy4Cd) {
		this.clmStsCatgy4Cd = clmStsCatgy4Cd;
	}

	public Long getClmSts4Id() {
		return clmSts4Id;
	}

	public void setClmSts4Id(Long clmSts4Id) {
		this.clmSts4Id = clmSts4Id;
	}

	public String getClmSts4Cd() {
		return clmSts4Cd;
	}

	public void setClmSts4Cd(String clmSts4Cd) {
		this.clmSts4Cd = clmSts4Cd;
	}

	public Long getClmStsCatgy5Id() {
		return clmStsCatgy5Id;
	}

	public void setClmStsCatgy5Id(Long clmStsCatgy5Id) {
		this.clmStsCatgy5Id = clmStsCatgy5Id;
	}

	public String getClmStsCatgy5Cd() {
		return clmStsCatgy5Cd;
	}

	public void setClmStsCatgy5Cd(String clmStsCatgy5Cd) {
		this.clmStsCatgy5Cd = clmStsCatgy5Cd;
	}

	public Long getClmSts5Id() {
		return clmSts5Id;
	}

	public void setClmSts5Id(Long clmSts5Id) {
		this.clmSts5Id = clmSts5Id;
	}

	public String getClmSts5Cd() {
		return clmSts5Cd;
	}

	public void setClmSts5Cd(String clmSts5Cd) {
		this.clmSts5Cd = clmSts5Cd;
	}

	public Long getClmStsCatgy6Id() {
		return clmStsCatgy6Id;
	}

	public void setClmStsCatgy6Id(Long clmStsCatgy6Id) {
		this.clmStsCatgy6Id = clmStsCatgy6Id;
	}

	public String getClmStsCatgy6Cd() {
		return clmStsCatgy6Cd;
	}

	public void setClmStsCatgy6Cd(String clmStsCatgy6Cd) {
		this.clmStsCatgy6Cd = clmStsCatgy6Cd;
	}

	public Long getClmSts6Id() {
		return clmSts6Id;
	}

	public void setClmSts6Id(Long clmSts6Id) {
		this.clmSts6Id = clmSts6Id;
	}

	public String getClmSts6Cd() {
		return clmSts6Cd;
	}

	public void setClmSts6Cd(String clmSts6Cd) {
		this.clmSts6Cd = clmSts6Cd;
	}

	public Long getClmStsCatgy7Id() {
		return clmStsCatgy7Id;
	}

	public void setClmStsCatgy7Id(Long clmStsCatgy7Id) {
		this.clmStsCatgy7Id = clmStsCatgy7Id;
	}

	public String getClmStsCatgy7Cd() {
		return clmStsCatgy7Cd;
	}

	public void setClmStsCatgy7Cd(String clmStsCatgy7Cd) {
		this.clmStsCatgy7Cd = clmStsCatgy7Cd;
	}

	public Long getClmSts7Id() {
		return clmSts7Id;
	}

	public void setClmSts7Id(Long clmSts7Id) {
		this.clmSts7Id = clmSts7Id;
	}

	public String getClmSts7Cd() {
		return clmSts7Cd;
	}

	public void setClmSts7Cd(String clmSts7Cd) {
		this.clmSts7Cd = clmSts7Cd;
	}

	public Long getClmStsCatgy8Id() {
		return clmStsCatgy8Id;
	}

	public void setClmStsCatgy8Id(Long clmStsCatgy8Id) {
		this.clmStsCatgy8Id = clmStsCatgy8Id;
	}

	public String getClmStsCatgy8Cd() {
		return clmStsCatgy8Cd;
	}

	public void setClmStsCatgy8Cd(String clmStsCatgy8Cd) {
		this.clmStsCatgy8Cd = clmStsCatgy8Cd;
	}

	public Long getClmSts8Id() {
		return clmSts8Id;
	}

	public void setClmSts8Id(Long clmSts8Id) {
		this.clmSts8Id = clmSts8Id;
	}

	public String getClmSts8Cd() {
		return clmSts8Cd;
	}

	public void setClmSts8Cd(String clmSts8Cd) {
		this.clmSts8Cd = clmSts8Cd;
	}

	public Long getAuthTypId() {
		return authTypId;
	}

	public void setAuthTypId(Long authTypId) {
		this.authTypId = authTypId;
	}

	public String getRefInd() {
		return refInd;
	}

	public void setRefInd(String refInd) {
		this.refInd = refInd;
	}

	public String getAuthNbr() {
		return authNbr;
	}

	public void setAuthNbr(String authNbr) {
		this.authNbr = authNbr;
	}

	public String getActvInd() {
		return actvInd;
	}

	public void setActvInd(String actvInd) {
		this.actvInd = actvInd;
	}

	public String getDelInd() {
		return delInd;
	}

	public void setDelInd(String delInd) {
		this.delInd = delInd;
	}

	public String getSpecialFields() {
		return specialFields;
	}

	public void setSpecialFields(String specialFields) {
		this.specialFields = specialFields;
	}


}