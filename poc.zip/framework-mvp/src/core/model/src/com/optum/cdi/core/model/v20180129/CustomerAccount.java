package com.optum.cdi.core.model.v20180129;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

public class CustomerAccount {

	public CustomerAccount() {
	}

	private String custAcctId;
	private Long srcSysId;
	private Date effDtlDt;
	private String creatUserId;
	private Timestamp creatTmstmp;
	private String updtUserId;
	private Timestamp updtTmstmp;
	private Long audId;
	private Date cancDtlDt;
	private String lgsltvLangCmplnInd;
	private String custAcctDesc;
	private String orgId;
	private Long orgSrcSysId;
	private Date orgEffDtlDt;
	private String indvId;
	private Long indvSrcSysId;
	private Date indvEffDtlDt;
	private Date custAcctOrigEffStrtDt;
	private Date custAcctEffStrtDt;
	private Date custAcctTrmDt;
	private Date custAcctCancDt;
	private Date custAcctRenDt;
	private Long acctCancRsnId;
	private Long custAcctStsTypId;
	private Integer lglEntyId;
	private Integer ownrLglEntyId;
	private Long incTypId;
	private Integer busEntpId;
	private String busEntpNm;
	private String busEntpCntcNm;
	private String busEntpTelNbr;
	private String busEntpFaxNbr;
	private String busEntpCntcEmail;
	private Long dmclIsoCntryId;
	private Long dmclStPrvcId;
	private Long abbrLglEntyId;
	private String lglEntyNm;
	private String fedTin;
	private String glBuNbr;
	private Date lglEntyEffDt;
	private Date lglEntyExpirDt;
	private Long regEntyId;
	private BigDecimal ownrPct;
	private Integer busArngBusEntpId;
	private String busArngBusEntpNm;
	private String busArngBusEntpCntcNm;
	private String busArngBusEntpTelNbr;
	private String busArngBusEntpFaxNbr;
	private String busArngBusEntpCntcEmail;
	private Integer prtnCarrId;
	private String prtnCarrNm;
	private String prtnCarrCntcNm;
	private String prtnCarrTelNbr;
	private String prtnCarrFaxNbr;
	private String prtnCarrCntcEmail;
	private Integer busArngId;
	private Long busArngTypId;
	private Date busArngEffDt;
	private Date busArngTrmDt;
	private Integer busSegId;
	private String busSegNm;
	private String busSegDesc;
	private Long busSegTypId;
	private Integer busSegBusEntpId;
	private String busSegBusEntpNm;
	private String busSegBusEntpCntcEmail;
	private String busSegBusEntpTelNbr;
	private String busSegBusEntpFaxNbr;
	private String busSegBusEntpCntcNm;
	private String supPlnInd;
	private Integer prtcpCnt;
	private String delInd;
	private String specialFields;

	public String getCustAcctId() {
		return custAcctId;
	}

	public void setCustAcctId(String custAcctId) {
		this.custAcctId = custAcctId;
	}

	public Long getSrcSysId() {
		return srcSysId;
	}

	public void setSrcSysId(Long srcSysId) {
		this.srcSysId = srcSysId;
	}

	public Date getEffDtlDt() {
		return effDtlDt;
	}

	public void setEffDtlDt(Date effDtlDt) {
		this.effDtlDt = effDtlDt;
	}

	public String getCreatUserId() {
		return creatUserId;
	}

	public void setCreatUserId(String creatUserId) {
		this.creatUserId = creatUserId;
	}

	public Timestamp getCreatTmstmp() {
		return creatTmstmp;
	}

	public void setCreatTmstmp(Timestamp creatTmstmp) {
		this.creatTmstmp = creatTmstmp;
	}

	public String getUpdtUserId() {
		return updtUserId;
	}

	public void setUpdtUserId(String updtUserId) {
		this.updtUserId = updtUserId;
	}

	public Timestamp getUpdtTmstmp() {
		return updtTmstmp;
	}

	public void setUpdtTmstmp(Timestamp updtTmstmp) {
		this.updtTmstmp = updtTmstmp;
	}

	public Long getAudId() {
		return audId;
	}

	public void setAudId(Long audId) {
		this.audId = audId;
	}

	public Date getCancDtlDt() {
		return cancDtlDt;
	}

	public void setCancDtlDt(Date cancDtlDt) {
		this.cancDtlDt = cancDtlDt;
	}

	public String getLgsltvLangCmplnInd() {
		return lgsltvLangCmplnInd;
	}

	public void setLgsltvLangCmplnInd(String lgsltvLangCmplnInd) {
		this.lgsltvLangCmplnInd = lgsltvLangCmplnInd;
	}

	public String getCustAcctDesc() {
		return custAcctDesc;
	}

	public void setCustAcctDesc(String custAcctDesc) {
		this.custAcctDesc = custAcctDesc;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public Long getOrgSrcSysId() {
		return orgSrcSysId;
	}

	public void setOrgSrcSysId(Long orgSrcSysId) {
		this.orgSrcSysId = orgSrcSysId;
	}

	public Date getOrgEffDtlDt() {
		return orgEffDtlDt;
	}

	public void setOrgEffDtlDt(Date orgEffDtlDt) {
		this.orgEffDtlDt = orgEffDtlDt;
	}

	public String getIndvId() {
		return indvId;
	}

	public void setIndvId(String indvId) {
		this.indvId = indvId;
	}

	public Long getIndvSrcSysId() {
		return indvSrcSysId;
	}

	public void setIndvSrcSysId(Long indvSrcSysId) {
		this.indvSrcSysId = indvSrcSysId;
	}

	public Date getIndvEffDtlDt() {
		return indvEffDtlDt;
	}

	public void setIndvEffDtlDt(Date indvEffDtlDt) {
		this.indvEffDtlDt = indvEffDtlDt;
	}

	public Date getCustAcctOrigEffStrtDt() {
		return custAcctOrigEffStrtDt;
	}

	public void setCustAcctOrigEffStrtDt(Date custAcctOrigEffStrtDt) {
		this.custAcctOrigEffStrtDt = custAcctOrigEffStrtDt;
	}

	public Date getCustAcctEffStrtDt() {
		return custAcctEffStrtDt;
	}

	public void setCustAcctEffStrtDt(Date custAcctEffStrtDt) {
		this.custAcctEffStrtDt = custAcctEffStrtDt;
	}

	public Date getCustAcctTrmDt() {
		return custAcctTrmDt;
	}

	public void setCustAcctTrmDt(Date custAcctTrmDt) {
		this.custAcctTrmDt = custAcctTrmDt;
	}

	public Date getCustAcctCancDt() {
		return custAcctCancDt;
	}

	public void setCustAcctCancDt(Date custAcctCancDt) {
		this.custAcctCancDt = custAcctCancDt;
	}

	public Date getCustAcctRenDt() {
		return custAcctRenDt;
	}

	public void setCustAcctRenDt(Date custAcctRenDt) {
		this.custAcctRenDt = custAcctRenDt;
	}

	public Long getAcctCancRsnId() {
		return acctCancRsnId;
	}

	public void setAcctCancRsnId(Long acctCancRsnId) {
		this.acctCancRsnId = acctCancRsnId;
	}

	public Long getCustAcctStsTypId() {
		return custAcctStsTypId;
	}

	public void setCustAcctStsTypId(Long custAcctStsTypId) {
		this.custAcctStsTypId = custAcctStsTypId;
	}

	public Integer getLglEntyId() {
		return lglEntyId;
	}

	public void setLglEntyId(Integer lglEntyId) {
		this.lglEntyId = lglEntyId;
	}

	public Integer getOwnrLglEntyId() {
		return ownrLglEntyId;
	}

	public void setOwnrLglEntyId(Integer ownrLglEntyId) {
		this.ownrLglEntyId = ownrLglEntyId;
	}

	public Long getIncTypId() {
		return incTypId;
	}

	public void setIncTypId(Long incTypId) {
		this.incTypId = incTypId;
	}

	public Integer getBusEntpId() {
		return busEntpId;
	}

	public void setBusEntpId(Integer busEntpId) {
		this.busEntpId = busEntpId;
	}

	public String getBusEntpNm() {
		return busEntpNm;
	}

	public void setBusEntpNm(String busEntpNm) {
		this.busEntpNm = busEntpNm;
	}

	public String getBusEntpCntcNm() {
		return busEntpCntcNm;
	}

	public void setBusEntpCntcNm(String busEntpCntcNm) {
		this.busEntpCntcNm = busEntpCntcNm;
	}

	public String getBusEntpTelNbr() {
		return busEntpTelNbr;
	}

	public void setBusEntpTelNbr(String busEntpTelNbr) {
		this.busEntpTelNbr = busEntpTelNbr;
	}

	public String getBusEntpFaxNbr() {
		return busEntpFaxNbr;
	}

	public void setBusEntpFaxNbr(String busEntpFaxNbr) {
		this.busEntpFaxNbr = busEntpFaxNbr;
	}

	public String getBusEntpCntcEmail() {
		return busEntpCntcEmail;
	}

	public void setBusEntpCntcEmail(String busEntpCntcEmail) {
		this.busEntpCntcEmail = busEntpCntcEmail;
	}

	public Long getDmclIsoCntryId() {
		return dmclIsoCntryId;
	}

	public void setDmclIsoCntryId(Long dmclIsoCntryId) {
		this.dmclIsoCntryId = dmclIsoCntryId;
	}

	public Long getDmclStPrvcId() {
		return dmclStPrvcId;
	}

	public void setDmclStPrvcId(Long dmclStPrvcId) {
		this.dmclStPrvcId = dmclStPrvcId;
	}

	public Long getAbbrLglEntyId() {
		return abbrLglEntyId;
	}

	public void setAbbrLglEntyId(Long abbrLglEntyId) {
		this.abbrLglEntyId = abbrLglEntyId;
	}

	public String getLglEntyNm() {
		return lglEntyNm;
	}

	public void setLglEntyNm(String lglEntyNm) {
		this.lglEntyNm = lglEntyNm;
	}

	public String getFedTin() {
		return fedTin;
	}

	public void setFedTin(String fedTin) {
		this.fedTin = fedTin;
	}

	public String getGlBuNbr() {
		return glBuNbr;
	}

	public void setGlBuNbr(String glBuNbr) {
		this.glBuNbr = glBuNbr;
	}

	public Date getLglEntyEffDt() {
		return lglEntyEffDt;
	}

	public void setLglEntyEffDt(Date lglEntyEffDt) {
		this.lglEntyEffDt = lglEntyEffDt;
	}

	public Date getLglEntyExpirDt() {
		return lglEntyExpirDt;
	}

	public void setLglEntyExpirDt(Date lglEntyExpirDt) {
		this.lglEntyExpirDt = lglEntyExpirDt;
	}

	public Long getRegEntyId() {
		return regEntyId;
	}

	public void setRegEntyId(Long regEntyId) {
		this.regEntyId = regEntyId;
	}

	public BigDecimal getOwnrPct() {
		return ownrPct;
	}

	public void setOwnrPct(BigDecimal ownrPct) {
		this.ownrPct = ownrPct;
	}

	public Integer getBusArngBusEntpId() {
		return busArngBusEntpId;
	}

	public void setBusArngBusEntpId(Integer busArngBusEntpId) {
		this.busArngBusEntpId = busArngBusEntpId;
	}

	public String getBusArngBusEntpNm() {
		return busArngBusEntpNm;
	}

	public void setBusArngBusEntpNm(String busArngBusEntpNm) {
		this.busArngBusEntpNm = busArngBusEntpNm;
	}

	public String getBusArngBusEntpCntcNm() {
		return busArngBusEntpCntcNm;
	}

	public void setBusArngBusEntpCntcNm(String busArngBusEntpCntcNm) {
		this.busArngBusEntpCntcNm = busArngBusEntpCntcNm;
	}

	public String getBusArngBusEntpTelNbr() {
		return busArngBusEntpTelNbr;
	}

	public void setBusArngBusEntpTelNbr(String busArngBusEntpTelNbr) {
		this.busArngBusEntpTelNbr = busArngBusEntpTelNbr;
	}

	public String getBusArngBusEntpFaxNbr() {
		return busArngBusEntpFaxNbr;
	}

	public void setBusArngBusEntpFaxNbr(String busArngBusEntpFaxNbr) {
		this.busArngBusEntpFaxNbr = busArngBusEntpFaxNbr;
	}

	public String getBusArngBusEntpCntcEmail() {
		return busArngBusEntpCntcEmail;
	}

	public void setBusArngBusEntpCntcEmail(String busArngBusEntpCntcEmail) {
		this.busArngBusEntpCntcEmail = busArngBusEntpCntcEmail;
	}

	public Integer getPrtnCarrId() {
		return prtnCarrId;
	}

	public void setPrtnCarrId(Integer prtnCarrId) {
		this.prtnCarrId = prtnCarrId;
	}

	public String getPrtnCarrNm() {
		return prtnCarrNm;
	}

	public void setPrtnCarrNm(String prtnCarrNm) {
		this.prtnCarrNm = prtnCarrNm;
	}

	public String getPrtnCarrCntcNm() {
		return prtnCarrCntcNm;
	}

	public void setPrtnCarrCntcNm(String prtnCarrCntcNm) {
		this.prtnCarrCntcNm = prtnCarrCntcNm;
	}

	public String getPrtnCarrTelNbr() {
		return prtnCarrTelNbr;
	}

	public void setPrtnCarrTelNbr(String prtnCarrTelNbr) {
		this.prtnCarrTelNbr = prtnCarrTelNbr;
	}

	public String getPrtnCarrFaxNbr() {
		return prtnCarrFaxNbr;
	}

	public void setPrtnCarrFaxNbr(String prtnCarrFaxNbr) {
		this.prtnCarrFaxNbr = prtnCarrFaxNbr;
	}

	public String getPrtnCarrCntcEmail() {
		return prtnCarrCntcEmail;
	}

	public void setPrtnCarrCntcEmail(String prtnCarrCntcEmail) {
		this.prtnCarrCntcEmail = prtnCarrCntcEmail;
	}

	public Integer getBusArngId() {
		return busArngId;
	}

	public void setBusArngId(Integer busArngId) {
		this.busArngId = busArngId;
	}

	public Long getBusArngTypId() {
		return busArngTypId;
	}

	public void setBusArngTypId(Long busArngTypId) {
		this.busArngTypId = busArngTypId;
	}

	public Date getBusArngEffDt() {
		return busArngEffDt;
	}

	public void setBusArngEffDt(Date busArngEffDt) {
		this.busArngEffDt = busArngEffDt;
	}

	public Date getBusArngTrmDt() {
		return busArngTrmDt;
	}

	public void setBusArngTrmDt(Date busArngTrmDt) {
		this.busArngTrmDt = busArngTrmDt;
	}

	public Integer getBusSegId() {
		return busSegId;
	}

	public void setBusSegId(Integer busSegId) {
		this.busSegId = busSegId;
	}

	public String getBusSegNm() {
		return busSegNm;
	}

	public void setBusSegNm(String busSegNm) {
		this.busSegNm = busSegNm;
	}

	public String getBusSegDesc() {
		return busSegDesc;
	}

	public void setBusSegDesc(String busSegDesc) {
		this.busSegDesc = busSegDesc;
	}

	public Long getBusSegTypId() {
		return busSegTypId;
	}

	public void setBusSegTypId(Long busSegTypId) {
		this.busSegTypId = busSegTypId;
	}

	public Integer getBusSegBusEntpId() {
		return busSegBusEntpId;
	}

	public void setBusSegBusEntpId(Integer busSegBusEntpId) {
		this.busSegBusEntpId = busSegBusEntpId;
	}

	public String getBusSegBusEntpNm() {
		return busSegBusEntpNm;
	}

	public void setBusSegBusEntpNm(String busSegBusEntpNm) {
		this.busSegBusEntpNm = busSegBusEntpNm;
	}

	public String getBusSegBusEntpCntcEmail() {
		return busSegBusEntpCntcEmail;
	}

	public void setBusSegBusEntpCntcEmail(String busSegBusEntpCntcEmail) {
		this.busSegBusEntpCntcEmail = busSegBusEntpCntcEmail;
	}

	public String getBusSegBusEntpTelNbr() {
		return busSegBusEntpTelNbr;
	}

	public void setBusSegBusEntpTelNbr(String busSegBusEntpTelNbr) {
		this.busSegBusEntpTelNbr = busSegBusEntpTelNbr;
	}

	public String getBusSegBusEntpFaxNbr() {
		return busSegBusEntpFaxNbr;
	}

	public void setBusSegBusEntpFaxNbr(String busSegBusEntpFaxNbr) {
		this.busSegBusEntpFaxNbr = busSegBusEntpFaxNbr;
	}

	public String getBusSegBusEntpCntcNm() {
		return busSegBusEntpCntcNm;
	}

	public void setBusSegBusEntpCntcNm(String busSegBusEntpCntcNm) {
		this.busSegBusEntpCntcNm = busSegBusEntpCntcNm;
	}

	public String getSupPlnInd() {
		return supPlnInd;
	}

	public void setSupPlnInd(String supPlnInd) {
		this.supPlnInd = supPlnInd;
	}

	public Integer getPrtcpCnt() {
		return prtcpCnt;
	}

	public void setPrtcpCnt(Integer prtcpCnt) {
		this.prtcpCnt = prtcpCnt;
	}

	public String getDelInd() {
		return delInd;
	}

	public void setDelInd(String delInd) {
		this.delInd = delInd;
	}

	public String getSpecialFields() {
		return specialFields;
	}

	public void setSpecialFields(String specialFields) {
		this.specialFields = specialFields;
	}


}