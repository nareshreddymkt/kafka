package com.optum.cdi.core.model.v20180129;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

public class Plan {

	public Plan() {
	}

	private String plnCd;
	private String plnVerNbr;
	private Long srcSysId;
	private Date effDtlDt;
	private String creatUserId;
	private Timestamp creatTmstmp;
	private String updtUserId;
	private Timestamp updtTmstmp;
	private Long audId;
	private Date cancDtlDt;
	private Date plnRdyDt;
	private Date plnExpirDt;
	private Date doNotSellDt;
	private Date doNotRenDt;
	private Date plnEffDt;
	private String rideAllwInd;
	private String rideOnlyInd;
	private String pkgOnlyInd;
	private String plnNm;
	private String plnLglDesc;
	private Long plnDfnTypId;
	private String prdctCd;
	private String prdctVerNbr;
	private Long prdctSrcSysId;
	private Date prdctEffDtlDt;
	private String derivFromPlnCd;
	private String derivFromPlnVerNbr;
	private Long derivFromPlnSrcSysId;
	private Date derivFromPlnEffDtlDt;
	private Long mtlcLvlId;
	private Long plnTypId;
	private Integer erSzId;
	private Long eeCntMethId;
	private Integer eeBegnCnt;
	private Integer eeEndCnt;
	private String erSzDesc;
	private Date erSzEffDt;
	private Long spclNeedPlnTypId;
	private String frmlryCd;
	private Long aggrDedId;
	private String aggrDedInd;
	private Long rideBenTypId;
	private Long plnOfrToTypId;
	private Long plnCatgyId;
	private Long plnSbcatgyId;
	private Long benPrdCalcBasTypId;
	private String aggrOopMaxInd;
	private String hsaEligInd;
	private String hraEligInd;
	private Long plnDlgtLvlId;
	private Long clmAdjdPltfmId;
	private Long fundArngId;
	private String benCd;
	private String benCdDesc;
	private String benCdStdTxt;
	private String benCdHlpTxt;
	private Date benCdEffDt;
	private Date benCdExpirDt;
	private Long hlthCovTypId;
	private Date plnBenEffDt;
	private Date plnBenExpirDt;
	private String plnBenOptInd;
	private String buyupInd;
	private String benXcldFromCovInd;
	private Long essnHlthBenCatgyId;
	private Integer plnCntcId;
	private Long cntcRoleId;
	private Integer suppCntcId;
	private Long isoCntryId;
	private String fstNm;
	private String midlNm;
	private String lstNm;
	private String suppCntcFullNm;
	private String titlTxt;
	private String suppCntcOrgNm;
	private Long nmPrfxId;
	private Long nmSufxId;
	private Long crdntlSufxId;
	private Long gdrTypId;
	private Long cntcTypId;
	private Long isoCntryTelId;
	private String areaCd;
	private String xchgNbr;
	private String telNbr;
	private String extNbr;
	private String priInd;
	private Integer lglEntyId;
	private Integer ownrLglEntyId;
	private Long medNtwkTypId;
	private Long incTypId;
	private Integer busEntpId;
	private String busEntpNm;
	private String busEntpCntcNm;
	private String busEntpTelNbr;
	private String busEntpFaxNbr;
	private String busEntpCntcEmail;
	private String adrLn1Txt;
	private String adrTnNm;
	private String pstCd;
	private Long dmclIsoCntryId;
	private Long dmclStPrvcId;
	private String lglEntyCd;
	private String lglEntyNm;
	private String fedTinVal;
	private Date lglEntyEffDt;
	private Date lglEntyExpirDt;
	private Long regEntyId;
	private BigDecimal ownrPct;
	private Long glBuId;
	private String glBuDesc;
	private String glBuShrtDesc;
	private Date origDt;
	private Long basCrncyTypId;
	private String totOptTypNm;
	private String balOptTypNm;
	private String errOptTypNm;
	private String elimOnlyInd;
	private String chrtfldDfnTxt;
	private String openClosStsTxt;
	private String delInd;
	private String specialFields;

	public String getPlnCd() {
		return plnCd;
	}

	public void setPlnCd(String plnCd) {
		this.plnCd = plnCd;
	}

	public String getPlnVerNbr() {
		return plnVerNbr;
	}

	public void setPlnVerNbr(String plnVerNbr) {
		this.plnVerNbr = plnVerNbr;
	}

	public Long getSrcSysId() {
		return srcSysId;
	}

	public void setSrcSysId(Long srcSysId) {
		this.srcSysId = srcSysId;
	}

	public Date getEffDtlDt() {
		return effDtlDt;
	}

	public void setEffDtlDt(Date effDtlDt) {
		this.effDtlDt = effDtlDt;
	}

	public String getCreatUserId() {
		return creatUserId;
	}

	public void setCreatUserId(String creatUserId) {
		this.creatUserId = creatUserId;
	}

	public Timestamp getCreatTmstmp() {
		return creatTmstmp;
	}

	public void setCreatTmstmp(Timestamp creatTmstmp) {
		this.creatTmstmp = creatTmstmp;
	}

	public String getUpdtUserId() {
		return updtUserId;
	}

	public void setUpdtUserId(String updtUserId) {
		this.updtUserId = updtUserId;
	}

	public Timestamp getUpdtTmstmp() {
		return updtTmstmp;
	}

	public void setUpdtTmstmp(Timestamp updtTmstmp) {
		this.updtTmstmp = updtTmstmp;
	}

	public Long getAudId() {
		return audId;
	}

	public void setAudId(Long audId) {
		this.audId = audId;
	}

	public Date getCancDtlDt() {
		return cancDtlDt;
	}

	public void setCancDtlDt(Date cancDtlDt) {
		this.cancDtlDt = cancDtlDt;
	}

	public Date getPlnRdyDt() {
		return plnRdyDt;
	}

	public void setPlnRdyDt(Date plnRdyDt) {
		this.plnRdyDt = plnRdyDt;
	}

	public Date getPlnExpirDt() {
		return plnExpirDt;
	}

	public void setPlnExpirDt(Date plnExpirDt) {
		this.plnExpirDt = plnExpirDt;
	}

	public Date getDoNotSellDt() {
		return doNotSellDt;
	}

	public void setDoNotSellDt(Date doNotSellDt) {
		this.doNotSellDt = doNotSellDt;
	}

	public Date getDoNotRenDt() {
		return doNotRenDt;
	}

	public void setDoNotRenDt(Date doNotRenDt) {
		this.doNotRenDt = doNotRenDt;
	}

	public Date getPlnEffDt() {
		return plnEffDt;
	}

	public void setPlnEffDt(Date plnEffDt) {
		this.plnEffDt = plnEffDt;
	}

	public String getRideAllwInd() {
		return rideAllwInd;
	}

	public void setRideAllwInd(String rideAllwInd) {
		this.rideAllwInd = rideAllwInd;
	}

	public String getRideOnlyInd() {
		return rideOnlyInd;
	}

	public void setRideOnlyInd(String rideOnlyInd) {
		this.rideOnlyInd = rideOnlyInd;
	}

	public String getPkgOnlyInd() {
		return pkgOnlyInd;
	}

	public void setPkgOnlyInd(String pkgOnlyInd) {
		this.pkgOnlyInd = pkgOnlyInd;
	}

	public String getPlnNm() {
		return plnNm;
	}

	public void setPlnNm(String plnNm) {
		this.plnNm = plnNm;
	}

	public String getPlnLglDesc() {
		return plnLglDesc;
	}

	public void setPlnLglDesc(String plnLglDesc) {
		this.plnLglDesc = plnLglDesc;
	}

	public Long getPlnDfnTypId() {
		return plnDfnTypId;
	}

	public void setPlnDfnTypId(Long plnDfnTypId) {
		this.plnDfnTypId = plnDfnTypId;
	}

	public String getPrdctCd() {
		return prdctCd;
	}

	public void setPrdctCd(String prdctCd) {
		this.prdctCd = prdctCd;
	}

	public String getPrdctVerNbr() {
		return prdctVerNbr;
	}

	public void setPrdctVerNbr(String prdctVerNbr) {
		this.prdctVerNbr = prdctVerNbr;
	}

	public Long getPrdctSrcSysId() {
		return prdctSrcSysId;
	}

	public void setPrdctSrcSysId(Long prdctSrcSysId) {
		this.prdctSrcSysId = prdctSrcSysId;
	}

	public Date getPrdctEffDtlDt() {
		return prdctEffDtlDt;
	}

	public void setPrdctEffDtlDt(Date prdctEffDtlDt) {
		this.prdctEffDtlDt = prdctEffDtlDt;
	}

	public String getDerivFromPlnCd() {
		return derivFromPlnCd;
	}

	public void setDerivFromPlnCd(String derivFromPlnCd) {
		this.derivFromPlnCd = derivFromPlnCd;
	}

	public String getDerivFromPlnVerNbr() {
		return derivFromPlnVerNbr;
	}

	public void setDerivFromPlnVerNbr(String derivFromPlnVerNbr) {
		this.derivFromPlnVerNbr = derivFromPlnVerNbr;
	}

	public Long getDerivFromPlnSrcSysId() {
		return derivFromPlnSrcSysId;
	}

	public void setDerivFromPlnSrcSysId(Long derivFromPlnSrcSysId) {
		this.derivFromPlnSrcSysId = derivFromPlnSrcSysId;
	}

	public Date getDerivFromPlnEffDtlDt() {
		return derivFromPlnEffDtlDt;
	}

	public void setDerivFromPlnEffDtlDt(Date derivFromPlnEffDtlDt) {
		this.derivFromPlnEffDtlDt = derivFromPlnEffDtlDt;
	}

	public Long getMtlcLvlId() {
		return mtlcLvlId;
	}

	public void setMtlcLvlId(Long mtlcLvlId) {
		this.mtlcLvlId = mtlcLvlId;
	}

	public Long getPlnTypId() {
		return plnTypId;
	}

	public void setPlnTypId(Long plnTypId) {
		this.plnTypId = plnTypId;
	}

	public Integer getErSzId() {
		return erSzId;
	}

	public void setErSzId(Integer erSzId) {
		this.erSzId = erSzId;
	}

	public Long getEeCntMethId() {
		return eeCntMethId;
	}

	public void setEeCntMethId(Long eeCntMethId) {
		this.eeCntMethId = eeCntMethId;
	}

	public Integer getEeBegnCnt() {
		return eeBegnCnt;
	}

	public void setEeBegnCnt(Integer eeBegnCnt) {
		this.eeBegnCnt = eeBegnCnt;
	}

	public Integer getEeEndCnt() {
		return eeEndCnt;
	}

	public void setEeEndCnt(Integer eeEndCnt) {
		this.eeEndCnt = eeEndCnt;
	}

	public String getErSzDesc() {
		return erSzDesc;
	}

	public void setErSzDesc(String erSzDesc) {
		this.erSzDesc = erSzDesc;
	}

	public Date getErSzEffDt() {
		return erSzEffDt;
	}

	public void setErSzEffDt(Date erSzEffDt) {
		this.erSzEffDt = erSzEffDt;
	}

	public Long getSpclNeedPlnTypId() {
		return spclNeedPlnTypId;
	}

	public void setSpclNeedPlnTypId(Long spclNeedPlnTypId) {
		this.spclNeedPlnTypId = spclNeedPlnTypId;
	}

	public String getFrmlryCd() {
		return frmlryCd;
	}

	public void setFrmlryCd(String frmlryCd) {
		this.frmlryCd = frmlryCd;
	}

	public Long getAggrDedId() {
		return aggrDedId;
	}

	public void setAggrDedId(Long aggrDedId) {
		this.aggrDedId = aggrDedId;
	}

	public String getAggrDedInd() {
		return aggrDedInd;
	}

	public void setAggrDedInd(String aggrDedInd) {
		this.aggrDedInd = aggrDedInd;
	}

	public Long getRideBenTypId() {
		return rideBenTypId;
	}

	public void setRideBenTypId(Long rideBenTypId) {
		this.rideBenTypId = rideBenTypId;
	}

	public Long getPlnOfrToTypId() {
		return plnOfrToTypId;
	}

	public void setPlnOfrToTypId(Long plnOfrToTypId) {
		this.plnOfrToTypId = plnOfrToTypId;
	}

	public Long getPlnCatgyId() {
		return plnCatgyId;
	}

	public void setPlnCatgyId(Long plnCatgyId) {
		this.plnCatgyId = plnCatgyId;
	}

	public Long getPlnSbcatgyId() {
		return plnSbcatgyId;
	}

	public void setPlnSbcatgyId(Long plnSbcatgyId) {
		this.plnSbcatgyId = plnSbcatgyId;
	}

	public Long getBenPrdCalcBasTypId() {
		return benPrdCalcBasTypId;
	}

	public void setBenPrdCalcBasTypId(Long benPrdCalcBasTypId) {
		this.benPrdCalcBasTypId = benPrdCalcBasTypId;
	}

	public String getAggrOopMaxInd() {
		return aggrOopMaxInd;
	}

	public void setAggrOopMaxInd(String aggrOopMaxInd) {
		this.aggrOopMaxInd = aggrOopMaxInd;
	}

	public String getHsaEligInd() {
		return hsaEligInd;
	}

	public void setHsaEligInd(String hsaEligInd) {
		this.hsaEligInd = hsaEligInd;
	}

	public String getHraEligInd() {
		return hraEligInd;
	}

	public void setHraEligInd(String hraEligInd) {
		this.hraEligInd = hraEligInd;
	}

	public Long getPlnDlgtLvlId() {
		return plnDlgtLvlId;
	}

	public void setPlnDlgtLvlId(Long plnDlgtLvlId) {
		this.plnDlgtLvlId = plnDlgtLvlId;
	}

	public Long getClmAdjdPltfmId() {
		return clmAdjdPltfmId;
	}

	public void setClmAdjdPltfmId(Long clmAdjdPltfmId) {
		this.clmAdjdPltfmId = clmAdjdPltfmId;
	}

	public Long getFundArngId() {
		return fundArngId;
	}

	public void setFundArngId(Long fundArngId) {
		this.fundArngId = fundArngId;
	}

	public String getBenCd() {
		return benCd;
	}

	public void setBenCd(String benCd) {
		this.benCd = benCd;
	}

	public String getBenCdDesc() {
		return benCdDesc;
	}

	public void setBenCdDesc(String benCdDesc) {
		this.benCdDesc = benCdDesc;
	}

	public String getBenCdStdTxt() {
		return benCdStdTxt;
	}

	public void setBenCdStdTxt(String benCdStdTxt) {
		this.benCdStdTxt = benCdStdTxt;
	}

	public String getBenCdHlpTxt() {
		return benCdHlpTxt;
	}

	public void setBenCdHlpTxt(String benCdHlpTxt) {
		this.benCdHlpTxt = benCdHlpTxt;
	}

	public Date getBenCdEffDt() {
		return benCdEffDt;
	}

	public void setBenCdEffDt(Date benCdEffDt) {
		this.benCdEffDt = benCdEffDt;
	}

	public Date getBenCdExpirDt() {
		return benCdExpirDt;
	}

	public void setBenCdExpirDt(Date benCdExpirDt) {
		this.benCdExpirDt = benCdExpirDt;
	}

	public Long getHlthCovTypId() {
		return hlthCovTypId;
	}

	public void setHlthCovTypId(Long hlthCovTypId) {
		this.hlthCovTypId = hlthCovTypId;
	}

	public Date getPlnBenEffDt() {
		return plnBenEffDt;
	}

	public void setPlnBenEffDt(Date plnBenEffDt) {
		this.plnBenEffDt = plnBenEffDt;
	}

	public Date getPlnBenExpirDt() {
		return plnBenExpirDt;
	}

	public void setPlnBenExpirDt(Date plnBenExpirDt) {
		this.plnBenExpirDt = plnBenExpirDt;
	}

	public String getPlnBenOptInd() {
		return plnBenOptInd;
	}

	public void setPlnBenOptInd(String plnBenOptInd) {
		this.plnBenOptInd = plnBenOptInd;
	}

	public String getBuyupInd() {
		return buyupInd;
	}

	public void setBuyupInd(String buyupInd) {
		this.buyupInd = buyupInd;
	}

	public String getBenXcldFromCovInd() {
		return benXcldFromCovInd;
	}

	public void setBenXcldFromCovInd(String benXcldFromCovInd) {
		this.benXcldFromCovInd = benXcldFromCovInd;
	}

	public Long getEssnHlthBenCatgyId() {
		return essnHlthBenCatgyId;
	}

	public void setEssnHlthBenCatgyId(Long essnHlthBenCatgyId) {
		this.essnHlthBenCatgyId = essnHlthBenCatgyId;
	}

	public Integer getPlnCntcId() {
		return plnCntcId;
	}

	public void setPlnCntcId(Integer plnCntcId) {
		this.plnCntcId = plnCntcId;
	}

	public Long getCntcRoleId() {
		return cntcRoleId;
	}

	public void setCntcRoleId(Long cntcRoleId) {
		this.cntcRoleId = cntcRoleId;
	}

	public Integer getSuppCntcId() {
		return suppCntcId;
	}

	public void setSuppCntcId(Integer suppCntcId) {
		this.suppCntcId = suppCntcId;
	}

	public Long getIsoCntryId() {
		return isoCntryId;
	}

	public void setIsoCntryId(Long isoCntryId) {
		this.isoCntryId = isoCntryId;
	}

	public String getFstNm() {
		return fstNm;
	}

	public void setFstNm(String fstNm) {
		this.fstNm = fstNm;
	}

	public String getMidlNm() {
		return midlNm;
	}

	public void setMidlNm(String midlNm) {
		this.midlNm = midlNm;
	}

	public String getLstNm() {
		return lstNm;
	}

	public void setLstNm(String lstNm) {
		this.lstNm = lstNm;
	}

	public String getSuppCntcFullNm() {
		return suppCntcFullNm;
	}

	public void setSuppCntcFullNm(String suppCntcFullNm) {
		this.suppCntcFullNm = suppCntcFullNm;
	}

	public String getTitlTxt() {
		return titlTxt;
	}

	public void setTitlTxt(String titlTxt) {
		this.titlTxt = titlTxt;
	}

	public String getSuppCntcOrgNm() {
		return suppCntcOrgNm;
	}

	public void setSuppCntcOrgNm(String suppCntcOrgNm) {
		this.suppCntcOrgNm = suppCntcOrgNm;
	}

	public Long getNmPrfxId() {
		return nmPrfxId;
	}

	public void setNmPrfxId(Long nmPrfxId) {
		this.nmPrfxId = nmPrfxId;
	}

	public Long getNmSufxId() {
		return nmSufxId;
	}

	public void setNmSufxId(Long nmSufxId) {
		this.nmSufxId = nmSufxId;
	}

	public Long getCrdntlSufxId() {
		return crdntlSufxId;
	}

	public void setCrdntlSufxId(Long crdntlSufxId) {
		this.crdntlSufxId = crdntlSufxId;
	}

	public Long getGdrTypId() {
		return gdrTypId;
	}

	public void setGdrTypId(Long gdrTypId) {
		this.gdrTypId = gdrTypId;
	}

	public Long getCntcTypId() {
		return cntcTypId;
	}

	public void setCntcTypId(Long cntcTypId) {
		this.cntcTypId = cntcTypId;
	}

	public Long getIsoCntryTelId() {
		return isoCntryTelId;
	}

	public void setIsoCntryTelId(Long isoCntryTelId) {
		this.isoCntryTelId = isoCntryTelId;
	}

	public String getAreaCd() {
		return areaCd;
	}

	public void setAreaCd(String areaCd) {
		this.areaCd = areaCd;
	}

	public String getXchgNbr() {
		return xchgNbr;
	}

	public void setXchgNbr(String xchgNbr) {
		this.xchgNbr = xchgNbr;
	}

	public String getTelNbr() {
		return telNbr;
	}

	public void setTelNbr(String telNbr) {
		this.telNbr = telNbr;
	}

	public String getExtNbr() {
		return extNbr;
	}

	public void setExtNbr(String extNbr) {
		this.extNbr = extNbr;
	}

	public String getPriInd() {
		return priInd;
	}

	public void setPriInd(String priInd) {
		this.priInd = priInd;
	}

	public Integer getLglEntyId() {
		return lglEntyId;
	}

	public void setLglEntyId(Integer lglEntyId) {
		this.lglEntyId = lglEntyId;
	}

	public Integer getOwnrLglEntyId() {
		return ownrLglEntyId;
	}

	public void setOwnrLglEntyId(Integer ownrLglEntyId) {
		this.ownrLglEntyId = ownrLglEntyId;
	}

	public Long getMedNtwkTypId() {
		return medNtwkTypId;
	}

	public void setMedNtwkTypId(Long medNtwkTypId) {
		this.medNtwkTypId = medNtwkTypId;
	}

	public Long getIncTypId() {
		return incTypId;
	}

	public void setIncTypId(Long incTypId) {
		this.incTypId = incTypId;
	}

	public Integer getBusEntpId() {
		return busEntpId;
	}

	public void setBusEntpId(Integer busEntpId) {
		this.busEntpId = busEntpId;
	}

	public String getBusEntpNm() {
		return busEntpNm;
	}

	public void setBusEntpNm(String busEntpNm) {
		this.busEntpNm = busEntpNm;
	}

	public String getBusEntpCntcNm() {
		return busEntpCntcNm;
	}

	public void setBusEntpCntcNm(String busEntpCntcNm) {
		this.busEntpCntcNm = busEntpCntcNm;
	}

	public String getBusEntpTelNbr() {
		return busEntpTelNbr;
	}

	public void setBusEntpTelNbr(String busEntpTelNbr) {
		this.busEntpTelNbr = busEntpTelNbr;
	}

	public String getBusEntpFaxNbr() {
		return busEntpFaxNbr;
	}

	public void setBusEntpFaxNbr(String busEntpFaxNbr) {
		this.busEntpFaxNbr = busEntpFaxNbr;
	}

	public String getBusEntpCntcEmail() {
		return busEntpCntcEmail;
	}

	public void setBusEntpCntcEmail(String busEntpCntcEmail) {
		this.busEntpCntcEmail = busEntpCntcEmail;
	}

	public String getAdrLn1Txt() {
		return adrLn1Txt;
	}

	public void setAdrLn1Txt(String adrLn1Txt) {
		this.adrLn1Txt = adrLn1Txt;
	}

	public String getAdrTnNm() {
		return adrTnNm;
	}

	public void setAdrTnNm(String adrTnNm) {
		this.adrTnNm = adrTnNm;
	}

	public String getPstCd() {
		return pstCd;
	}

	public void setPstCd(String pstCd) {
		this.pstCd = pstCd;
	}

	public Long getDmclIsoCntryId() {
		return dmclIsoCntryId;
	}

	public void setDmclIsoCntryId(Long dmclIsoCntryId) {
		this.dmclIsoCntryId = dmclIsoCntryId;
	}

	public Long getDmclStPrvcId() {
		return dmclStPrvcId;
	}

	public void setDmclStPrvcId(Long dmclStPrvcId) {
		this.dmclStPrvcId = dmclStPrvcId;
	}

	public String getLglEntyCd() {
		return lglEntyCd;
	}

	public void setLglEntyCd(String lglEntyCd) {
		this.lglEntyCd = lglEntyCd;
	}

	public String getLglEntyNm() {
		return lglEntyNm;
	}

	public void setLglEntyNm(String lglEntyNm) {
		this.lglEntyNm = lglEntyNm;
	}

	public String getFedTinVal() {
		return fedTinVal;
	}

	public void setFedTinVal(String fedTinVal) {
		this.fedTinVal = fedTinVal;
	}

	public Date getLglEntyEffDt() {
		return lglEntyEffDt;
	}

	public void setLglEntyEffDt(Date lglEntyEffDt) {
		this.lglEntyEffDt = lglEntyEffDt;
	}

	public Date getLglEntyExpirDt() {
		return lglEntyExpirDt;
	}

	public void setLglEntyExpirDt(Date lglEntyExpirDt) {
		this.lglEntyExpirDt = lglEntyExpirDt;
	}

	public Long getRegEntyId() {
		return regEntyId;
	}

	public void setRegEntyId(Long regEntyId) {
		this.regEntyId = regEntyId;
	}

	public BigDecimal getOwnrPct() {
		return ownrPct;
	}

	public void setOwnrPct(BigDecimal ownrPct) {
		this.ownrPct = ownrPct;
	}

	public Long getGlBuId() {
		return glBuId;
	}

	public void setGlBuId(Long glBuId) {
		this.glBuId = glBuId;
	}

	public String getGlBuDesc() {
		return glBuDesc;
	}

	public void setGlBuDesc(String glBuDesc) {
		this.glBuDesc = glBuDesc;
	}

	public String getGlBuShrtDesc() {
		return glBuShrtDesc;
	}

	public void setGlBuShrtDesc(String glBuShrtDesc) {
		this.glBuShrtDesc = glBuShrtDesc;
	}

	public Date getOrigDt() {
		return origDt;
	}

	public void setOrigDt(Date origDt) {
		this.origDt = origDt;
	}

	public Long getBasCrncyTypId() {
		return basCrncyTypId;
	}

	public void setBasCrncyTypId(Long basCrncyTypId) {
		this.basCrncyTypId = basCrncyTypId;
	}

	public String getTotOptTypNm() {
		return totOptTypNm;
	}

	public void setTotOptTypNm(String totOptTypNm) {
		this.totOptTypNm = totOptTypNm;
	}

	public String getBalOptTypNm() {
		return balOptTypNm;
	}

	public void setBalOptTypNm(String balOptTypNm) {
		this.balOptTypNm = balOptTypNm;
	}

	public String getErrOptTypNm() {
		return errOptTypNm;
	}

	public void setErrOptTypNm(String errOptTypNm) {
		this.errOptTypNm = errOptTypNm;
	}

	public String getElimOnlyInd() {
		return elimOnlyInd;
	}

	public void setElimOnlyInd(String elimOnlyInd) {
		this.elimOnlyInd = elimOnlyInd;
	}

	public String getChrtfldDfnTxt() {
		return chrtfldDfnTxt;
	}

	public void setChrtfldDfnTxt(String chrtfldDfnTxt) {
		this.chrtfldDfnTxt = chrtfldDfnTxt;
	}

	public String getOpenClosStsTxt() {
		return openClosStsTxt;
	}

	public void setOpenClosStsTxt(String openClosStsTxt) {
		this.openClosStsTxt = openClosStsTxt;
	}

	public String getDelInd() {
		return delInd;
	}

	public void setDelInd(String delInd) {
		this.delInd = delInd;
	}

	public String getSpecialFields() {
		return specialFields;
	}

	public void setSpecialFields(String specialFields) {
		this.specialFields = specialFields;
	}


}