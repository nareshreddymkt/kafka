package com.optum.cdi.core.model.v20180129;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

public class Membership {

	public Membership() {
	}

	private String sbscrIndvId;
	private Long sbscrSrcSysId;
	private Date sbscrEffDtlDt;
	private String enrleeIndvId;
	private Long enrleeSrcSysId;
	private Date enrleeEffDtlDt;
	private Date mbrshpEffDt;
	private String custAcctId;
	private Long custAcctSrcSysId;
	private Date custAcctEffDtlDt;
	private String custPchsId;
	private Date custPchsEffDtlDt;
	private Date effDtlDt;
	private String creatUserId;
	private Timestamp creatTmstmp;
	private String updtUserId;
	private Timestamp updtTmstmp;
	private Long audId;
	private Date cancDtlDt;
	private String enrleeMbrFaceId;
	private String sbscrMbrFaceId;
	private String enrleeEligSysId;
	private String mbrSeqNbr;
	private Date mbrshpTrmDt;
	private Long mbrshpTrmRsnTypId;
	private Long covLvlId;
	private Long benStsId;
	private Long benStsRsnId;
	private Date benStsEffDt;
	private Date benStsEndDt;
	private String prdctCd;
	private String prdctVerNbr;
	private Long prdctSrcSysId;
	private Date prdctEffDtlDt;
	private Long prdctCatgyId;
	private Long prdctSbcatgyId;
	private String plnCd;
	private String plnVerNbr;
	private Long plnSrcSysId;
	private Date plnEffDtlDt;
	private Integer ntwkId;
	private Integer assocNtwkId;
	private String erSpecInd;
	private String leasNtwkInd;
	private String ntwkBrndNm;
	private Date ntwkCreatDt;
	private Date ntwkCancDt;
	private Date ntwkEffDt;
	private String clinPgmCd;
	private String clinPgmNm;
	private Date clinPgmEffDt;
	private Date clinPgmEndDt;
	private String oiInd;
	private String mbrMktNbr;
	private Date retroEligRecvDt;
	private Long retroEligOvrdRsnTypId;
	private Long ltEnrlTypId;
	private String orgId;
	private Long orgSrcSysId;
	private Date orgEffDtlDt;
	private String orgPopGrpId;
	private Date orgPopGrpEffDtlDt;
	private Long exSpoTypId;
	private Date depnPrfOfEligDt;
	private Long spknLgsltvLangId;
	private Long wrtLgsltvLangId;
	private Long eligRelId;
	private Date origMbrshpEffDt;
	private String cmlCobCovInd;
	private String govtCobCovInd;
	private Long custdTypId;
	private String crtDcreNoteTxt;
	private Integer bilEntyId;
	private String hlthcarProfId;
	private Long hlthcarProfSrcSysId;
	private Date hlthcarProfEffDtlDt;
	private Long hlthcarProfRoleTypId;
	private Date provSelEffDt;
	private String hlthcarProfFstNm;
	private String hlthcarProfMidlNm;
	private String hlthcarProfLstNm;
	private Date hlthcarProfBthDt;
	private String ssn;
	private Long hlthcarProfGdrId;
	private String bthAdrTnNm;
	private Long bthStPrvcId;
	private Long bthCntryId;
	private Long mrtlStsId;
	private Long mltrySrvcTypId;
	private Date hlthcarProfDthDt;
	private Date hlthcarProfEffStrtDt;
	private String erlyPrdScrDiagTrtVal;
	private Long provChgRsnTypId;
	private Date provSelEndDt;
	private String xstPtntInd;
	private Long physnAsgnTypId;
	private Long adrTypId;
	private Integer pracAdrSurrgKey;
	private String adrLn1Txt;
	private String adrLn2Txt;
	private String adrLn3Txt;
	private String adrLn4Txt;
	private String adrLn5Txt;
	private Integer adrVldId;
	private String adrGuidVer;
	private String resDlvrInd;
	private String adrHseNbrWoFrac;
	private String adrHseNbrFrac;
	private String adrStrPrfxDir;
	private String adrStrNm;
	private String adrStrSufxAbbr;
	private String adrStrSufxDir;
	private String adrSecUnitDesg;
	private String adrSecUnitQual;
	private String adrPoBoxNbr;
	private String adrRteDesg;
	private String adrBoxNbr;
	private String adrUrbnNm;
	private String adrTnNm;
	private String adrDlvrPtCd;
	private String adrDlvrPtChkDgt;
	private String adrCarrRteCd;
	private String latDeg;
	private String lngDeg;
	private String pstCd;
	private String pstPrfxCd;
	private String pstSufxCd;
	private String pstDesc;
	private Long tmZoneId;
	private String tmZoneNm;
	private BigDecimal utcOfstTm;
	private Long isoCntryId;
	private Long isoCntrySubdivId;
	private Long fipsStId;
	private Long fipsCntyId;
	private Long stPrvcId;
	private String bcbsItsInd;
	private String delInd;
	private String specialFields;

	public String getSbscrIndvId() {
		return sbscrIndvId;
	}

	public void setSbscrIndvId(String sbscrIndvId) {
		this.sbscrIndvId = sbscrIndvId;
	}

	public Long getSbscrSrcSysId() {
		return sbscrSrcSysId;
	}

	public void setSbscrSrcSysId(Long sbscrSrcSysId) {
		this.sbscrSrcSysId = sbscrSrcSysId;
	}

	public Date getSbscrEffDtlDt() {
		return sbscrEffDtlDt;
	}

	public void setSbscrEffDtlDt(Date sbscrEffDtlDt) {
		this.sbscrEffDtlDt = sbscrEffDtlDt;
	}

	public String getEnrleeIndvId() {
		return enrleeIndvId;
	}

	public void setEnrleeIndvId(String enrleeIndvId) {
		this.enrleeIndvId = enrleeIndvId;
	}

	public Long getEnrleeSrcSysId() {
		return enrleeSrcSysId;
	}

	public void setEnrleeSrcSysId(Long enrleeSrcSysId) {
		this.enrleeSrcSysId = enrleeSrcSysId;
	}

	public Date getEnrleeEffDtlDt() {
		return enrleeEffDtlDt;
	}

	public void setEnrleeEffDtlDt(Date enrleeEffDtlDt) {
		this.enrleeEffDtlDt = enrleeEffDtlDt;
	}

	public Date getMbrshpEffDt() {
		return mbrshpEffDt;
	}

	public void setMbrshpEffDt(Date mbrshpEffDt) {
		this.mbrshpEffDt = mbrshpEffDt;
	}

	public String getCustAcctId() {
		return custAcctId;
	}

	public void setCustAcctId(String custAcctId) {
		this.custAcctId = custAcctId;
	}

	public Long getCustAcctSrcSysId() {
		return custAcctSrcSysId;
	}

	public void setCustAcctSrcSysId(Long custAcctSrcSysId) {
		this.custAcctSrcSysId = custAcctSrcSysId;
	}

	public Date getCustAcctEffDtlDt() {
		return custAcctEffDtlDt;
	}

	public void setCustAcctEffDtlDt(Date custAcctEffDtlDt) {
		this.custAcctEffDtlDt = custAcctEffDtlDt;
	}

	public String getCustPchsId() {
		return custPchsId;
	}

	public void setCustPchsId(String custPchsId) {
		this.custPchsId = custPchsId;
	}

	public Date getCustPchsEffDtlDt() {
		return custPchsEffDtlDt;
	}

	public void setCustPchsEffDtlDt(Date custPchsEffDtlDt) {
		this.custPchsEffDtlDt = custPchsEffDtlDt;
	}

	public Date getEffDtlDt() {
		return effDtlDt;
	}

	public void setEffDtlDt(Date effDtlDt) {
		this.effDtlDt = effDtlDt;
	}

	public String getCreatUserId() {
		return creatUserId;
	}

	public void setCreatUserId(String creatUserId) {
		this.creatUserId = creatUserId;
	}

	public Timestamp getCreatTmstmp() {
		return creatTmstmp;
	}

	public void setCreatTmstmp(Timestamp creatTmstmp) {
		this.creatTmstmp = creatTmstmp;
	}

	public String getUpdtUserId() {
		return updtUserId;
	}

	public void setUpdtUserId(String updtUserId) {
		this.updtUserId = updtUserId;
	}

	public Timestamp getUpdtTmstmp() {
		return updtTmstmp;
	}

	public void setUpdtTmstmp(Timestamp updtTmstmp) {
		this.updtTmstmp = updtTmstmp;
	}

	public Long getAudId() {
		return audId;
	}

	public void setAudId(Long audId) {
		this.audId = audId;
	}

	public Date getCancDtlDt() {
		return cancDtlDt;
	}

	public void setCancDtlDt(Date cancDtlDt) {
		this.cancDtlDt = cancDtlDt;
	}

	public String getEnrleeMbrFaceId() {
		return enrleeMbrFaceId;
	}

	public void setEnrleeMbrFaceId(String enrleeMbrFaceId) {
		this.enrleeMbrFaceId = enrleeMbrFaceId;
	}

	public String getSbscrMbrFaceId() {
		return sbscrMbrFaceId;
	}

	public void setSbscrMbrFaceId(String sbscrMbrFaceId) {
		this.sbscrMbrFaceId = sbscrMbrFaceId;
	}

	public String getEnrleeEligSysId() {
		return enrleeEligSysId;
	}

	public void setEnrleeEligSysId(String enrleeEligSysId) {
		this.enrleeEligSysId = enrleeEligSysId;
	}

	public String getMbrSeqNbr() {
		return mbrSeqNbr;
	}

	public void setMbrSeqNbr(String mbrSeqNbr) {
		this.mbrSeqNbr = mbrSeqNbr;
	}

	public Date getMbrshpTrmDt() {
		return mbrshpTrmDt;
	}

	public void setMbrshpTrmDt(Date mbrshpTrmDt) {
		this.mbrshpTrmDt = mbrshpTrmDt;
	}

	public Long getMbrshpTrmRsnTypId() {
		return mbrshpTrmRsnTypId;
	}

	public void setMbrshpTrmRsnTypId(Long mbrshpTrmRsnTypId) {
		this.mbrshpTrmRsnTypId = mbrshpTrmRsnTypId;
	}

	public Long getCovLvlId() {
		return covLvlId;
	}

	public void setCovLvlId(Long covLvlId) {
		this.covLvlId = covLvlId;
	}

	public Long getBenStsId() {
		return benStsId;
	}

	public void setBenStsId(Long benStsId) {
		this.benStsId = benStsId;
	}

	public Long getBenStsRsnId() {
		return benStsRsnId;
	}

	public void setBenStsRsnId(Long benStsRsnId) {
		this.benStsRsnId = benStsRsnId;
	}

	public Date getBenStsEffDt() {
		return benStsEffDt;
	}

	public void setBenStsEffDt(Date benStsEffDt) {
		this.benStsEffDt = benStsEffDt;
	}

	public Date getBenStsEndDt() {
		return benStsEndDt;
	}

	public void setBenStsEndDt(Date benStsEndDt) {
		this.benStsEndDt = benStsEndDt;
	}

	public String getPrdctCd() {
		return prdctCd;
	}

	public void setPrdctCd(String prdctCd) {
		this.prdctCd = prdctCd;
	}

	public String getPrdctVerNbr() {
		return prdctVerNbr;
	}

	public void setPrdctVerNbr(String prdctVerNbr) {
		this.prdctVerNbr = prdctVerNbr;
	}

	public Long getPrdctSrcSysId() {
		return prdctSrcSysId;
	}

	public void setPrdctSrcSysId(Long prdctSrcSysId) {
		this.prdctSrcSysId = prdctSrcSysId;
	}

	public Date getPrdctEffDtlDt() {
		return prdctEffDtlDt;
	}

	public void setPrdctEffDtlDt(Date prdctEffDtlDt) {
		this.prdctEffDtlDt = prdctEffDtlDt;
	}

	public Long getPrdctCatgyId() {
		return prdctCatgyId;
	}

	public void setPrdctCatgyId(Long prdctCatgyId) {
		this.prdctCatgyId = prdctCatgyId;
	}

	public Long getPrdctSbcatgyId() {
		return prdctSbcatgyId;
	}

	public void setPrdctSbcatgyId(Long prdctSbcatgyId) {
		this.prdctSbcatgyId = prdctSbcatgyId;
	}

	public String getPlnCd() {
		return plnCd;
	}

	public void setPlnCd(String plnCd) {
		this.plnCd = plnCd;
	}

	public String getPlnVerNbr() {
		return plnVerNbr;
	}

	public void setPlnVerNbr(String plnVerNbr) {
		this.plnVerNbr = plnVerNbr;
	}

	public Long getPlnSrcSysId() {
		return plnSrcSysId;
	}

	public void setPlnSrcSysId(Long plnSrcSysId) {
		this.plnSrcSysId = plnSrcSysId;
	}

	public Date getPlnEffDtlDt() {
		return plnEffDtlDt;
	}

	public void setPlnEffDtlDt(Date plnEffDtlDt) {
		this.plnEffDtlDt = plnEffDtlDt;
	}

	public Integer getNtwkId() {
		return ntwkId;
	}

	public void setNtwkId(Integer ntwkId) {
		this.ntwkId = ntwkId;
	}

	public Integer getAssocNtwkId() {
		return assocNtwkId;
	}

	public void setAssocNtwkId(Integer assocNtwkId) {
		this.assocNtwkId = assocNtwkId;
	}

	public String getErSpecInd() {
		return erSpecInd;
	}

	public void setErSpecInd(String erSpecInd) {
		this.erSpecInd = erSpecInd;
	}

	public String getLeasNtwkInd() {
		return leasNtwkInd;
	}

	public void setLeasNtwkInd(String leasNtwkInd) {
		this.leasNtwkInd = leasNtwkInd;
	}

	public String getNtwkBrndNm() {
		return ntwkBrndNm;
	}

	public void setNtwkBrndNm(String ntwkBrndNm) {
		this.ntwkBrndNm = ntwkBrndNm;
	}

	public Date getNtwkCreatDt() {
		return ntwkCreatDt;
	}

	public void setNtwkCreatDt(Date ntwkCreatDt) {
		this.ntwkCreatDt = ntwkCreatDt;
	}

	public Date getNtwkCancDt() {
		return ntwkCancDt;
	}

	public void setNtwkCancDt(Date ntwkCancDt) {
		this.ntwkCancDt = ntwkCancDt;
	}

	public Date getNtwkEffDt() {
		return ntwkEffDt;
	}

	public void setNtwkEffDt(Date ntwkEffDt) {
		this.ntwkEffDt = ntwkEffDt;
	}

	public String getClinPgmCd() {
		return clinPgmCd;
	}

	public void setClinPgmCd(String clinPgmCd) {
		this.clinPgmCd = clinPgmCd;
	}

	public String getClinPgmNm() {
		return clinPgmNm;
	}

	public void setClinPgmNm(String clinPgmNm) {
		this.clinPgmNm = clinPgmNm;
	}

	public Date getClinPgmEffDt() {
		return clinPgmEffDt;
	}

	public void setClinPgmEffDt(Date clinPgmEffDt) {
		this.clinPgmEffDt = clinPgmEffDt;
	}

	public Date getClinPgmEndDt() {
		return clinPgmEndDt;
	}

	public void setClinPgmEndDt(Date clinPgmEndDt) {
		this.clinPgmEndDt = clinPgmEndDt;
	}

	public String getOiInd() {
		return oiInd;
	}

	public void setOiInd(String oiInd) {
		this.oiInd = oiInd;
	}

	public String getMbrMktNbr() {
		return mbrMktNbr;
	}

	public void setMbrMktNbr(String mbrMktNbr) {
		this.mbrMktNbr = mbrMktNbr;
	}

	public Date getRetroEligRecvDt() {
		return retroEligRecvDt;
	}

	public void setRetroEligRecvDt(Date retroEligRecvDt) {
		this.retroEligRecvDt = retroEligRecvDt;
	}

	public Long getRetroEligOvrdRsnTypId() {
		return retroEligOvrdRsnTypId;
	}

	public void setRetroEligOvrdRsnTypId(Long retroEligOvrdRsnTypId) {
		this.retroEligOvrdRsnTypId = retroEligOvrdRsnTypId;
	}

	public Long getLtEnrlTypId() {
		return ltEnrlTypId;
	}

	public void setLtEnrlTypId(Long ltEnrlTypId) {
		this.ltEnrlTypId = ltEnrlTypId;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public Long getOrgSrcSysId() {
		return orgSrcSysId;
	}

	public void setOrgSrcSysId(Long orgSrcSysId) {
		this.orgSrcSysId = orgSrcSysId;
	}

	public Date getOrgEffDtlDt() {
		return orgEffDtlDt;
	}

	public void setOrgEffDtlDt(Date orgEffDtlDt) {
		this.orgEffDtlDt = orgEffDtlDt;
	}

	public String getOrgPopGrpId() {
		return orgPopGrpId;
	}

	public void setOrgPopGrpId(String orgPopGrpId) {
		this.orgPopGrpId = orgPopGrpId;
	}

	public Date getOrgPopGrpEffDtlDt() {
		return orgPopGrpEffDtlDt;
	}

	public void setOrgPopGrpEffDtlDt(Date orgPopGrpEffDtlDt) {
		this.orgPopGrpEffDtlDt = orgPopGrpEffDtlDt;
	}

	public Long getExSpoTypId() {
		return exSpoTypId;
	}

	public void setExSpoTypId(Long exSpoTypId) {
		this.exSpoTypId = exSpoTypId;
	}

	public Date getDepnPrfOfEligDt() {
		return depnPrfOfEligDt;
	}

	public void setDepnPrfOfEligDt(Date depnPrfOfEligDt) {
		this.depnPrfOfEligDt = depnPrfOfEligDt;
	}

	public Long getSpknLgsltvLangId() {
		return spknLgsltvLangId;
	}

	public void setSpknLgsltvLangId(Long spknLgsltvLangId) {
		this.spknLgsltvLangId = spknLgsltvLangId;
	}

	public Long getWrtLgsltvLangId() {
		return wrtLgsltvLangId;
	}

	public void setWrtLgsltvLangId(Long wrtLgsltvLangId) {
		this.wrtLgsltvLangId = wrtLgsltvLangId;
	}

	public Long getEligRelId() {
		return eligRelId;
	}

	public void setEligRelId(Long eligRelId) {
		this.eligRelId = eligRelId;
	}

	public Date getOrigMbrshpEffDt() {
		return origMbrshpEffDt;
	}

	public void setOrigMbrshpEffDt(Date origMbrshpEffDt) {
		this.origMbrshpEffDt = origMbrshpEffDt;
	}

	public String getCmlCobCovInd() {
		return cmlCobCovInd;
	}

	public void setCmlCobCovInd(String cmlCobCovInd) {
		this.cmlCobCovInd = cmlCobCovInd;
	}

	public String getGovtCobCovInd() {
		return govtCobCovInd;
	}

	public void setGovtCobCovInd(String govtCobCovInd) {
		this.govtCobCovInd = govtCobCovInd;
	}

	public Long getCustdTypId() {
		return custdTypId;
	}

	public void setCustdTypId(Long custdTypId) {
		this.custdTypId = custdTypId;
	}

	public String getCrtDcreNoteTxt() {
		return crtDcreNoteTxt;
	}

	public void setCrtDcreNoteTxt(String crtDcreNoteTxt) {
		this.crtDcreNoteTxt = crtDcreNoteTxt;
	}

	public Integer getBilEntyId() {
		return bilEntyId;
	}

	public void setBilEntyId(Integer bilEntyId) {
		this.bilEntyId = bilEntyId;
	}

	public String getHlthcarProfId() {
		return hlthcarProfId;
	}

	public void setHlthcarProfId(String hlthcarProfId) {
		this.hlthcarProfId = hlthcarProfId;
	}

	public Long getHlthcarProfSrcSysId() {
		return hlthcarProfSrcSysId;
	}

	public void setHlthcarProfSrcSysId(Long hlthcarProfSrcSysId) {
		this.hlthcarProfSrcSysId = hlthcarProfSrcSysId;
	}

	public Date getHlthcarProfEffDtlDt() {
		return hlthcarProfEffDtlDt;
	}

	public void setHlthcarProfEffDtlDt(Date hlthcarProfEffDtlDt) {
		this.hlthcarProfEffDtlDt = hlthcarProfEffDtlDt;
	}

	public Long getHlthcarProfRoleTypId() {
		return hlthcarProfRoleTypId;
	}

	public void setHlthcarProfRoleTypId(Long hlthcarProfRoleTypId) {
		this.hlthcarProfRoleTypId = hlthcarProfRoleTypId;
	}

	public Date getProvSelEffDt() {
		return provSelEffDt;
	}

	public void setProvSelEffDt(Date provSelEffDt) {
		this.provSelEffDt = provSelEffDt;
	}

	public String getHlthcarProfFstNm() {
		return hlthcarProfFstNm;
	}

	public void setHlthcarProfFstNm(String hlthcarProfFstNm) {
		this.hlthcarProfFstNm = hlthcarProfFstNm;
	}

	public String getHlthcarProfMidlNm() {
		return hlthcarProfMidlNm;
	}

	public void setHlthcarProfMidlNm(String hlthcarProfMidlNm) {
		this.hlthcarProfMidlNm = hlthcarProfMidlNm;
	}

	public String getHlthcarProfLstNm() {
		return hlthcarProfLstNm;
	}

	public void setHlthcarProfLstNm(String hlthcarProfLstNm) {
		this.hlthcarProfLstNm = hlthcarProfLstNm;
	}

	public Date getHlthcarProfBthDt() {
		return hlthcarProfBthDt;
	}

	public void setHlthcarProfBthDt(Date hlthcarProfBthDt) {
		this.hlthcarProfBthDt = hlthcarProfBthDt;
	}

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public Long getHlthcarProfGdrId() {
		return hlthcarProfGdrId;
	}

	public void setHlthcarProfGdrId(Long hlthcarProfGdrId) {
		this.hlthcarProfGdrId = hlthcarProfGdrId;
	}

	public String getBthAdrTnNm() {
		return bthAdrTnNm;
	}

	public void setBthAdrTnNm(String bthAdrTnNm) {
		this.bthAdrTnNm = bthAdrTnNm;
	}

	public Long getBthStPrvcId() {
		return bthStPrvcId;
	}

	public void setBthStPrvcId(Long bthStPrvcId) {
		this.bthStPrvcId = bthStPrvcId;
	}

	public Long getBthCntryId() {
		return bthCntryId;
	}

	public void setBthCntryId(Long bthCntryId) {
		this.bthCntryId = bthCntryId;
	}

	public Long getMrtlStsId() {
		return mrtlStsId;
	}

	public void setMrtlStsId(Long mrtlStsId) {
		this.mrtlStsId = mrtlStsId;
	}

	public Long getMltrySrvcTypId() {
		return mltrySrvcTypId;
	}

	public void setMltrySrvcTypId(Long mltrySrvcTypId) {
		this.mltrySrvcTypId = mltrySrvcTypId;
	}

	public Date getHlthcarProfDthDt() {
		return hlthcarProfDthDt;
	}

	public void setHlthcarProfDthDt(Date hlthcarProfDthDt) {
		this.hlthcarProfDthDt = hlthcarProfDthDt;
	}

	public Date getHlthcarProfEffStrtDt() {
		return hlthcarProfEffStrtDt;
	}

	public void setHlthcarProfEffStrtDt(Date hlthcarProfEffStrtDt) {
		this.hlthcarProfEffStrtDt = hlthcarProfEffStrtDt;
	}

	public String getErlyPrdScrDiagTrtVal() {
		return erlyPrdScrDiagTrtVal;
	}

	public void setErlyPrdScrDiagTrtVal(String erlyPrdScrDiagTrtVal) {
		this.erlyPrdScrDiagTrtVal = erlyPrdScrDiagTrtVal;
	}

	public Long getProvChgRsnTypId() {
		return provChgRsnTypId;
	}

	public void setProvChgRsnTypId(Long provChgRsnTypId) {
		this.provChgRsnTypId = provChgRsnTypId;
	}

	public Date getProvSelEndDt() {
		return provSelEndDt;
	}

	public void setProvSelEndDt(Date provSelEndDt) {
		this.provSelEndDt = provSelEndDt;
	}

	public String getXstPtntInd() {
		return xstPtntInd;
	}

	public void setXstPtntInd(String xstPtntInd) {
		this.xstPtntInd = xstPtntInd;
	}

	public Long getPhysnAsgnTypId() {
		return physnAsgnTypId;
	}

	public void setPhysnAsgnTypId(Long physnAsgnTypId) {
		this.physnAsgnTypId = physnAsgnTypId;
	}

	public Long getAdrTypId() {
		return adrTypId;
	}

	public void setAdrTypId(Long adrTypId) {
		this.adrTypId = adrTypId;
	}

	public Integer getPracAdrSurrgKey() {
		return pracAdrSurrgKey;
	}

	public void setPracAdrSurrgKey(Integer pracAdrSurrgKey) {
		this.pracAdrSurrgKey = pracAdrSurrgKey;
	}

	public String getAdrLn1Txt() {
		return adrLn1Txt;
	}

	public void setAdrLn1Txt(String adrLn1Txt) {
		this.adrLn1Txt = adrLn1Txt;
	}

	public String getAdrLn2Txt() {
		return adrLn2Txt;
	}

	public void setAdrLn2Txt(String adrLn2Txt) {
		this.adrLn2Txt = adrLn2Txt;
	}

	public String getAdrLn3Txt() {
		return adrLn3Txt;
	}

	public void setAdrLn3Txt(String adrLn3Txt) {
		this.adrLn3Txt = adrLn3Txt;
	}

	public String getAdrLn4Txt() {
		return adrLn4Txt;
	}

	public void setAdrLn4Txt(String adrLn4Txt) {
		this.adrLn4Txt = adrLn4Txt;
	}

	public String getAdrLn5Txt() {
		return adrLn5Txt;
	}

	public void setAdrLn5Txt(String adrLn5Txt) {
		this.adrLn5Txt = adrLn5Txt;
	}

	public Integer getAdrVldId() {
		return adrVldId;
	}

	public void setAdrVldId(Integer adrVldId) {
		this.adrVldId = adrVldId;
	}

	public String getAdrGuidVer() {
		return adrGuidVer;
	}

	public void setAdrGuidVer(String adrGuidVer) {
		this.adrGuidVer = adrGuidVer;
	}

	public String getResDlvrInd() {
		return resDlvrInd;
	}

	public void setResDlvrInd(String resDlvrInd) {
		this.resDlvrInd = resDlvrInd;
	}

	public String getAdrHseNbrWoFrac() {
		return adrHseNbrWoFrac;
	}

	public void setAdrHseNbrWoFrac(String adrHseNbrWoFrac) {
		this.adrHseNbrWoFrac = adrHseNbrWoFrac;
	}

	public String getAdrHseNbrFrac() {
		return adrHseNbrFrac;
	}

	public void setAdrHseNbrFrac(String adrHseNbrFrac) {
		this.adrHseNbrFrac = adrHseNbrFrac;
	}

	public String getAdrStrPrfxDir() {
		return adrStrPrfxDir;
	}

	public void setAdrStrPrfxDir(String adrStrPrfxDir) {
		this.adrStrPrfxDir = adrStrPrfxDir;
	}

	public String getAdrStrNm() {
		return adrStrNm;
	}

	public void setAdrStrNm(String adrStrNm) {
		this.adrStrNm = adrStrNm;
	}

	public String getAdrStrSufxAbbr() {
		return adrStrSufxAbbr;
	}

	public void setAdrStrSufxAbbr(String adrStrSufxAbbr) {
		this.adrStrSufxAbbr = adrStrSufxAbbr;
	}

	public String getAdrStrSufxDir() {
		return adrStrSufxDir;
	}

	public void setAdrStrSufxDir(String adrStrSufxDir) {
		this.adrStrSufxDir = adrStrSufxDir;
	}

	public String getAdrSecUnitDesg() {
		return adrSecUnitDesg;
	}

	public void setAdrSecUnitDesg(String adrSecUnitDesg) {
		this.adrSecUnitDesg = adrSecUnitDesg;
	}

	public String getAdrSecUnitQual() {
		return adrSecUnitQual;
	}

	public void setAdrSecUnitQual(String adrSecUnitQual) {
		this.adrSecUnitQual = adrSecUnitQual;
	}

	public String getAdrPoBoxNbr() {
		return adrPoBoxNbr;
	}

	public void setAdrPoBoxNbr(String adrPoBoxNbr) {
		this.adrPoBoxNbr = adrPoBoxNbr;
	}

	public String getAdrRteDesg() {
		return adrRteDesg;
	}

	public void setAdrRteDesg(String adrRteDesg) {
		this.adrRteDesg = adrRteDesg;
	}

	public String getAdrBoxNbr() {
		return adrBoxNbr;
	}

	public void setAdrBoxNbr(String adrBoxNbr) {
		this.adrBoxNbr = adrBoxNbr;
	}

	public String getAdrUrbnNm() {
		return adrUrbnNm;
	}

	public void setAdrUrbnNm(String adrUrbnNm) {
		this.adrUrbnNm = adrUrbnNm;
	}

	public String getAdrTnNm() {
		return adrTnNm;
	}

	public void setAdrTnNm(String adrTnNm) {
		this.adrTnNm = adrTnNm;
	}

	public String getAdrDlvrPtCd() {
		return adrDlvrPtCd;
	}

	public void setAdrDlvrPtCd(String adrDlvrPtCd) {
		this.adrDlvrPtCd = adrDlvrPtCd;
	}

	public String getAdrDlvrPtChkDgt() {
		return adrDlvrPtChkDgt;
	}

	public void setAdrDlvrPtChkDgt(String adrDlvrPtChkDgt) {
		this.adrDlvrPtChkDgt = adrDlvrPtChkDgt;
	}

	public String getAdrCarrRteCd() {
		return adrCarrRteCd;
	}

	public void setAdrCarrRteCd(String adrCarrRteCd) {
		this.adrCarrRteCd = adrCarrRteCd;
	}

	public String getLatDeg() {
		return latDeg;
	}

	public void setLatDeg(String latDeg) {
		this.latDeg = latDeg;
	}

	public String getLngDeg() {
		return lngDeg;
	}

	public void setLngDeg(String lngDeg) {
		this.lngDeg = lngDeg;
	}

	public String getPstCd() {
		return pstCd;
	}

	public void setPstCd(String pstCd) {
		this.pstCd = pstCd;
	}

	public String getPstPrfxCd() {
		return pstPrfxCd;
	}

	public void setPstPrfxCd(String pstPrfxCd) {
		this.pstPrfxCd = pstPrfxCd;
	}

	public String getPstSufxCd() {
		return pstSufxCd;
	}

	public void setPstSufxCd(String pstSufxCd) {
		this.pstSufxCd = pstSufxCd;
	}

	public String getPstDesc() {
		return pstDesc;
	}

	public void setPstDesc(String pstDesc) {
		this.pstDesc = pstDesc;
	}

	public Long getTmZoneId() {
		return tmZoneId;
	}

	public void setTmZoneId(Long tmZoneId) {
		this.tmZoneId = tmZoneId;
	}

	public String getTmZoneNm() {
		return tmZoneNm;
	}

	public void setTmZoneNm(String tmZoneNm) {
		this.tmZoneNm = tmZoneNm;
	}

	public BigDecimal getUtcOfstTm() {
		return utcOfstTm;
	}

	public void setUtcOfstTm(BigDecimal utcOfstTm) {
		this.utcOfstTm = utcOfstTm;
	}

	public Long getIsoCntryId() {
		return isoCntryId;
	}

	public void setIsoCntryId(Long isoCntryId) {
		this.isoCntryId = isoCntryId;
	}

	public Long getIsoCntrySubdivId() {
		return isoCntrySubdivId;
	}

	public void setIsoCntrySubdivId(Long isoCntrySubdivId) {
		this.isoCntrySubdivId = isoCntrySubdivId;
	}

	public Long getFipsStId() {
		return fipsStId;
	}

	public void setFipsStId(Long fipsStId) {
		this.fipsStId = fipsStId;
	}

	public Long getFipsCntyId() {
		return fipsCntyId;
	}

	public void setFipsCntyId(Long fipsCntyId) {
		this.fipsCntyId = fipsCntyId;
	}

	public Long getStPrvcId() {
		return stPrvcId;
	}

	public void setStPrvcId(Long stPrvcId) {
		this.stPrvcId = stPrvcId;
	}

	public String getBcbsItsInd() {
		return bcbsItsInd;
	}

	public void setBcbsItsInd(String bcbsItsInd) {
		this.bcbsItsInd = bcbsItsInd;
	}

	public String getDelInd() {
		return delInd;
	}

	public void setDelInd(String delInd) {
		this.delInd = delInd;
	}

	public String getSpecialFields() {
		return specialFields;
	}

	public void setSpecialFields(String specialFields) {
		this.specialFields = specialFields;
	}


}