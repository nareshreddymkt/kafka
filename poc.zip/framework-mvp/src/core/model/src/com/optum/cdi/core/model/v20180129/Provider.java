package com.optum.cdi.core.model.v20180129;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

public class Provider {

	public Provider() {
	}

	private String provId;
	private Long srcSysId;
	private Date effDtlDt;
	private String creatUserId;
	private Timestamp creatTmstmp;
	private String updtUserId;
	private Timestamp updtTmstmp;
	private String audId;
	private Date cancDtlDt;
	private Long provPtyTypId;
	private Date provEffDt;
	private String nonProvSpclHndlInd;
	private String cmptVceRspnNbr;
	private Date provClmRnotDt;
	private Date provTrmDt;
	private Long provTrmRsnTypId;
	private String atypclInd;
	private Date provCancDt;
	private String hlthcarOrgId;
	private Long hlthcarOrgSrcSysId;
	private Date hlthcarOrgEffDtlDt;
	private Long hlthcarOrgTinTypId;
	private String hlthcarOrgTin;
	private Long hlthcarOrgTypId;
	private String hlthcarOrgNm;
	private String provLglNm;
	private Long hlthcarProfNmPrfxId;
	private String hlthcarProfFstNm;
	private String hlthcarProfMidlNm;
	private String hlthcarProfLstNm;
	private Long hlthcarProfNmSufxId;
	private Long hlthcarProfCrdntlSufxId;
	private Date hlthcarProfBthDt;
	private String bthAdrTnNm;
	private String ssn;
	private Long mrtlStsId;
	private Date hlthcarProfDthDt;
	private Date hlthcarProfEffStrtDt;
	private String erlyPrdScrDiagTrt;
	private Long hlthcarProfGdrId;
	private Long bthCntyId;
	private Long bthStPrvcId;
	private Long bthCntryId;
	private Long mltrySrvcTypId;
	private Long priPhrmDspnsTypId;
	private Long secPhrmDspnsTypId;
	private Long phrmClssTypId;
	private Date medcrAsgnDt;
	private String ncpdpNbr;
	private Long provHlthcarOrgOwnrId;
	private Long provStLocTypId;
	private Long provEnrlStsId;
	private Long provTinTypId;
	private String provTin;
	private String taxBNtcInd;
	private String tinLglOwnrNm;
	private Date tinEffDt;
	private Date tinCancDt;
	private Date taxBNtcDt;
	private String nonPrftInd;
	private Long incTypId;
	private Long w9CpyTypId;
	private Long adrTypId;
	private String adrLn1Txt;
	private String adrLn2Txt;
	private String adrLn3Txt;
	private String adrLn4Txt;
	private String adrLn5Txt;
	private Integer adrVldId;
	private String adrGuidVer;
	private String resDlvrInd;
	private String adrHseNbrWoFrac;
	private String adrHseNbrFrac;
	private String adrStrPrfxDir;
	private String adrStrNm;
	private String adrStrSufxAbbr;
	private String adrStrSufxDir;
	private String adrSecUnitDesg;
	private String adrSecUnitQual;
	private String adrPoBoxNbr;
	private String adrRteDesg;
	private String adrBoxNbr;
	private String adrUrbnNm;
	private String adrTnNm;
	private String adrDlvrPtCd;
	private String adrDlvrPtChkDgt;
	private String adrCarrRteCd;
	private String latDeg;
	private String lngDeg;
	private String pstCd;
	private String pstPrfxCd;
	private String pstSufxCd;
	private String pstDesc;
	private Long tmZoneId;
	private String tmZoneNm;
	private BigDecimal utcOfstTm;
	private Long isoCntryId;
	private Long isoCntrySubdivId;
	private Long fipsStId;
	private Long fipsCntyId;
	private Long stPrvcId;
	private Long othrIdTypCd;
	private Long othrIdSrcSysId;
	private String othrIdDesc;
	private String othrId;
	private Date othrIdEffDt;
	private Date othrIdCancDt;
	private Long othrIdIssCntryId;
	private Long othrIdIssStPrvcId;
	private Integer othrIdGeoAreaId;
	private String othrIdGeoAreaNm;
	private Long othrIdGeoAreaTypId;
	private Long provTypId;
	private Long provClssTypId;
	private Long provSpclTypId;
	private Long provSpclTyp2Id;
	private Long provSpclTyp3Id;
	private Long provSpclTyp4Id;
	private Long provSpclTyp5Id;
	private Long provSpclTyp6Id;
	private Long provSpclTyp7Id;
	private Long provSpclTyp8Id;
	private Long provSpclTyp9Id;
	private Long provSpclTyp10Id;
	private Long provSpclTyp11Id;
	private Long provSpclTyp12Id;
	private Long cntcRoleId;
	private String cntcTitl;
	private Long cntcNmPrfxId;
	private String cntcFstNm;
	private String cntcMidlNm;
	private String cntcMidlInitTxt;
	private String cntcLstNm;
	private Long cntcNmSufxId;
	private String cntcCrdntlSufx;
	private Long cntcStsId;
	private Long cmnctTypId;
	private String elctrCmnctTxt;
	private Long isoCntryTelId;
	private String areaCd;
	private String xchgNbr;
	private String telNbr;
	private String extNbr;
	private String priTelInd;
	private Long cmnctStsId;
	private Integer agrId;
	private Long agrTypId;
	private Integer agrLglDocId;
	private Long agrLglDocTypId;
	private Date agrEffDt;
	private Date agrCancDt;
	private String ovpayRecovInd;
	private Long provAgrTrmRsnTypId;
	private Long iptntTrnsfTypId;
	private Date agrSrvcProvEffDt;
	private Date agrSrvcProvCancDt;
	private Long provAsgnTypId;
	private String recovWaitPrdCnt;
	private Long recovWaitPrdMsrId;
	private BigDecimal recovDdlnPrdCnt;
	private Long recovDdlnPrdMsrId;
	private String medcrIdNbr;
	private Date medcrIdEffDt;
	private Date medcrIdCancDt;
	private Long medcrIssCntryId;
	private Long medcrIssStPrvcId;
	private String medcrAtypclInd;
	private Long medcrStsTypId;
	private String medcdIdNbr;
	private Date medcdIdEffDt;
	private Date medcdIdCancDt;
	private Long medcdIssCntryId;
	private Long medcdIssStPrvcId;
	private String provMedcdLocCd;
	private String medcdAtypclInd;
	private Date medcdVldDt;
	private Long medcdStsTypId;
	private Integer npiVal;
	private String npiNm;
	private Date npiEnmrtnDt;
	private String replNpi;
	private Integer prevNpi;
	private String provFein;
	private Date npiActvDt;
	private Date npiDactvDt;
	private Date npiLstUpdtDt;
	private Long drgLicTypId;
	private String drgLicNbr;
	private Integer drgLicGeoAreaId;
	private String drgLicGeoAreaNm;
	private Long drgLicGeoAreaTypId;
	private Date drgLicEffDt;
	private Date drgLicExpirDt;
	private Long drgSchedTypId;
	private Long drgLicStsTypId;
	private Long licTypId;
	private String licNbr;
	private Date licEffDt;
	private Date licExpirDt;
	private String licBdNbr;
	private String licBdDesc;
	private Date licIssDt;
	private Long licCntryId;
	private Integer licGeoAreaId;
	private String licGeoAreaNm;
	private Long licGeoAreaTypId;
	private Long licStsTypId;
	private Long licTrmRsnTypId;
	private Integer affilProvId;
	private Long affilTypId;
	private Date affilEffDt;
	private Date affilCancDt;
	private String priHospAffilInd;
	private Long admisPrvlgTypId;
	private String affilHospDeptNm;
	private Long affilStsTypId;
	private String bcbsItsInd;
	private String faxNbr;
	private String provPrtcpInd;
	private String delInd;
	private String specialFields;

	public String getProvId() {
		return provId;
	}

	public void setProvId(String provId) {
		this.provId = provId;
	}

	public Long getSrcSysId() {
		return srcSysId;
	}

	public void setSrcSysId(Long srcSysId) {
		this.srcSysId = srcSysId;
	}

	public Date getEffDtlDt() {
		return effDtlDt;
	}

	public void setEffDtlDt(Date effDtlDt) {
		this.effDtlDt = effDtlDt;
	}

	public String getCreatUserId() {
		return creatUserId;
	}

	public void setCreatUserId(String creatUserId) {
		this.creatUserId = creatUserId;
	}

	public Timestamp getCreatTmstmp() {
		return creatTmstmp;
	}

	public void setCreatTmstmp(Timestamp creatTmstmp) {
		this.creatTmstmp = creatTmstmp;
	}

	public String getUpdtUserId() {
		return updtUserId;
	}

	public void setUpdtUserId(String updtUserId) {
		this.updtUserId = updtUserId;
	}

	public Timestamp getUpdtTmstmp() {
		return updtTmstmp;
	}

	public void setUpdtTmstmp(Timestamp updtTmstmp) {
		this.updtTmstmp = updtTmstmp;
	}

	public String getAudId() {
		return audId;
	}

	public void setAudId(String audId) {
		this.audId = audId;
	}

	public Date getCancDtlDt() {
		return cancDtlDt;
	}

	public void setCancDtlDt(Date cancDtlDt) {
		this.cancDtlDt = cancDtlDt;
	}

	public Long getProvPtyTypId() {
		return provPtyTypId;
	}

	public void setProvPtyTypId(Long provPtyTypId) {
		this.provPtyTypId = provPtyTypId;
	}

	public Date getProvEffDt() {
		return provEffDt;
	}

	public void setProvEffDt(Date provEffDt) {
		this.provEffDt = provEffDt;
	}

	public String getNonProvSpclHndlInd() {
		return nonProvSpclHndlInd;
	}

	public void setNonProvSpclHndlInd(String nonProvSpclHndlInd) {
		this.nonProvSpclHndlInd = nonProvSpclHndlInd;
	}

	public String getCmptVceRspnNbr() {
		return cmptVceRspnNbr;
	}

	public void setCmptVceRspnNbr(String cmptVceRspnNbr) {
		this.cmptVceRspnNbr = cmptVceRspnNbr;
	}

	public Date getProvClmRnotDt() {
		return provClmRnotDt;
	}

	public void setProvClmRnotDt(Date provClmRnotDt) {
		this.provClmRnotDt = provClmRnotDt;
	}

	public Date getProvTrmDt() {
		return provTrmDt;
	}

	public void setProvTrmDt(Date provTrmDt) {
		this.provTrmDt = provTrmDt;
	}

	public Long getProvTrmRsnTypId() {
		return provTrmRsnTypId;
	}

	public void setProvTrmRsnTypId(Long provTrmRsnTypId) {
		this.provTrmRsnTypId = provTrmRsnTypId;
	}

	public String getAtypclInd() {
		return atypclInd;
	}

	public void setAtypclInd(String atypclInd) {
		this.atypclInd = atypclInd;
	}

	public Date getProvCancDt() {
		return provCancDt;
	}

	public void setProvCancDt(Date provCancDt) {
		this.provCancDt = provCancDt;
	}

	public String getHlthcarOrgId() {
		return hlthcarOrgId;
	}

	public void setHlthcarOrgId(String hlthcarOrgId) {
		this.hlthcarOrgId = hlthcarOrgId;
	}

	public Long getHlthcarOrgSrcSysId() {
		return hlthcarOrgSrcSysId;
	}

	public void setHlthcarOrgSrcSysId(Long hlthcarOrgSrcSysId) {
		this.hlthcarOrgSrcSysId = hlthcarOrgSrcSysId;
	}

	public Date getHlthcarOrgEffDtlDt() {
		return hlthcarOrgEffDtlDt;
	}

	public void setHlthcarOrgEffDtlDt(Date hlthcarOrgEffDtlDt) {
		this.hlthcarOrgEffDtlDt = hlthcarOrgEffDtlDt;
	}

	public Long getHlthcarOrgTinTypId() {
		return hlthcarOrgTinTypId;
	}

	public void setHlthcarOrgTinTypId(Long hlthcarOrgTinTypId) {
		this.hlthcarOrgTinTypId = hlthcarOrgTinTypId;
	}

	public String getHlthcarOrgTin() {
		return hlthcarOrgTin;
	}

	public void setHlthcarOrgTin(String hlthcarOrgTin) {
		this.hlthcarOrgTin = hlthcarOrgTin;
	}

	public Long getHlthcarOrgTypId() {
		return hlthcarOrgTypId;
	}

	public void setHlthcarOrgTypId(Long hlthcarOrgTypId) {
		this.hlthcarOrgTypId = hlthcarOrgTypId;
	}

	public String getHlthcarOrgNm() {
		return hlthcarOrgNm;
	}

	public void setHlthcarOrgNm(String hlthcarOrgNm) {
		this.hlthcarOrgNm = hlthcarOrgNm;
	}

	public String getProvLglNm() {
		return provLglNm;
	}

	public void setProvLglNm(String provLglNm) {
		this.provLglNm = provLglNm;
	}

	public Long getHlthcarProfNmPrfxId() {
		return hlthcarProfNmPrfxId;
	}

	public void setHlthcarProfNmPrfxId(Long hlthcarProfNmPrfxId) {
		this.hlthcarProfNmPrfxId = hlthcarProfNmPrfxId;
	}

	public String getHlthcarProfFstNm() {
		return hlthcarProfFstNm;
	}

	public void setHlthcarProfFstNm(String hlthcarProfFstNm) {
		this.hlthcarProfFstNm = hlthcarProfFstNm;
	}

	public String getHlthcarProfMidlNm() {
		return hlthcarProfMidlNm;
	}

	public void setHlthcarProfMidlNm(String hlthcarProfMidlNm) {
		this.hlthcarProfMidlNm = hlthcarProfMidlNm;
	}

	public String getHlthcarProfLstNm() {
		return hlthcarProfLstNm;
	}

	public void setHlthcarProfLstNm(String hlthcarProfLstNm) {
		this.hlthcarProfLstNm = hlthcarProfLstNm;
	}

	public Long getHlthcarProfNmSufxId() {
		return hlthcarProfNmSufxId;
	}

	public void setHlthcarProfNmSufxId(Long hlthcarProfNmSufxId) {
		this.hlthcarProfNmSufxId = hlthcarProfNmSufxId;
	}

	public Long getHlthcarProfCrdntlSufxId() {
		return hlthcarProfCrdntlSufxId;
	}

	public void setHlthcarProfCrdntlSufxId(Long hlthcarProfCrdntlSufxId) {
		this.hlthcarProfCrdntlSufxId = hlthcarProfCrdntlSufxId;
	}

	public Date getHlthcarProfBthDt() {
		return hlthcarProfBthDt;
	}

	public void setHlthcarProfBthDt(Date hlthcarProfBthDt) {
		this.hlthcarProfBthDt = hlthcarProfBthDt;
	}

	public String getBthAdrTnNm() {
		return bthAdrTnNm;
	}

	public void setBthAdrTnNm(String bthAdrTnNm) {
		this.bthAdrTnNm = bthAdrTnNm;
	}

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public Long getMrtlStsId() {
		return mrtlStsId;
	}

	public void setMrtlStsId(Long mrtlStsId) {
		this.mrtlStsId = mrtlStsId;
	}

	public Date getHlthcarProfDthDt() {
		return hlthcarProfDthDt;
	}

	public void setHlthcarProfDthDt(Date hlthcarProfDthDt) {
		this.hlthcarProfDthDt = hlthcarProfDthDt;
	}

	public Date getHlthcarProfEffStrtDt() {
		return hlthcarProfEffStrtDt;
	}

	public void setHlthcarProfEffStrtDt(Date hlthcarProfEffStrtDt) {
		this.hlthcarProfEffStrtDt = hlthcarProfEffStrtDt;
	}

	public String getErlyPrdScrDiagTrt() {
		return erlyPrdScrDiagTrt;
	}

	public void setErlyPrdScrDiagTrt(String erlyPrdScrDiagTrt) {
		this.erlyPrdScrDiagTrt = erlyPrdScrDiagTrt;
	}

	public Long getHlthcarProfGdrId() {
		return hlthcarProfGdrId;
	}

	public void setHlthcarProfGdrId(Long hlthcarProfGdrId) {
		this.hlthcarProfGdrId = hlthcarProfGdrId;
	}

	public Long getBthCntyId() {
		return bthCntyId;
	}

	public void setBthCntyId(Long bthCntyId) {
		this.bthCntyId = bthCntyId;
	}

	public Long getBthStPrvcId() {
		return bthStPrvcId;
	}

	public void setBthStPrvcId(Long bthStPrvcId) {
		this.bthStPrvcId = bthStPrvcId;
	}

	public Long getBthCntryId() {
		return bthCntryId;
	}

	public void setBthCntryId(Long bthCntryId) {
		this.bthCntryId = bthCntryId;
	}

	public Long getMltrySrvcTypId() {
		return mltrySrvcTypId;
	}

	public void setMltrySrvcTypId(Long mltrySrvcTypId) {
		this.mltrySrvcTypId = mltrySrvcTypId;
	}

	public Long getPriPhrmDspnsTypId() {
		return priPhrmDspnsTypId;
	}

	public void setPriPhrmDspnsTypId(Long priPhrmDspnsTypId) {
		this.priPhrmDspnsTypId = priPhrmDspnsTypId;
	}

	public Long getSecPhrmDspnsTypId() {
		return secPhrmDspnsTypId;
	}

	public void setSecPhrmDspnsTypId(Long secPhrmDspnsTypId) {
		this.secPhrmDspnsTypId = secPhrmDspnsTypId;
	}

	public Long getPhrmClssTypId() {
		return phrmClssTypId;
	}

	public void setPhrmClssTypId(Long phrmClssTypId) {
		this.phrmClssTypId = phrmClssTypId;
	}

	public Date getMedcrAsgnDt() {
		return medcrAsgnDt;
	}

	public void setMedcrAsgnDt(Date medcrAsgnDt) {
		this.medcrAsgnDt = medcrAsgnDt;
	}

	public String getNcpdpNbr() {
		return ncpdpNbr;
	}

	public void setNcpdpNbr(String ncpdpNbr) {
		this.ncpdpNbr = ncpdpNbr;
	}

	public Long getProvHlthcarOrgOwnrId() {
		return provHlthcarOrgOwnrId;
	}

	public void setProvHlthcarOrgOwnrId(Long provHlthcarOrgOwnrId) {
		this.provHlthcarOrgOwnrId = provHlthcarOrgOwnrId;
	}

	public Long getProvStLocTypId() {
		return provStLocTypId;
	}

	public void setProvStLocTypId(Long provStLocTypId) {
		this.provStLocTypId = provStLocTypId;
	}

	public Long getProvEnrlStsId() {
		return provEnrlStsId;
	}

	public void setProvEnrlStsId(Long provEnrlStsId) {
		this.provEnrlStsId = provEnrlStsId;
	}

	public Long getProvTinTypId() {
		return provTinTypId;
	}

	public void setProvTinTypId(Long provTinTypId) {
		this.provTinTypId = provTinTypId;
	}

	public String getProvTin() {
		return provTin;
	}

	public void setProvTin(String provTin) {
		this.provTin = provTin;
	}

	public String getTaxBNtcInd() {
		return taxBNtcInd;
	}

	public void setTaxBNtcInd(String taxBNtcInd) {
		this.taxBNtcInd = taxBNtcInd;
	}

	public String getTinLglOwnrNm() {
		return tinLglOwnrNm;
	}

	public void setTinLglOwnrNm(String tinLglOwnrNm) {
		this.tinLglOwnrNm = tinLglOwnrNm;
	}

	public Date getTinEffDt() {
		return tinEffDt;
	}

	public void setTinEffDt(Date tinEffDt) {
		this.tinEffDt = tinEffDt;
	}

	public Date getTinCancDt() {
		return tinCancDt;
	}

	public void setTinCancDt(Date tinCancDt) {
		this.tinCancDt = tinCancDt;
	}

	public Date getTaxBNtcDt() {
		return taxBNtcDt;
	}

	public void setTaxBNtcDt(Date taxBNtcDt) {
		this.taxBNtcDt = taxBNtcDt;
	}

	public String getNonPrftInd() {
		return nonPrftInd;
	}

	public void setNonPrftInd(String nonPrftInd) {
		this.nonPrftInd = nonPrftInd;
	}

	public Long getIncTypId() {
		return incTypId;
	}

	public void setIncTypId(Long incTypId) {
		this.incTypId = incTypId;
	}

	public Long getW9CpyTypId() {
		return w9CpyTypId;
	}

	public void setW9CpyTypId(Long w9CpyTypId) {
		this.w9CpyTypId = w9CpyTypId;
	}

	public Long getAdrTypId() {
		return adrTypId;
	}

	public void setAdrTypId(Long adrTypId) {
		this.adrTypId = adrTypId;
	}

	public String getAdrLn1Txt() {
		return adrLn1Txt;
	}

	public void setAdrLn1Txt(String adrLn1Txt) {
		this.adrLn1Txt = adrLn1Txt;
	}

	public String getAdrLn2Txt() {
		return adrLn2Txt;
	}

	public void setAdrLn2Txt(String adrLn2Txt) {
		this.adrLn2Txt = adrLn2Txt;
	}

	public String getAdrLn3Txt() {
		return adrLn3Txt;
	}

	public void setAdrLn3Txt(String adrLn3Txt) {
		this.adrLn3Txt = adrLn3Txt;
	}

	public String getAdrLn4Txt() {
		return adrLn4Txt;
	}

	public void setAdrLn4Txt(String adrLn4Txt) {
		this.adrLn4Txt = adrLn4Txt;
	}

	public String getAdrLn5Txt() {
		return adrLn5Txt;
	}

	public void setAdrLn5Txt(String adrLn5Txt) {
		this.adrLn5Txt = adrLn5Txt;
	}

	public Integer getAdrVldId() {
		return adrVldId;
	}

	public void setAdrVldId(Integer adrVldId) {
		this.adrVldId = adrVldId;
	}

	public String getAdrGuidVer() {
		return adrGuidVer;
	}

	public void setAdrGuidVer(String adrGuidVer) {
		this.adrGuidVer = adrGuidVer;
	}

	public String getResDlvrInd() {
		return resDlvrInd;
	}

	public void setResDlvrInd(String resDlvrInd) {
		this.resDlvrInd = resDlvrInd;
	}

	public String getAdrHseNbrWoFrac() {
		return adrHseNbrWoFrac;
	}

	public void setAdrHseNbrWoFrac(String adrHseNbrWoFrac) {
		this.adrHseNbrWoFrac = adrHseNbrWoFrac;
	}

	public String getAdrHseNbrFrac() {
		return adrHseNbrFrac;
	}

	public void setAdrHseNbrFrac(String adrHseNbrFrac) {
		this.adrHseNbrFrac = adrHseNbrFrac;
	}

	public String getAdrStrPrfxDir() {
		return adrStrPrfxDir;
	}

	public void setAdrStrPrfxDir(String adrStrPrfxDir) {
		this.adrStrPrfxDir = adrStrPrfxDir;
	}

	public String getAdrStrNm() {
		return adrStrNm;
	}

	public void setAdrStrNm(String adrStrNm) {
		this.adrStrNm = adrStrNm;
	}

	public String getAdrStrSufxAbbr() {
		return adrStrSufxAbbr;
	}

	public void setAdrStrSufxAbbr(String adrStrSufxAbbr) {
		this.adrStrSufxAbbr = adrStrSufxAbbr;
	}

	public String getAdrStrSufxDir() {
		return adrStrSufxDir;
	}

	public void setAdrStrSufxDir(String adrStrSufxDir) {
		this.adrStrSufxDir = adrStrSufxDir;
	}

	public String getAdrSecUnitDesg() {
		return adrSecUnitDesg;
	}

	public void setAdrSecUnitDesg(String adrSecUnitDesg) {
		this.adrSecUnitDesg = adrSecUnitDesg;
	}

	public String getAdrSecUnitQual() {
		return adrSecUnitQual;
	}

	public void setAdrSecUnitQual(String adrSecUnitQual) {
		this.adrSecUnitQual = adrSecUnitQual;
	}

	public String getAdrPoBoxNbr() {
		return adrPoBoxNbr;
	}

	public void setAdrPoBoxNbr(String adrPoBoxNbr) {
		this.adrPoBoxNbr = adrPoBoxNbr;
	}

	public String getAdrRteDesg() {
		return adrRteDesg;
	}

	public void setAdrRteDesg(String adrRteDesg) {
		this.adrRteDesg = adrRteDesg;
	}

	public String getAdrBoxNbr() {
		return adrBoxNbr;
	}

	public void setAdrBoxNbr(String adrBoxNbr) {
		this.adrBoxNbr = adrBoxNbr;
	}

	public String getAdrUrbnNm() {
		return adrUrbnNm;
	}

	public void setAdrUrbnNm(String adrUrbnNm) {
		this.adrUrbnNm = adrUrbnNm;
	}

	public String getAdrTnNm() {
		return adrTnNm;
	}

	public void setAdrTnNm(String adrTnNm) {
		this.adrTnNm = adrTnNm;
	}

	public String getAdrDlvrPtCd() {
		return adrDlvrPtCd;
	}

	public void setAdrDlvrPtCd(String adrDlvrPtCd) {
		this.adrDlvrPtCd = adrDlvrPtCd;
	}

	public String getAdrDlvrPtChkDgt() {
		return adrDlvrPtChkDgt;
	}

	public void setAdrDlvrPtChkDgt(String adrDlvrPtChkDgt) {
		this.adrDlvrPtChkDgt = adrDlvrPtChkDgt;
	}

	public String getAdrCarrRteCd() {
		return adrCarrRteCd;
	}

	public void setAdrCarrRteCd(String adrCarrRteCd) {
		this.adrCarrRteCd = adrCarrRteCd;
	}

	public String getLatDeg() {
		return latDeg;
	}

	public void setLatDeg(String latDeg) {
		this.latDeg = latDeg;
	}

	public String getLngDeg() {
		return lngDeg;
	}

	public void setLngDeg(String lngDeg) {
		this.lngDeg = lngDeg;
	}

	public String getPstCd() {
		return pstCd;
	}

	public void setPstCd(String pstCd) {
		this.pstCd = pstCd;
	}

	public String getPstPrfxCd() {
		return pstPrfxCd;
	}

	public void setPstPrfxCd(String pstPrfxCd) {
		this.pstPrfxCd = pstPrfxCd;
	}

	public String getPstSufxCd() {
		return pstSufxCd;
	}

	public void setPstSufxCd(String pstSufxCd) {
		this.pstSufxCd = pstSufxCd;
	}

	public String getPstDesc() {
		return pstDesc;
	}

	public void setPstDesc(String pstDesc) {
		this.pstDesc = pstDesc;
	}

	public Long getTmZoneId() {
		return tmZoneId;
	}

	public void setTmZoneId(Long tmZoneId) {
		this.tmZoneId = tmZoneId;
	}

	public String getTmZoneNm() {
		return tmZoneNm;
	}

	public void setTmZoneNm(String tmZoneNm) {
		this.tmZoneNm = tmZoneNm;
	}

	public BigDecimal getUtcOfstTm() {
		return utcOfstTm;
	}

	public void setUtcOfstTm(BigDecimal utcOfstTm) {
		this.utcOfstTm = utcOfstTm;
	}

	public Long getIsoCntryId() {
		return isoCntryId;
	}

	public void setIsoCntryId(Long isoCntryId) {
		this.isoCntryId = isoCntryId;
	}

	public Long getIsoCntrySubdivId() {
		return isoCntrySubdivId;
	}

	public void setIsoCntrySubdivId(Long isoCntrySubdivId) {
		this.isoCntrySubdivId = isoCntrySubdivId;
	}

	public Long getFipsStId() {
		return fipsStId;
	}

	public void setFipsStId(Long fipsStId) {
		this.fipsStId = fipsStId;
	}

	public Long getFipsCntyId() {
		return fipsCntyId;
	}

	public void setFipsCntyId(Long fipsCntyId) {
		this.fipsCntyId = fipsCntyId;
	}

	public Long getStPrvcId() {
		return stPrvcId;
	}

	public void setStPrvcId(Long stPrvcId) {
		this.stPrvcId = stPrvcId;
	}

	public Long getOthrIdTypCd() {
		return othrIdTypCd;
	}

	public void setOthrIdTypCd(Long othrIdTypCd) {
		this.othrIdTypCd = othrIdTypCd;
	}

	public Long getOthrIdSrcSysId() {
		return othrIdSrcSysId;
	}

	public void setOthrIdSrcSysId(Long othrIdSrcSysId) {
		this.othrIdSrcSysId = othrIdSrcSysId;
	}

	public String getOthrIdDesc() {
		return othrIdDesc;
	}

	public void setOthrIdDesc(String othrIdDesc) {
		this.othrIdDesc = othrIdDesc;
	}

	public String getOthrId() {
		return othrId;
	}

	public void setOthrId(String othrId) {
		this.othrId = othrId;
	}

	public Date getOthrIdEffDt() {
		return othrIdEffDt;
	}

	public void setOthrIdEffDt(Date othrIdEffDt) {
		this.othrIdEffDt = othrIdEffDt;
	}

	public Date getOthrIdCancDt() {
		return othrIdCancDt;
	}

	public void setOthrIdCancDt(Date othrIdCancDt) {
		this.othrIdCancDt = othrIdCancDt;
	}

	public Long getOthrIdIssCntryId() {
		return othrIdIssCntryId;
	}

	public void setOthrIdIssCntryId(Long othrIdIssCntryId) {
		this.othrIdIssCntryId = othrIdIssCntryId;
	}

	public Long getOthrIdIssStPrvcId() {
		return othrIdIssStPrvcId;
	}

	public void setOthrIdIssStPrvcId(Long othrIdIssStPrvcId) {
		this.othrIdIssStPrvcId = othrIdIssStPrvcId;
	}

	public Integer getOthrIdGeoAreaId() {
		return othrIdGeoAreaId;
	}

	public void setOthrIdGeoAreaId(Integer othrIdGeoAreaId) {
		this.othrIdGeoAreaId = othrIdGeoAreaId;
	}

	public String getOthrIdGeoAreaNm() {
		return othrIdGeoAreaNm;
	}

	public void setOthrIdGeoAreaNm(String othrIdGeoAreaNm) {
		this.othrIdGeoAreaNm = othrIdGeoAreaNm;
	}

	public Long getOthrIdGeoAreaTypId() {
		return othrIdGeoAreaTypId;
	}

	public void setOthrIdGeoAreaTypId(Long othrIdGeoAreaTypId) {
		this.othrIdGeoAreaTypId = othrIdGeoAreaTypId;
	}

	public Long getProvTypId() {
		return provTypId;
	}

	public void setProvTypId(Long provTypId) {
		this.provTypId = provTypId;
	}

	public Long getProvClssTypId() {
		return provClssTypId;
	}

	public void setProvClssTypId(Long provClssTypId) {
		this.provClssTypId = provClssTypId;
	}

	public Long getProvSpclTypId() {
		return provSpclTypId;
	}

	public void setProvSpclTypId(Long provSpclTypId) {
		this.provSpclTypId = provSpclTypId;
	}

	public Long getProvSpclTyp2Id() {
		return provSpclTyp2Id;
	}

	public void setProvSpclTyp2Id(Long provSpclTyp2Id) {
		this.provSpclTyp2Id = provSpclTyp2Id;
	}

	public Long getProvSpclTyp3Id() {
		return provSpclTyp3Id;
	}

	public void setProvSpclTyp3Id(Long provSpclTyp3Id) {
		this.provSpclTyp3Id = provSpclTyp3Id;
	}

	public Long getProvSpclTyp4Id() {
		return provSpclTyp4Id;
	}

	public void setProvSpclTyp4Id(Long provSpclTyp4Id) {
		this.provSpclTyp4Id = provSpclTyp4Id;
	}

	public Long getProvSpclTyp5Id() {
		return provSpclTyp5Id;
	}

	public void setProvSpclTyp5Id(Long provSpclTyp5Id) {
		this.provSpclTyp5Id = provSpclTyp5Id;
	}

	public Long getProvSpclTyp6Id() {
		return provSpclTyp6Id;
	}

	public void setProvSpclTyp6Id(Long provSpclTyp6Id) {
		this.provSpclTyp6Id = provSpclTyp6Id;
	}

	public Long getProvSpclTyp7Id() {
		return provSpclTyp7Id;
	}

	public void setProvSpclTyp7Id(Long provSpclTyp7Id) {
		this.provSpclTyp7Id = provSpclTyp7Id;
	}

	public Long getProvSpclTyp8Id() {
		return provSpclTyp8Id;
	}

	public void setProvSpclTyp8Id(Long provSpclTyp8Id) {
		this.provSpclTyp8Id = provSpclTyp8Id;
	}

	public Long getProvSpclTyp9Id() {
		return provSpclTyp9Id;
	}

	public void setProvSpclTyp9Id(Long provSpclTyp9Id) {
		this.provSpclTyp9Id = provSpclTyp9Id;
	}

	public Long getProvSpclTyp10Id() {
		return provSpclTyp10Id;
	}

	public void setProvSpclTyp10Id(Long provSpclTyp10Id) {
		this.provSpclTyp10Id = provSpclTyp10Id;
	}

	public Long getProvSpclTyp11Id() {
		return provSpclTyp11Id;
	}

	public void setProvSpclTyp11Id(Long provSpclTyp11Id) {
		this.provSpclTyp11Id = provSpclTyp11Id;
	}

	public Long getProvSpclTyp12Id() {
		return provSpclTyp12Id;
	}

	public void setProvSpclTyp12Id(Long provSpclTyp12Id) {
		this.provSpclTyp12Id = provSpclTyp12Id;
	}

	public Long getCntcRoleId() {
		return cntcRoleId;
	}

	public void setCntcRoleId(Long cntcRoleId) {
		this.cntcRoleId = cntcRoleId;
	}

	public String getCntcTitl() {
		return cntcTitl;
	}

	public void setCntcTitl(String cntcTitl) {
		this.cntcTitl = cntcTitl;
	}

	public Long getCntcNmPrfxId() {
		return cntcNmPrfxId;
	}

	public void setCntcNmPrfxId(Long cntcNmPrfxId) {
		this.cntcNmPrfxId = cntcNmPrfxId;
	}

	public String getCntcFstNm() {
		return cntcFstNm;
	}

	public void setCntcFstNm(String cntcFstNm) {
		this.cntcFstNm = cntcFstNm;
	}

	public String getCntcMidlNm() {
		return cntcMidlNm;
	}

	public void setCntcMidlNm(String cntcMidlNm) {
		this.cntcMidlNm = cntcMidlNm;
	}

	public String getCntcMidlInitTxt() {
		return cntcMidlInitTxt;
	}

	public void setCntcMidlInitTxt(String cntcMidlInitTxt) {
		this.cntcMidlInitTxt = cntcMidlInitTxt;
	}

	public String getCntcLstNm() {
		return cntcLstNm;
	}

	public void setCntcLstNm(String cntcLstNm) {
		this.cntcLstNm = cntcLstNm;
	}

	public Long getCntcNmSufxId() {
		return cntcNmSufxId;
	}

	public void setCntcNmSufxId(Long cntcNmSufxId) {
		this.cntcNmSufxId = cntcNmSufxId;
	}

	public String getCntcCrdntlSufx() {
		return cntcCrdntlSufx;
	}

	public void setCntcCrdntlSufx(String cntcCrdntlSufx) {
		this.cntcCrdntlSufx = cntcCrdntlSufx;
	}

	public Long getCntcStsId() {
		return cntcStsId;
	}

	public void setCntcStsId(Long cntcStsId) {
		this.cntcStsId = cntcStsId;
	}

	public Long getCmnctTypId() {
		return cmnctTypId;
	}

	public void setCmnctTypId(Long cmnctTypId) {
		this.cmnctTypId = cmnctTypId;
	}

	public String getElctrCmnctTxt() {
		return elctrCmnctTxt;
	}

	public void setElctrCmnctTxt(String elctrCmnctTxt) {
		this.elctrCmnctTxt = elctrCmnctTxt;
	}

	public Long getIsoCntryTelId() {
		return isoCntryTelId;
	}

	public void setIsoCntryTelId(Long isoCntryTelId) {
		this.isoCntryTelId = isoCntryTelId;
	}

	public String getAreaCd() {
		return areaCd;
	}

	public void setAreaCd(String areaCd) {
		this.areaCd = areaCd;
	}

	public String getXchgNbr() {
		return xchgNbr;
	}

	public void setXchgNbr(String xchgNbr) {
		this.xchgNbr = xchgNbr;
	}

	public String getTelNbr() {
		return telNbr;
	}

	public void setTelNbr(String telNbr) {
		this.telNbr = telNbr;
	}

	public String getExtNbr() {
		return extNbr;
	}

	public void setExtNbr(String extNbr) {
		this.extNbr = extNbr;
	}

	public String getPriTelInd() {
		return priTelInd;
	}

	public void setPriTelInd(String priTelInd) {
		this.priTelInd = priTelInd;
	}

	public Long getCmnctStsId() {
		return cmnctStsId;
	}

	public void setCmnctStsId(Long cmnctStsId) {
		this.cmnctStsId = cmnctStsId;
	}

	public Integer getAgrId() {
		return agrId;
	}

	public void setAgrId(Integer agrId) {
		this.agrId = agrId;
	}

	public Long getAgrTypId() {
		return agrTypId;
	}

	public void setAgrTypId(Long agrTypId) {
		this.agrTypId = agrTypId;
	}

	public Integer getAgrLglDocId() {
		return agrLglDocId;
	}

	public void setAgrLglDocId(Integer agrLglDocId) {
		this.agrLglDocId = agrLglDocId;
	}

	public Long getAgrLglDocTypId() {
		return agrLglDocTypId;
	}

	public void setAgrLglDocTypId(Long agrLglDocTypId) {
		this.agrLglDocTypId = agrLglDocTypId;
	}

	public Date getAgrEffDt() {
		return agrEffDt;
	}

	public void setAgrEffDt(Date agrEffDt) {
		this.agrEffDt = agrEffDt;
	}

	public Date getAgrCancDt() {
		return agrCancDt;
	}

	public void setAgrCancDt(Date agrCancDt) {
		this.agrCancDt = agrCancDt;
	}

	public String getOvpayRecovInd() {
		return ovpayRecovInd;
	}

	public void setOvpayRecovInd(String ovpayRecovInd) {
		this.ovpayRecovInd = ovpayRecovInd;
	}

	public Long getProvAgrTrmRsnTypId() {
		return provAgrTrmRsnTypId;
	}

	public void setProvAgrTrmRsnTypId(Long provAgrTrmRsnTypId) {
		this.provAgrTrmRsnTypId = provAgrTrmRsnTypId;
	}

	public Long getIptntTrnsfTypId() {
		return iptntTrnsfTypId;
	}

	public void setIptntTrnsfTypId(Long iptntTrnsfTypId) {
		this.iptntTrnsfTypId = iptntTrnsfTypId;
	}

	public Date getAgrSrvcProvEffDt() {
		return agrSrvcProvEffDt;
	}

	public void setAgrSrvcProvEffDt(Date agrSrvcProvEffDt) {
		this.agrSrvcProvEffDt = agrSrvcProvEffDt;
	}

	public Date getAgrSrvcProvCancDt() {
		return agrSrvcProvCancDt;
	}

	public void setAgrSrvcProvCancDt(Date agrSrvcProvCancDt) {
		this.agrSrvcProvCancDt = agrSrvcProvCancDt;
	}

	public Long getProvAsgnTypId() {
		return provAsgnTypId;
	}

	public void setProvAsgnTypId(Long provAsgnTypId) {
		this.provAsgnTypId = provAsgnTypId;
	}

	public String getRecovWaitPrdCnt() {
		return recovWaitPrdCnt;
	}

	public void setRecovWaitPrdCnt(String recovWaitPrdCnt) {
		this.recovWaitPrdCnt = recovWaitPrdCnt;
	}

	public Long getRecovWaitPrdMsrId() {
		return recovWaitPrdMsrId;
	}

	public void setRecovWaitPrdMsrId(Long recovWaitPrdMsrId) {
		this.recovWaitPrdMsrId = recovWaitPrdMsrId;
	}

	public BigDecimal getRecovDdlnPrdCnt() {
		return recovDdlnPrdCnt;
	}

	public void setRecovDdlnPrdCnt(BigDecimal recovDdlnPrdCnt) {
		this.recovDdlnPrdCnt = recovDdlnPrdCnt;
	}

	public Long getRecovDdlnPrdMsrId() {
		return recovDdlnPrdMsrId;
	}

	public void setRecovDdlnPrdMsrId(Long recovDdlnPrdMsrId) {
		this.recovDdlnPrdMsrId = recovDdlnPrdMsrId;
	}

	public String getMedcrIdNbr() {
		return medcrIdNbr;
	}

	public void setMedcrIdNbr(String medcrIdNbr) {
		this.medcrIdNbr = medcrIdNbr;
	}

	public Date getMedcrIdEffDt() {
		return medcrIdEffDt;
	}

	public void setMedcrIdEffDt(Date medcrIdEffDt) {
		this.medcrIdEffDt = medcrIdEffDt;
	}

	public Date getMedcrIdCancDt() {
		return medcrIdCancDt;
	}

	public void setMedcrIdCancDt(Date medcrIdCancDt) {
		this.medcrIdCancDt = medcrIdCancDt;
	}

	public Long getMedcrIssCntryId() {
		return medcrIssCntryId;
	}

	public void setMedcrIssCntryId(Long medcrIssCntryId) {
		this.medcrIssCntryId = medcrIssCntryId;
	}

	public Long getMedcrIssStPrvcId() {
		return medcrIssStPrvcId;
	}

	public void setMedcrIssStPrvcId(Long medcrIssStPrvcId) {
		this.medcrIssStPrvcId = medcrIssStPrvcId;
	}

	public String getMedcrAtypclInd() {
		return medcrAtypclInd;
	}

	public void setMedcrAtypclInd(String medcrAtypclInd) {
		this.medcrAtypclInd = medcrAtypclInd;
	}

	public Long getMedcrStsTypId() {
		return medcrStsTypId;
	}

	public void setMedcrStsTypId(Long medcrStsTypId) {
		this.medcrStsTypId = medcrStsTypId;
	}

	public String getMedcdIdNbr() {
		return medcdIdNbr;
	}

	public void setMedcdIdNbr(String medcdIdNbr) {
		this.medcdIdNbr = medcdIdNbr;
	}

	public Date getMedcdIdEffDt() {
		return medcdIdEffDt;
	}

	public void setMedcdIdEffDt(Date medcdIdEffDt) {
		this.medcdIdEffDt = medcdIdEffDt;
	}

	public Date getMedcdIdCancDt() {
		return medcdIdCancDt;
	}

	public void setMedcdIdCancDt(Date medcdIdCancDt) {
		this.medcdIdCancDt = medcdIdCancDt;
	}

	public Long getMedcdIssCntryId() {
		return medcdIssCntryId;
	}

	public void setMedcdIssCntryId(Long medcdIssCntryId) {
		this.medcdIssCntryId = medcdIssCntryId;
	}

	public Long getMedcdIssStPrvcId() {
		return medcdIssStPrvcId;
	}

	public void setMedcdIssStPrvcId(Long medcdIssStPrvcId) {
		this.medcdIssStPrvcId = medcdIssStPrvcId;
	}

	public String getProvMedcdLocCd() {
		return provMedcdLocCd;
	}

	public void setProvMedcdLocCd(String provMedcdLocCd) {
		this.provMedcdLocCd = provMedcdLocCd;
	}

	public String getMedcdAtypclInd() {
		return medcdAtypclInd;
	}

	public void setMedcdAtypclInd(String medcdAtypclInd) {
		this.medcdAtypclInd = medcdAtypclInd;
	}

	public Date getMedcdVldDt() {
		return medcdVldDt;
	}

	public void setMedcdVldDt(Date medcdVldDt) {
		this.medcdVldDt = medcdVldDt;
	}

	public Long getMedcdStsTypId() {
		return medcdStsTypId;
	}

	public void setMedcdStsTypId(Long medcdStsTypId) {
		this.medcdStsTypId = medcdStsTypId;
	}

	public Integer getNpiVal() {
		return npiVal;
	}

	public void setNpiVal(Integer npiVal) {
		this.npiVal = npiVal;
	}

	public String getNpiNm() {
		return npiNm;
	}

	public void setNpiNm(String npiNm) {
		this.npiNm = npiNm;
	}

	public Date getNpiEnmrtnDt() {
		return npiEnmrtnDt;
	}

	public void setNpiEnmrtnDt(Date npiEnmrtnDt) {
		this.npiEnmrtnDt = npiEnmrtnDt;
	}

	public String getReplNpi() {
		return replNpi;
	}

	public void setReplNpi(String replNpi) {
		this.replNpi = replNpi;
	}

	public Integer getPrevNpi() {
		return prevNpi;
	}

	public void setPrevNpi(Integer prevNpi) {
		this.prevNpi = prevNpi;
	}

	public String getProvFein() {
		return provFein;
	}

	public void setProvFein(String provFein) {
		this.provFein = provFein;
	}

	public Date getNpiActvDt() {
		return npiActvDt;
	}

	public void setNpiActvDt(Date npiActvDt) {
		this.npiActvDt = npiActvDt;
	}

	public Date getNpiDactvDt() {
		return npiDactvDt;
	}

	public void setNpiDactvDt(Date npiDactvDt) {
		this.npiDactvDt = npiDactvDt;
	}

	public Date getNpiLstUpdtDt() {
		return npiLstUpdtDt;
	}

	public void setNpiLstUpdtDt(Date npiLstUpdtDt) {
		this.npiLstUpdtDt = npiLstUpdtDt;
	}

	public Long getDrgLicTypId() {
		return drgLicTypId;
	}

	public void setDrgLicTypId(Long drgLicTypId) {
		this.drgLicTypId = drgLicTypId;
	}

	public String getDrgLicNbr() {
		return drgLicNbr;
	}

	public void setDrgLicNbr(String drgLicNbr) {
		this.drgLicNbr = drgLicNbr;
	}

	public Integer getDrgLicGeoAreaId() {
		return drgLicGeoAreaId;
	}

	public void setDrgLicGeoAreaId(Integer drgLicGeoAreaId) {
		this.drgLicGeoAreaId = drgLicGeoAreaId;
	}

	public String getDrgLicGeoAreaNm() {
		return drgLicGeoAreaNm;
	}

	public void setDrgLicGeoAreaNm(String drgLicGeoAreaNm) {
		this.drgLicGeoAreaNm = drgLicGeoAreaNm;
	}

	public Long getDrgLicGeoAreaTypId() {
		return drgLicGeoAreaTypId;
	}

	public void setDrgLicGeoAreaTypId(Long drgLicGeoAreaTypId) {
		this.drgLicGeoAreaTypId = drgLicGeoAreaTypId;
	}

	public Date getDrgLicEffDt() {
		return drgLicEffDt;
	}

	public void setDrgLicEffDt(Date drgLicEffDt) {
		this.drgLicEffDt = drgLicEffDt;
	}

	public Date getDrgLicExpirDt() {
		return drgLicExpirDt;
	}

	public void setDrgLicExpirDt(Date drgLicExpirDt) {
		this.drgLicExpirDt = drgLicExpirDt;
	}

	public Long getDrgSchedTypId() {
		return drgSchedTypId;
	}

	public void setDrgSchedTypId(Long drgSchedTypId) {
		this.drgSchedTypId = drgSchedTypId;
	}

	public Long getDrgLicStsTypId() {
		return drgLicStsTypId;
	}

	public void setDrgLicStsTypId(Long drgLicStsTypId) {
		this.drgLicStsTypId = drgLicStsTypId;
	}

	public Long getLicTypId() {
		return licTypId;
	}

	public void setLicTypId(Long licTypId) {
		this.licTypId = licTypId;
	}

	public String getLicNbr() {
		return licNbr;
	}

	public void setLicNbr(String licNbr) {
		this.licNbr = licNbr;
	}

	public Date getLicEffDt() {
		return licEffDt;
	}

	public void setLicEffDt(Date licEffDt) {
		this.licEffDt = licEffDt;
	}

	public Date getLicExpirDt() {
		return licExpirDt;
	}

	public void setLicExpirDt(Date licExpirDt) {
		this.licExpirDt = licExpirDt;
	}

	public String getLicBdNbr() {
		return licBdNbr;
	}

	public void setLicBdNbr(String licBdNbr) {
		this.licBdNbr = licBdNbr;
	}

	public String getLicBdDesc() {
		return licBdDesc;
	}

	public void setLicBdDesc(String licBdDesc) {
		this.licBdDesc = licBdDesc;
	}

	public Date getLicIssDt() {
		return licIssDt;
	}

	public void setLicIssDt(Date licIssDt) {
		this.licIssDt = licIssDt;
	}

	public Long getLicCntryId() {
		return licCntryId;
	}

	public void setLicCntryId(Long licCntryId) {
		this.licCntryId = licCntryId;
	}

	public Integer getLicGeoAreaId() {
		return licGeoAreaId;
	}

	public void setLicGeoAreaId(Integer licGeoAreaId) {
		this.licGeoAreaId = licGeoAreaId;
	}

	public String getLicGeoAreaNm() {
		return licGeoAreaNm;
	}

	public void setLicGeoAreaNm(String licGeoAreaNm) {
		this.licGeoAreaNm = licGeoAreaNm;
	}

	public Long getLicGeoAreaTypId() {
		return licGeoAreaTypId;
	}

	public void setLicGeoAreaTypId(Long licGeoAreaTypId) {
		this.licGeoAreaTypId = licGeoAreaTypId;
	}

	public Long getLicStsTypId() {
		return licStsTypId;
	}

	public void setLicStsTypId(Long licStsTypId) {
		this.licStsTypId = licStsTypId;
	}

	public Long getLicTrmRsnTypId() {
		return licTrmRsnTypId;
	}

	public void setLicTrmRsnTypId(Long licTrmRsnTypId) {
		this.licTrmRsnTypId = licTrmRsnTypId;
	}

	public Integer getAffilProvId() {
		return affilProvId;
	}

	public void setAffilProvId(Integer affilProvId) {
		this.affilProvId = affilProvId;
	}

	public Long getAffilTypId() {
		return affilTypId;
	}

	public void setAffilTypId(Long affilTypId) {
		this.affilTypId = affilTypId;
	}

	public Date getAffilEffDt() {
		return affilEffDt;
	}

	public void setAffilEffDt(Date affilEffDt) {
		this.affilEffDt = affilEffDt;
	}

	public Date getAffilCancDt() {
		return affilCancDt;
	}

	public void setAffilCancDt(Date affilCancDt) {
		this.affilCancDt = affilCancDt;
	}

	public String getPriHospAffilInd() {
		return priHospAffilInd;
	}

	public void setPriHospAffilInd(String priHospAffilInd) {
		this.priHospAffilInd = priHospAffilInd;
	}

	public Long getAdmisPrvlgTypId() {
		return admisPrvlgTypId;
	}

	public void setAdmisPrvlgTypId(Long admisPrvlgTypId) {
		this.admisPrvlgTypId = admisPrvlgTypId;
	}

	public String getAffilHospDeptNm() {
		return affilHospDeptNm;
	}

	public void setAffilHospDeptNm(String affilHospDeptNm) {
		this.affilHospDeptNm = affilHospDeptNm;
	}

	public Long getAffilStsTypId() {
		return affilStsTypId;
	}

	public void setAffilStsTypId(Long affilStsTypId) {
		this.affilStsTypId = affilStsTypId;
	}

	public String getBcbsItsInd() {
		return bcbsItsInd;
	}

	public void setBcbsItsInd(String bcbsItsInd) {
		this.bcbsItsInd = bcbsItsInd;
	}

	public String getFaxNbr() {
		return faxNbr;
	}

	public void setFaxNbr(String faxNbr) {
		this.faxNbr = faxNbr;
	}

	public String getProvPrtcpInd() {
		return provPrtcpInd;
	}

	public void setProvPrtcpInd(String provPrtcpInd) {
		this.provPrtcpInd = provPrtcpInd;
	}

	public String getDelInd() {
		return delInd;
	}

	public void setDelInd(String delInd) {
		this.delInd = delInd;
	}

	public String getSpecialFields() {
		return specialFields;
	}

	public void setSpecialFields(String specialFields) {
		this.specialFields = specialFields;
	}


}