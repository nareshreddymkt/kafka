package com.optum.cdi.core.model.v20180129;

import java.sql.Timestamp;
import java.util.Date;

public class CustomerPurchase {

	public CustomerPurchase() {
	}

	private String custAcctId;
	private Long custAcctSrcSysId;
	private Date custAcctEffDtlDt;
	private String custPchsId;
	private Date effDtlDt;
	private String creatUserId;
	private Timestamp creatTmstmp;
	private String updtUserId;
	private Timestamp updtTmstmp;
	private Long audId;
	private Date cancDtlDt;
	private String prdctCd;
	private String prdctVerNbr;
	private Long prdctSrcSysId;
	private Date prdctEffDtlDt;
	private String plnCd;
	private String plnVerNbr;
	private Long plnSrcSysId;
	private Date plnEffDtlDt;
	private Long pkgOptId;
	private String pkgCd;
	private Long pkgCatgyId;
	private Long pkgSbcatgyId;
	private String parPkgCd;
	private Long brndId;
	private Long pkgStsId;
	private String pkgDesc;
	private Date pkgEffDt;
	private Date pkgExpirDt;
	private Date pkgDoNotSellDt;
	private Date pkgDoNotRenDt;
	private String pkgNm;
	private Long pkgOfrToTypId;
	private String pkgOptNm;
	private String pkgOptDesc;
	private Long pkgOptTypId;
	private Integer srvcAreaId;
	private String srvcAreaCd;
	private String srvcAreaDesc;
	private Date srvcAreaEffDt;
	private Date srvcAreaExpirDt;
	private Long srvcAreaTypId;
	private Integer geoBndryId;
	private String geoBndryCd;
	private String pkgOptHiosPlnId;
	private Long pkgOptPrtcpTypId;
	private Long pkgTypId;
	private Date pkgTypEffDt;
	private Date pkgTypExpirDt;
	private Long situsStId;
	private Long fundArngId;
	private Long ppacaGrndfthrPlnStsId;
	private Long dstrbChnlId;
	private Date custPchsEffDt;
	private Date custPchsTrmDt;
	private Date rnotDt;
	private String rnotDtPrrPlnYr;
	private String buyUpOptInd;
	private Long retroEligTypId;
	private Integer retroEligDay;
	private String delInd;
	private String specialFields;

	public String getCustAcctId() {
		return custAcctId;
	}

	public void setCustAcctId(String custAcctId) {
		this.custAcctId = custAcctId;
	}

	public Long getCustAcctSrcSysId() {
		return custAcctSrcSysId;
	}

	public void setCustAcctSrcSysId(Long custAcctSrcSysId) {
		this.custAcctSrcSysId = custAcctSrcSysId;
	}

	public Date getCustAcctEffDtlDt() {
		return custAcctEffDtlDt;
	}

	public void setCustAcctEffDtlDt(Date custAcctEffDtlDt) {
		this.custAcctEffDtlDt = custAcctEffDtlDt;
	}

	public String getCustPchsId() {
		return custPchsId;
	}

	public void setCustPchsId(String custPchsId) {
		this.custPchsId = custPchsId;
	}

	public Date getEffDtlDt() {
		return effDtlDt;
	}

	public void setEffDtlDt(Date effDtlDt) {
		this.effDtlDt = effDtlDt;
	}

	public String getCreatUserId() {
		return creatUserId;
	}

	public void setCreatUserId(String creatUserId) {
		this.creatUserId = creatUserId;
	}

	public Timestamp getCreatTmstmp() {
		return creatTmstmp;
	}

	public void setCreatTmstmp(Timestamp creatTmstmp) {
		this.creatTmstmp = creatTmstmp;
	}

	public String getUpdtUserId() {
		return updtUserId;
	}

	public void setUpdtUserId(String updtUserId) {
		this.updtUserId = updtUserId;
	}

	public Timestamp getUpdtTmstmp() {
		return updtTmstmp;
	}

	public void setUpdtTmstmp(Timestamp updtTmstmp) {
		this.updtTmstmp = updtTmstmp;
	}

	public Long getAudId() {
		return audId;
	}

	public void setAudId(Long audId) {
		this.audId = audId;
	}

	public Date getCancDtlDt() {
		return cancDtlDt;
	}

	public void setCancDtlDt(Date cancDtlDt) {
		this.cancDtlDt = cancDtlDt;
	}

	public String getPrdctCd() {
		return prdctCd;
	}

	public void setPrdctCd(String prdctCd) {
		this.prdctCd = prdctCd;
	}

	public String getPrdctVerNbr() {
		return prdctVerNbr;
	}

	public void setPrdctVerNbr(String prdctVerNbr) {
		this.prdctVerNbr = prdctVerNbr;
	}

	public Long getPrdctSrcSysId() {
		return prdctSrcSysId;
	}

	public void setPrdctSrcSysId(Long prdctSrcSysId) {
		this.prdctSrcSysId = prdctSrcSysId;
	}

	public Date getPrdctEffDtlDt() {
		return prdctEffDtlDt;
	}

	public void setPrdctEffDtlDt(Date prdctEffDtlDt) {
		this.prdctEffDtlDt = prdctEffDtlDt;
	}

	public String getPlnCd() {
		return plnCd;
	}

	public void setPlnCd(String plnCd) {
		this.plnCd = plnCd;
	}

	public String getPlnVerNbr() {
		return plnVerNbr;
	}

	public void setPlnVerNbr(String plnVerNbr) {
		this.plnVerNbr = plnVerNbr;
	}

	public Long getPlnSrcSysId() {
		return plnSrcSysId;
	}

	public void setPlnSrcSysId(Long plnSrcSysId) {
		this.plnSrcSysId = plnSrcSysId;
	}

	public Date getPlnEffDtlDt() {
		return plnEffDtlDt;
	}

	public void setPlnEffDtlDt(Date plnEffDtlDt) {
		this.plnEffDtlDt = plnEffDtlDt;
	}

	public Long getPkgOptId() {
		return pkgOptId;
	}

	public void setPkgOptId(Long pkgOptId) {
		this.pkgOptId = pkgOptId;
	}

	public String getPkgCd() {
		return pkgCd;
	}

	public void setPkgCd(String pkgCd) {
		this.pkgCd = pkgCd;
	}

	public Long getPkgCatgyId() {
		return pkgCatgyId;
	}

	public void setPkgCatgyId(Long pkgCatgyId) {
		this.pkgCatgyId = pkgCatgyId;
	}

	public Long getPkgSbcatgyId() {
		return pkgSbcatgyId;
	}

	public void setPkgSbcatgyId(Long pkgSbcatgyId) {
		this.pkgSbcatgyId = pkgSbcatgyId;
	}

	public String getParPkgCd() {
		return parPkgCd;
	}

	public void setParPkgCd(String parPkgCd) {
		this.parPkgCd = parPkgCd;
	}

	public Long getBrndId() {
		return brndId;
	}

	public void setBrndId(Long brndId) {
		this.brndId = brndId;
	}

	public Long getPkgStsId() {
		return pkgStsId;
	}

	public void setPkgStsId(Long pkgStsId) {
		this.pkgStsId = pkgStsId;
	}

	public String getPkgDesc() {
		return pkgDesc;
	}

	public void setPkgDesc(String pkgDesc) {
		this.pkgDesc = pkgDesc;
	}

	public Date getPkgEffDt() {
		return pkgEffDt;
	}

	public void setPkgEffDt(Date pkgEffDt) {
		this.pkgEffDt = pkgEffDt;
	}

	public Date getPkgExpirDt() {
		return pkgExpirDt;
	}

	public void setPkgExpirDt(Date pkgExpirDt) {
		this.pkgExpirDt = pkgExpirDt;
	}

	public Date getPkgDoNotSellDt() {
		return pkgDoNotSellDt;
	}

	public void setPkgDoNotSellDt(Date pkgDoNotSellDt) {
		this.pkgDoNotSellDt = pkgDoNotSellDt;
	}

	public Date getPkgDoNotRenDt() {
		return pkgDoNotRenDt;
	}

	public void setPkgDoNotRenDt(Date pkgDoNotRenDt) {
		this.pkgDoNotRenDt = pkgDoNotRenDt;
	}

	public String getPkgNm() {
		return pkgNm;
	}

	public void setPkgNm(String pkgNm) {
		this.pkgNm = pkgNm;
	}

	public Long getPkgOfrToTypId() {
		return pkgOfrToTypId;
	}

	public void setPkgOfrToTypId(Long pkgOfrToTypId) {
		this.pkgOfrToTypId = pkgOfrToTypId;
	}

	public String getPkgOptNm() {
		return pkgOptNm;
	}

	public void setPkgOptNm(String pkgOptNm) {
		this.pkgOptNm = pkgOptNm;
	}

	public String getPkgOptDesc() {
		return pkgOptDesc;
	}

	public void setPkgOptDesc(String pkgOptDesc) {
		this.pkgOptDesc = pkgOptDesc;
	}

	public Long getPkgOptTypId() {
		return pkgOptTypId;
	}

	public void setPkgOptTypId(Long pkgOptTypId) {
		this.pkgOptTypId = pkgOptTypId;
	}

	public Integer getSrvcAreaId() {
		return srvcAreaId;
	}

	public void setSrvcAreaId(Integer srvcAreaId) {
		this.srvcAreaId = srvcAreaId;
	}

	public String getSrvcAreaCd() {
		return srvcAreaCd;
	}

	public void setSrvcAreaCd(String srvcAreaCd) {
		this.srvcAreaCd = srvcAreaCd;
	}

	public String getSrvcAreaDesc() {
		return srvcAreaDesc;
	}

	public void setSrvcAreaDesc(String srvcAreaDesc) {
		this.srvcAreaDesc = srvcAreaDesc;
	}

	public Date getSrvcAreaEffDt() {
		return srvcAreaEffDt;
	}

	public void setSrvcAreaEffDt(Date srvcAreaEffDt) {
		this.srvcAreaEffDt = srvcAreaEffDt;
	}

	public Date getSrvcAreaExpirDt() {
		return srvcAreaExpirDt;
	}

	public void setSrvcAreaExpirDt(Date srvcAreaExpirDt) {
		this.srvcAreaExpirDt = srvcAreaExpirDt;
	}

	public Long getSrvcAreaTypId() {
		return srvcAreaTypId;
	}

	public void setSrvcAreaTypId(Long srvcAreaTypId) {
		this.srvcAreaTypId = srvcAreaTypId;
	}

	public Integer getGeoBndryId() {
		return geoBndryId;
	}

	public void setGeoBndryId(Integer geoBndryId) {
		this.geoBndryId = geoBndryId;
	}

	public String getGeoBndryCd() {
		return geoBndryCd;
	}

	public void setGeoBndryCd(String geoBndryCd) {
		this.geoBndryCd = geoBndryCd;
	}

	public String getPkgOptHiosPlnId() {
		return pkgOptHiosPlnId;
	}

	public void setPkgOptHiosPlnId(String pkgOptHiosPlnId) {
		this.pkgOptHiosPlnId = pkgOptHiosPlnId;
	}

	public Long getPkgOptPrtcpTypId() {
		return pkgOptPrtcpTypId;
	}

	public void setPkgOptPrtcpTypId(Long pkgOptPrtcpTypId) {
		this.pkgOptPrtcpTypId = pkgOptPrtcpTypId;
	}

	public Long getPkgTypId() {
		return pkgTypId;
	}

	public void setPkgTypId(Long pkgTypId) {
		this.pkgTypId = pkgTypId;
	}

	public Date getPkgTypEffDt() {
		return pkgTypEffDt;
	}

	public void setPkgTypEffDt(Date pkgTypEffDt) {
		this.pkgTypEffDt = pkgTypEffDt;
	}

	public Date getPkgTypExpirDt() {
		return pkgTypExpirDt;
	}

	public void setPkgTypExpirDt(Date pkgTypExpirDt) {
		this.pkgTypExpirDt = pkgTypExpirDt;
	}

	public Long getSitusStId() {
		return situsStId;
	}

	public void setSitusStId(Long situsStId) {
		this.situsStId = situsStId;
	}

	public Long getFundArngId() {
		return fundArngId;
	}

	public void setFundArngId(Long fundArngId) {
		this.fundArngId = fundArngId;
	}

	public Long getPpacaGrndfthrPlnStsId() {
		return ppacaGrndfthrPlnStsId;
	}

	public void setPpacaGrndfthrPlnStsId(Long ppacaGrndfthrPlnStsId) {
		this.ppacaGrndfthrPlnStsId = ppacaGrndfthrPlnStsId;
	}

	public Long getDstrbChnlId() {
		return dstrbChnlId;
	}

	public void setDstrbChnlId(Long dstrbChnlId) {
		this.dstrbChnlId = dstrbChnlId;
	}

	public Date getCustPchsEffDt() {
		return custPchsEffDt;
	}

	public void setCustPchsEffDt(Date custPchsEffDt) {
		this.custPchsEffDt = custPchsEffDt;
	}

	public Date getCustPchsTrmDt() {
		return custPchsTrmDt;
	}

	public void setCustPchsTrmDt(Date custPchsTrmDt) {
		this.custPchsTrmDt = custPchsTrmDt;
	}

	public Date getRnotDt() {
		return rnotDt;
	}

	public void setRnotDt(Date rnotDt) {
		this.rnotDt = rnotDt;
	}

	public String getRnotDtPrrPlnYr() {
		return rnotDtPrrPlnYr;
	}

	public void setRnotDtPrrPlnYr(String rnotDtPrrPlnYr) {
		this.rnotDtPrrPlnYr = rnotDtPrrPlnYr;
	}

	public String getBuyUpOptInd() {
		return buyUpOptInd;
	}

	public void setBuyUpOptInd(String buyUpOptInd) {
		this.buyUpOptInd = buyUpOptInd;
	}

	public Long getRetroEligTypId() {
		return retroEligTypId;
	}

	public void setRetroEligTypId(Long retroEligTypId) {
		this.retroEligTypId = retroEligTypId;
	}

	public Integer getRetroEligDay() {
		return retroEligDay;
	}

	public void setRetroEligDay(Integer retroEligDay) {
		this.retroEligDay = retroEligDay;
	}

	public String getDelInd() {
		return delInd;
	}

	public void setDelInd(String delInd) {
		this.delInd = delInd;
	}

	public String getSpecialFields() {
		return specialFields;
	}

	public void setSpecialFields(String specialFields) {
		this.specialFields = specialFields;
	}


}