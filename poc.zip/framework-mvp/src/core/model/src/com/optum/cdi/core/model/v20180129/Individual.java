package com.optum.cdi.core.model.v20180129;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

public class Individual {

	public Individual() {
	}

	private String indvId;
	private Long srcSysId;
	private Date effDtlDt;
	private String creatUserId;
	private Timestamp creatTmstmp;
	private String updtUserId;
	private Timestamp updtTmstmp;
	private Long audId;
	private Date cancDtlDt;
	private Long taxIdStsTypId;
	private Long nmPrfxId;
	private String indvFstNm;
	private String indvMidlNm;
	private String indvMidlInitTxt;
	private String indvLstNm;
	private Long nmSufxId;
	private String indvAlsNm;
	private String mothrMadnNm;
	private Long gdrTypId;
	private Long mrtlStsTypId;
	private Long edLvlTypId;
	private String ssn;
	private String drivLicNbr;
	private Date bthDt;
	private Date dcsdDt;
	private String doNotSlctInd;
	private Long stdntStsTypId;
	private String vetInd;
	private Integer bthSeqNbr;
	private String sbstncAbusInd;
	private String tbccUseInd;
	private String hncpInd;
	private BigDecimal indvWgt;
	private BigDecimal indvHgt;
	private String vipInd;
	private String qmscoInd;
	private String rschAuthInd;
	private Date rschAuthDt;
	private Long cmnctTypId;
	private String elctrCmnctTxt;
	private Long isoCntryTelId;
	private String areaCd;
	private String xchgNbr;
	private String telNbr;
	private String extNbr;
	private String priTelInd;
	private Long cmnctStsId;
	private String priShipAdrInd;
	private String priAdrInd;
	private String actvStsInd;
	private String indvPrefInv;
	private Date indvPstAdrBegnDt;
	private Date indvPstAdrEndDt;
	private Long cntcStsId;
	private Long empmtStsTypId;
	private Date empmtStsEffDt;
	private Date empmtStrtDt;
	private String orgId;
	private Long orgSrcSysId;
	private Date orgEffDtlDt;
	private Date empmtStsCancDt;
	private Date lstWrkDt;
	private Date rtwDt;
	private Long medcrEntlTypId;
	private Date entlEffDt;
	private Long cmsMedcrIdTypId;
	private String cmsMedcrIdTypCd;
	private String cmsMedcrId;
	private Long medcrEntlRsnTypId;
	private Date entlTrmDt;
	private String medcrEligInd;
	private Long cmsMedcdIdTypId;
	private String cmsMedcdIdTypCd;
	private String cmsMedcdId;
	private Long medcdEligTypId;
	private Long medcdMajPgmId;
	private Long adrTypId;
	private String adrLn1Txt;
	private String adrLn2Txt;
	private String adrLn3Txt;
	private String adrLn4Txt;
	private String adrLn5Txt;
	private Integer adrVldId;
	private String adrGuidVer;
	private String resDlvrInd;
	private String adrHseNbrWoFrac;
	private String adrHseNbrFrac;
	private String adrStrPrfxDir;
	private String adrStrNm;
	private String adrStrSufxAbbr;
	private String adrStrSufxDir;
	private String adrSecUnitDesg;
	private String adrSecUnitQual;
	private String adrPoBoxNbr;
	private String adrRteDesg;
	private String adrBoxNbr;
	private String adrUrbnNm;
	private String adrTnNm;
	private String adrDlvrPtCd;
	private String adrDlvrPtChkDgt;
	private String adrCarrRteCd;
	private String latDeg;
	private String lngDeg;
	private String pstCd;
	private String pstPrfxCd;
	private String pstSufxCd;
	private String pstDesc;
	private Long tmZoneId;
	private String tmZoneNm;
	private BigDecimal utcOfstTm;
	private Long isoCntryId;
	private Long isoCntrySubdivId;
	private Long fipsStId;
	private Long fipsCntyId;
	private Long stPrvcId;
	private String sbscrIndvId;
	private Long relId;
	private String cobraCovInd;
	private Long ethncTypId;
	private Long othrIdTypId;
	private Long othrIdSrcSysId;
	private String indvOthrId;
	private String othrIdDesc;
	private Date othrIdEffStrtDt;
	private Date othrIdExpirDt;
	private Date marrDt;
	private Date dvrcDt;
	private Date adptnDt;
	private Date initDlsDt;
	private String srcRelVal;
	private String delInd;
	private String specialFields;

	public String getIndvId() {
		return indvId;
	}

	public void setIndvId(String indvId) {
		this.indvId = indvId;
	}

	public Long getSrcSysId() {
		return srcSysId;
	}

	public void setSrcSysId(Long srcSysId) {
		this.srcSysId = srcSysId;
	}

	public Date getEffDtlDt() {
		return effDtlDt;
	}

	public void setEffDtlDt(Date effDtlDt) {
		this.effDtlDt = effDtlDt;
	}

	public String getCreatUserId() {
		return creatUserId;
	}

	public void setCreatUserId(String creatUserId) {
		this.creatUserId = creatUserId;
	}

	public Timestamp getCreatTmstmp() {
		return creatTmstmp;
	}

	public void setCreatTmstmp(Timestamp creatTmstmp) {
		this.creatTmstmp = creatTmstmp;
	}

	public String getUpdtUserId() {
		return updtUserId;
	}

	public void setUpdtUserId(String updtUserId) {
		this.updtUserId = updtUserId;
	}

	public Timestamp getUpdtTmstmp() {
		return updtTmstmp;
	}

	public void setUpdtTmstmp(Timestamp updtTmstmp) {
		this.updtTmstmp = updtTmstmp;
	}

	public Long getAudId() {
		return audId;
	}

	public void setAudId(Long audId) {
		this.audId = audId;
	}

	public Date getCancDtlDt() {
		return cancDtlDt;
	}

	public void setCancDtlDt(Date cancDtlDt) {
		this.cancDtlDt = cancDtlDt;
	}

	public Long getTaxIdStsTypId() {
		return taxIdStsTypId;
	}

	public void setTaxIdStsTypId(Long taxIdStsTypId) {
		this.taxIdStsTypId = taxIdStsTypId;
	}

	public Long getNmPrfxId() {
		return nmPrfxId;
	}

	public void setNmPrfxId(Long nmPrfxId) {
		this.nmPrfxId = nmPrfxId;
	}

	public String getIndvFstNm() {
		return indvFstNm;
	}

	public void setIndvFstNm(String indvFstNm) {
		this.indvFstNm = indvFstNm;
	}

	public String getIndvMidlNm() {
		return indvMidlNm;
	}

	public void setIndvMidlNm(String indvMidlNm) {
		this.indvMidlNm = indvMidlNm;
	}

	public String getIndvMidlInitTxt() {
		return indvMidlInitTxt;
	}

	public void setIndvMidlInitTxt(String indvMidlInitTxt) {
		this.indvMidlInitTxt = indvMidlInitTxt;
	}

	public String getIndvLstNm() {
		return indvLstNm;
	}

	public void setIndvLstNm(String indvLstNm) {
		this.indvLstNm = indvLstNm;
	}

	public Long getNmSufxId() {
		return nmSufxId;
	}

	public void setNmSufxId(Long nmSufxId) {
		this.nmSufxId = nmSufxId;
	}

	public String getIndvAlsNm() {
		return indvAlsNm;
	}

	public void setIndvAlsNm(String indvAlsNm) {
		this.indvAlsNm = indvAlsNm;
	}

	public String getMothrMadnNm() {
		return mothrMadnNm;
	}

	public void setMothrMadnNm(String mothrMadnNm) {
		this.mothrMadnNm = mothrMadnNm;
	}

	public Long getGdrTypId() {
		return gdrTypId;
	}

	public void setGdrTypId(Long gdrTypId) {
		this.gdrTypId = gdrTypId;
	}

	public Long getMrtlStsTypId() {
		return mrtlStsTypId;
	}

	public void setMrtlStsTypId(Long mrtlStsTypId) {
		this.mrtlStsTypId = mrtlStsTypId;
	}

	public Long getEdLvlTypId() {
		return edLvlTypId;
	}

	public void setEdLvlTypId(Long edLvlTypId) {
		this.edLvlTypId = edLvlTypId;
	}

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public String getDrivLicNbr() {
		return drivLicNbr;
	}

	public void setDrivLicNbr(String drivLicNbr) {
		this.drivLicNbr = drivLicNbr;
	}

	public Date getBthDt() {
		return bthDt;
	}

	public void setBthDt(Date bthDt) {
		this.bthDt = bthDt;
	}

	public Date getDcsdDt() {
		return dcsdDt;
	}

	public void setDcsdDt(Date dcsdDt) {
		this.dcsdDt = dcsdDt;
	}

	public String getDoNotSlctInd() {
		return doNotSlctInd;
	}

	public void setDoNotSlctInd(String doNotSlctInd) {
		this.doNotSlctInd = doNotSlctInd;
	}

	public Long getStdntStsTypId() {
		return stdntStsTypId;
	}

	public void setStdntStsTypId(Long stdntStsTypId) {
		this.stdntStsTypId = stdntStsTypId;
	}

	public String getVetInd() {
		return vetInd;
	}

	public void setVetInd(String vetInd) {
		this.vetInd = vetInd;
	}

	public Integer getBthSeqNbr() {
		return bthSeqNbr;
	}

	public void setBthSeqNbr(Integer bthSeqNbr) {
		this.bthSeqNbr = bthSeqNbr;
	}

	public String getSbstncAbusInd() {
		return sbstncAbusInd;
	}

	public void setSbstncAbusInd(String sbstncAbusInd) {
		this.sbstncAbusInd = sbstncAbusInd;
	}

	public String getTbccUseInd() {
		return tbccUseInd;
	}

	public void setTbccUseInd(String tbccUseInd) {
		this.tbccUseInd = tbccUseInd;
	}

	public String getHncpInd() {
		return hncpInd;
	}

	public void setHncpInd(String hncpInd) {
		this.hncpInd = hncpInd;
	}

	public BigDecimal getIndvWgt() {
		return indvWgt;
	}

	public void setIndvWgt(BigDecimal indvWgt) {
		this.indvWgt = indvWgt;
	}

	public BigDecimal getIndvHgt() {
		return indvHgt;
	}

	public void setIndvHgt(BigDecimal indvHgt) {
		this.indvHgt = indvHgt;
	}

	public String getVipInd() {
		return vipInd;
	}

	public void setVipInd(String vipInd) {
		this.vipInd = vipInd;
	}

	public String getQmscoInd() {
		return qmscoInd;
	}

	public void setQmscoInd(String qmscoInd) {
		this.qmscoInd = qmscoInd;
	}

	public String getRschAuthInd() {
		return rschAuthInd;
	}

	public void setRschAuthInd(String rschAuthInd) {
		this.rschAuthInd = rschAuthInd;
	}

	public Date getRschAuthDt() {
		return rschAuthDt;
	}

	public void setRschAuthDt(Date rschAuthDt) {
		this.rschAuthDt = rschAuthDt;
	}

	public Long getCmnctTypId() {
		return cmnctTypId;
	}

	public void setCmnctTypId(Long cmnctTypId) {
		this.cmnctTypId = cmnctTypId;
	}

	public String getElctrCmnctTxt() {
		return elctrCmnctTxt;
	}

	public void setElctrCmnctTxt(String elctrCmnctTxt) {
		this.elctrCmnctTxt = elctrCmnctTxt;
	}

	public Long getIsoCntryTelId() {
		return isoCntryTelId;
	}

	public void setIsoCntryTelId(Long isoCntryTelId) {
		this.isoCntryTelId = isoCntryTelId;
	}

	public String getAreaCd() {
		return areaCd;
	}

	public void setAreaCd(String areaCd) {
		this.areaCd = areaCd;
	}

	public String getXchgNbr() {
		return xchgNbr;
	}

	public void setXchgNbr(String xchgNbr) {
		this.xchgNbr = xchgNbr;
	}

	public String getTelNbr() {
		return telNbr;
	}

	public void setTelNbr(String telNbr) {
		this.telNbr = telNbr;
	}

	public String getExtNbr() {
		return extNbr;
	}

	public void setExtNbr(String extNbr) {
		this.extNbr = extNbr;
	}

	public String getPriTelInd() {
		return priTelInd;
	}

	public void setPriTelInd(String priTelInd) {
		this.priTelInd = priTelInd;
	}

	public Long getCmnctStsId() {
		return cmnctStsId;
	}

	public void setCmnctStsId(Long cmnctStsId) {
		this.cmnctStsId = cmnctStsId;
	}

	public String getPriShipAdrInd() {
		return priShipAdrInd;
	}

	public void setPriShipAdrInd(String priShipAdrInd) {
		this.priShipAdrInd = priShipAdrInd;
	}

	public String getPriAdrInd() {
		return priAdrInd;
	}

	public void setPriAdrInd(String priAdrInd) {
		this.priAdrInd = priAdrInd;
	}

	public String getActvStsInd() {
		return actvStsInd;
	}

	public void setActvStsInd(String actvStsInd) {
		this.actvStsInd = actvStsInd;
	}

	public String getIndvPrefInv() {
		return indvPrefInv;
	}

	public void setIndvPrefInv(String indvPrefInv) {
		this.indvPrefInv = indvPrefInv;
	}

	public Date getIndvPstAdrBegnDt() {
		return indvPstAdrBegnDt;
	}

	public void setIndvPstAdrBegnDt(Date indvPstAdrBegnDt) {
		this.indvPstAdrBegnDt = indvPstAdrBegnDt;
	}

	public Date getIndvPstAdrEndDt() {
		return indvPstAdrEndDt;
	}

	public void setIndvPstAdrEndDt(Date indvPstAdrEndDt) {
		this.indvPstAdrEndDt = indvPstAdrEndDt;
	}

	public Long getCntcStsId() {
		return cntcStsId;
	}

	public void setCntcStsId(Long cntcStsId) {
		this.cntcStsId = cntcStsId;
	}

	public Long getEmpmtStsTypId() {
		return empmtStsTypId;
	}

	public void setEmpmtStsTypId(Long empmtStsTypId) {
		this.empmtStsTypId = empmtStsTypId;
	}

	public Date getEmpmtStsEffDt() {
		return empmtStsEffDt;
	}

	public void setEmpmtStsEffDt(Date empmtStsEffDt) {
		this.empmtStsEffDt = empmtStsEffDt;
	}

	public Date getEmpmtStrtDt() {
		return empmtStrtDt;
	}

	public void setEmpmtStrtDt(Date empmtStrtDt) {
		this.empmtStrtDt = empmtStrtDt;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public Long getOrgSrcSysId() {
		return orgSrcSysId;
	}

	public void setOrgSrcSysId(Long orgSrcSysId) {
		this.orgSrcSysId = orgSrcSysId;
	}

	public Date getOrgEffDtlDt() {
		return orgEffDtlDt;
	}

	public void setOrgEffDtlDt(Date orgEffDtlDt) {
		this.orgEffDtlDt = orgEffDtlDt;
	}

	public Date getEmpmtStsCancDt() {
		return empmtStsCancDt;
	}

	public void setEmpmtStsCancDt(Date empmtStsCancDt) {
		this.empmtStsCancDt = empmtStsCancDt;
	}

	public Date getLstWrkDt() {
		return lstWrkDt;
	}

	public void setLstWrkDt(Date lstWrkDt) {
		this.lstWrkDt = lstWrkDt;
	}

	public Date getRtwDt() {
		return rtwDt;
	}

	public void setRtwDt(Date rtwDt) {
		this.rtwDt = rtwDt;
	}

	public Long getMedcrEntlTypId() {
		return medcrEntlTypId;
	}

	public void setMedcrEntlTypId(Long medcrEntlTypId) {
		this.medcrEntlTypId = medcrEntlTypId;
	}

	public Date getEntlEffDt() {
		return entlEffDt;
	}

	public void setEntlEffDt(Date entlEffDt) {
		this.entlEffDt = entlEffDt;
	}

	public Long getCmsMedcrIdTypId() {
		return cmsMedcrIdTypId;
	}

	public void setCmsMedcrIdTypId(Long cmsMedcrIdTypId) {
		this.cmsMedcrIdTypId = cmsMedcrIdTypId;
	}

	public String getCmsMedcrIdTypCd() {
		return cmsMedcrIdTypCd;
	}

	public void setCmsMedcrIdTypCd(String cmsMedcrIdTypCd) {
		this.cmsMedcrIdTypCd = cmsMedcrIdTypCd;
	}

	public String getCmsMedcrId() {
		return cmsMedcrId;
	}

	public void setCmsMedcrId(String cmsMedcrId) {
		this.cmsMedcrId = cmsMedcrId;
	}

	public Long getMedcrEntlRsnTypId() {
		return medcrEntlRsnTypId;
	}

	public void setMedcrEntlRsnTypId(Long medcrEntlRsnTypId) {
		this.medcrEntlRsnTypId = medcrEntlRsnTypId;
	}

	public Date getEntlTrmDt() {
		return entlTrmDt;
	}

	public void setEntlTrmDt(Date entlTrmDt) {
		this.entlTrmDt = entlTrmDt;
	}

	public String getMedcrEligInd() {
		return medcrEligInd;
	}

	public void setMedcrEligInd(String medcrEligInd) {
		this.medcrEligInd = medcrEligInd;
	}

	public Long getCmsMedcdIdTypId() {
		return cmsMedcdIdTypId;
	}

	public void setCmsMedcdIdTypId(Long cmsMedcdIdTypId) {
		this.cmsMedcdIdTypId = cmsMedcdIdTypId;
	}

	public String getCmsMedcdIdTypCd() {
		return cmsMedcdIdTypCd;
	}

	public void setCmsMedcdIdTypCd(String cmsMedcdIdTypCd) {
		this.cmsMedcdIdTypCd = cmsMedcdIdTypCd;
	}

	public String getCmsMedcdId() {
		return cmsMedcdId;
	}

	public void setCmsMedcdId(String cmsMedcdId) {
		this.cmsMedcdId = cmsMedcdId;
	}

	public Long getMedcdEligTypId() {
		return medcdEligTypId;
	}

	public void setMedcdEligTypId(Long medcdEligTypId) {
		this.medcdEligTypId = medcdEligTypId;
	}

	public Long getMedcdMajPgmId() {
		return medcdMajPgmId;
	}

	public void setMedcdMajPgmId(Long medcdMajPgmId) {
		this.medcdMajPgmId = medcdMajPgmId;
	}

	public Long getAdrTypId() {
		return adrTypId;
	}

	public void setAdrTypId(Long adrTypId) {
		this.adrTypId = adrTypId;
	}

	public String getAdrLn1Txt() {
		return adrLn1Txt;
	}

	public void setAdrLn1Txt(String adrLn1Txt) {
		this.adrLn1Txt = adrLn1Txt;
	}

	public String getAdrLn2Txt() {
		return adrLn2Txt;
	}

	public void setAdrLn2Txt(String adrLn2Txt) {
		this.adrLn2Txt = adrLn2Txt;
	}

	public String getAdrLn3Txt() {
		return adrLn3Txt;
	}

	public void setAdrLn3Txt(String adrLn3Txt) {
		this.adrLn3Txt = adrLn3Txt;
	}

	public String getAdrLn4Txt() {
		return adrLn4Txt;
	}

	public void setAdrLn4Txt(String adrLn4Txt) {
		this.adrLn4Txt = adrLn4Txt;
	}

	public String getAdrLn5Txt() {
		return adrLn5Txt;
	}

	public void setAdrLn5Txt(String adrLn5Txt) {
		this.adrLn5Txt = adrLn5Txt;
	}

	public Integer getAdrVldId() {
		return adrVldId;
	}

	public void setAdrVldId(Integer adrVldId) {
		this.adrVldId = adrVldId;
	}

	public String getAdrGuidVer() {
		return adrGuidVer;
	}

	public void setAdrGuidVer(String adrGuidVer) {
		this.adrGuidVer = adrGuidVer;
	}

	public String getResDlvrInd() {
		return resDlvrInd;
	}

	public void setResDlvrInd(String resDlvrInd) {
		this.resDlvrInd = resDlvrInd;
	}

	public String getAdrHseNbrWoFrac() {
		return adrHseNbrWoFrac;
	}

	public void setAdrHseNbrWoFrac(String adrHseNbrWoFrac) {
		this.adrHseNbrWoFrac = adrHseNbrWoFrac;
	}

	public String getAdrHseNbrFrac() {
		return adrHseNbrFrac;
	}

	public void setAdrHseNbrFrac(String adrHseNbrFrac) {
		this.adrHseNbrFrac = adrHseNbrFrac;
	}

	public String getAdrStrPrfxDir() {
		return adrStrPrfxDir;
	}

	public void setAdrStrPrfxDir(String adrStrPrfxDir) {
		this.adrStrPrfxDir = adrStrPrfxDir;
	}

	public String getAdrStrNm() {
		return adrStrNm;
	}

	public void setAdrStrNm(String adrStrNm) {
		this.adrStrNm = adrStrNm;
	}

	public String getAdrStrSufxAbbr() {
		return adrStrSufxAbbr;
	}

	public void setAdrStrSufxAbbr(String adrStrSufxAbbr) {
		this.adrStrSufxAbbr = adrStrSufxAbbr;
	}

	public String getAdrStrSufxDir() {
		return adrStrSufxDir;
	}

	public void setAdrStrSufxDir(String adrStrSufxDir) {
		this.adrStrSufxDir = adrStrSufxDir;
	}

	public String getAdrSecUnitDesg() {
		return adrSecUnitDesg;
	}

	public void setAdrSecUnitDesg(String adrSecUnitDesg) {
		this.adrSecUnitDesg = adrSecUnitDesg;
	}

	public String getAdrSecUnitQual() {
		return adrSecUnitQual;
	}

	public void setAdrSecUnitQual(String adrSecUnitQual) {
		this.adrSecUnitQual = adrSecUnitQual;
	}

	public String getAdrPoBoxNbr() {
		return adrPoBoxNbr;
	}

	public void setAdrPoBoxNbr(String adrPoBoxNbr) {
		this.adrPoBoxNbr = adrPoBoxNbr;
	}

	public String getAdrRteDesg() {
		return adrRteDesg;
	}

	public void setAdrRteDesg(String adrRteDesg) {
		this.adrRteDesg = adrRteDesg;
	}

	public String getAdrBoxNbr() {
		return adrBoxNbr;
	}

	public void setAdrBoxNbr(String adrBoxNbr) {
		this.adrBoxNbr = adrBoxNbr;
	}

	public String getAdrUrbnNm() {
		return adrUrbnNm;
	}

	public void setAdrUrbnNm(String adrUrbnNm) {
		this.adrUrbnNm = adrUrbnNm;
	}

	public String getAdrTnNm() {
		return adrTnNm;
	}

	public void setAdrTnNm(String adrTnNm) {
		this.adrTnNm = adrTnNm;
	}

	public String getAdrDlvrPtCd() {
		return adrDlvrPtCd;
	}

	public void setAdrDlvrPtCd(String adrDlvrPtCd) {
		this.adrDlvrPtCd = adrDlvrPtCd;
	}

	public String getAdrDlvrPtChkDgt() {
		return adrDlvrPtChkDgt;
	}

	public void setAdrDlvrPtChkDgt(String adrDlvrPtChkDgt) {
		this.adrDlvrPtChkDgt = adrDlvrPtChkDgt;
	}

	public String getAdrCarrRteCd() {
		return adrCarrRteCd;
	}

	public void setAdrCarrRteCd(String adrCarrRteCd) {
		this.adrCarrRteCd = adrCarrRteCd;
	}

	public String getLatDeg() {
		return latDeg;
	}

	public void setLatDeg(String latDeg) {
		this.latDeg = latDeg;
	}

	public String getLngDeg() {
		return lngDeg;
	}

	public void setLngDeg(String lngDeg) {
		this.lngDeg = lngDeg;
	}

	public String getPstCd() {
		return pstCd;
	}

	public void setPstCd(String pstCd) {
		this.pstCd = pstCd;
	}

	public String getPstPrfxCd() {
		return pstPrfxCd;
	}

	public void setPstPrfxCd(String pstPrfxCd) {
		this.pstPrfxCd = pstPrfxCd;
	}

	public String getPstSufxCd() {
		return pstSufxCd;
	}

	public void setPstSufxCd(String pstSufxCd) {
		this.pstSufxCd = pstSufxCd;
	}

	public String getPstDesc() {
		return pstDesc;
	}

	public void setPstDesc(String pstDesc) {
		this.pstDesc = pstDesc;
	}

	public Long getTmZoneId() {
		return tmZoneId;
	}

	public void setTmZoneId(Long tmZoneId) {
		this.tmZoneId = tmZoneId;
	}

	public String getTmZoneNm() {
		return tmZoneNm;
	}

	public void setTmZoneNm(String tmZoneNm) {
		this.tmZoneNm = tmZoneNm;
	}

	public BigDecimal getUtcOfstTm() {
		return utcOfstTm;
	}

	public void setUtcOfstTm(BigDecimal utcOfstTm) {
		this.utcOfstTm = utcOfstTm;
	}

	public Long getIsoCntryId() {
		return isoCntryId;
	}

	public void setIsoCntryId(Long isoCntryId) {
		this.isoCntryId = isoCntryId;
	}

	public Long getIsoCntrySubdivId() {
		return isoCntrySubdivId;
	}

	public void setIsoCntrySubdivId(Long isoCntrySubdivId) {
		this.isoCntrySubdivId = isoCntrySubdivId;
	}

	public Long getFipsStId() {
		return fipsStId;
	}

	public void setFipsStId(Long fipsStId) {
		this.fipsStId = fipsStId;
	}

	public Long getFipsCntyId() {
		return fipsCntyId;
	}

	public void setFipsCntyId(Long fipsCntyId) {
		this.fipsCntyId = fipsCntyId;
	}

	public Long getStPrvcId() {
		return stPrvcId;
	}

	public void setStPrvcId(Long stPrvcId) {
		this.stPrvcId = stPrvcId;
	}

	public String getSbscrIndvId() {
		return sbscrIndvId;
	}

	public void setSbscrIndvId(String sbscrIndvId) {
		this.sbscrIndvId = sbscrIndvId;
	}

	public Long getRelId() {
		return relId;
	}

	public void setRelId(Long relId) {
		this.relId = relId;
	}

	public String getCobraCovInd() {
		return cobraCovInd;
	}

	public void setCobraCovInd(String cobraCovInd) {
		this.cobraCovInd = cobraCovInd;
	}

	public Long getEthncTypId() {
		return ethncTypId;
	}

	public void setEthncTypId(Long ethncTypId) {
		this.ethncTypId = ethncTypId;
	}

	public Long getOthrIdTypId() {
		return othrIdTypId;
	}

	public void setOthrIdTypId(Long othrIdTypId) {
		this.othrIdTypId = othrIdTypId;
	}

	public Long getOthrIdSrcSysId() {
		return othrIdSrcSysId;
	}

	public void setOthrIdSrcSysId(Long othrIdSrcSysId) {
		this.othrIdSrcSysId = othrIdSrcSysId;
	}

	public String getIndvOthrId() {
		return indvOthrId;
	}

	public void setIndvOthrId(String indvOthrId) {
		this.indvOthrId = indvOthrId;
	}

	public String getOthrIdDesc() {
		return othrIdDesc;
	}

	public void setOthrIdDesc(String othrIdDesc) {
		this.othrIdDesc = othrIdDesc;
	}

	public Date getOthrIdEffStrtDt() {
		return othrIdEffStrtDt;
	}

	public void setOthrIdEffStrtDt(Date othrIdEffStrtDt) {
		this.othrIdEffStrtDt = othrIdEffStrtDt;
	}

	public Date getOthrIdExpirDt() {
		return othrIdExpirDt;
	}

	public void setOthrIdExpirDt(Date othrIdExpirDt) {
		this.othrIdExpirDt = othrIdExpirDt;
	}

	public Date getMarrDt() {
		return marrDt;
	}

	public void setMarrDt(Date marrDt) {
		this.marrDt = marrDt;
	}

	public Date getDvrcDt() {
		return dvrcDt;
	}

	public void setDvrcDt(Date dvrcDt) {
		this.dvrcDt = dvrcDt;
	}

	public Date getAdptnDt() {
		return adptnDt;
	}

	public void setAdptnDt(Date adptnDt) {
		this.adptnDt = adptnDt;
	}

	public Date getInitDlsDt() {
		return initDlsDt;
	}

	public void setInitDlsDt(Date initDlsDt) {
		this.initDlsDt = initDlsDt;
	}

	public String getSrcRelVal() {
		return srcRelVal;
	}

	public void setSrcRelVal(String srcRelVal) {
		this.srcRelVal = srcRelVal;
	}

	public String getDelInd() {
		return delInd;
	}

	public void setDelInd(String delInd) {
		this.delInd = delInd;
	}

	public String getSpecialFields() {
		return specialFields;
	}

	public void setSpecialFields(String specialFields) {
		this.specialFields = specialFields;
	}


}