package com.optum.cdi.core.model.v20180129;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

public class ClaimTransSrvcLine {

	public ClaimTransSrvcLine() {
	}

	private String clmId;
	private Integer clmVerNbr;
	private Long srcSysId;
	private Integer clmSrvcLnNbr;
	private String creatUserId;
	private Timestamp creatTmstmp;
	private String updtUserId;
	private Timestamp updtTmstmp;
	private Long audId;
	private String srcClmVerNbr;
	private String srcClmVerAdjNbr;
	private Integer srvcAdjdGrpId;
	private Long srvcLnStsId;
	private Long srvcProcId;
	private String srvcProcLvlCd;
	private String srvcProcCd;
	private Long rvnuId;
	private String rvnuCd;
	private String profDiag1PtNbr;
	private String profDiag2PtNbr;
	private String profDiag3PtNbr;
	private String profDiag4PtNbr;
	private String profEmrgInd;
	private String profEpsdtInd;
	private String profFamPlnInd;
	private String profCopayStsInd;
	private Long srvcCovTypId;
	private Long plsrvId;
	private String ordrProvId;
	private Long ordrProvSrcSysId;
	private Date ordrProvEffDtlDt;
	private String rndrProvId;
	private Long rndrProvSrcSysId;
	private Date rndrProvEffDtlDt;
	private Integer rndrNpi;
	private Long rndrProvTypId;
	private Long rndrProvClssTypId;
	private Long rndrProvSpclTypId;
	private String pchsSrvcProvId;
	private Long pchsSrvcProvSrcSysId;
	private Date pchsSrvcProvEffDtlDt;
	private String operProvId;
	private Long operProvSrcSysId;
	private Date operProvEffDtlDt;
	private String othrOperProvSrcSysId;
	private Integer othrOperProvId;
	private Date othrOperProvEffDtlDt;
	private String supvProvId;
	private Long supvProvSrcSysId;
	private Date supvProvEffDtlDt;
	private String refProvId;
	private Long refProvSrcSysId;
	private Date refProvEffDtlDt;
	private String srvcLocProvId;
	private Long srvcLocProvSrcSysId;
	private Date srvcLocProvEffDtlDt;
	private Long srvcLocProvAdrTypId;
	private String srvcLocProvLocId;
	private Date srvcLocProvPracLocEffDtlDt;
	private Long prcMethTypId;
	private Long srvcUnitMsrId;
	private BigDecimal srvcUnitCnt;
	private BigDecimal aprvSrvcUnitCnt;
	private Long aprvSrvcUnitMsrId;
	private Long ndcId;
	private String drgPrscNbr;
	private String prscDeaNbr;
	private Long drgUomId;
	private BigDecimal drgUnitCnt;
	private Integer rflNbr;
	private Integer payrFrmlryId;
	private Long procMod1Id;
	private String procMod1Cd;
	private Long procMod2Id;
	private String procMod2Cd;
	private Long procMod3Id;
	private String procMod3Cd;
	private Long procMod4Id;
	private String procMod4Cd;
	private Integer srvcSpltGrpId;
	private String oonSrvcInd;
	private String oonSrvcRndrProvInd;
	private String cptnInd;
	private BigDecimal obstAnesAddUnitCnt;
	private String srvcLnCommtTxt;
	private String srvcLnDenyInd;
	private String hspcEeInd;
	private Long dmeRntUomId;
	private BigDecimal dmeInitDurMoCnt;
	private BigDecimal dmeRenDurMoCnt;
	private BigDecimal dmeRvsDurMoCnt;
	private BigDecimal dmePchsPrcAmt;
	private Date srvcDt;
	private Date srvcEndDt;
	private Date claDt;
	private BigDecimal claTm;
	private Date certRvsDt;
	private Date lstCertDt;
	private Date trpyStrtDt;
	private Date ptntLstSeen1Dt;
	private Date ptntLstSeen2Dt;
	private Date hmglbnTstDt;
	private Date srmCrtinTstDt;
	private Date oxgnTstDt;
	private Date prdctShipDt;
	private Date sympDt;
	private Date lstXrayDt;
	private Date ptntMnfstDt;
	private Date initTrtDt;
	private Date simIllDt;
	private Date clmPdDt;
	private String chkNbr;
	private Long tthSysId;
	private String tthIdVal;
	private String tthIdFromVal;
	private String tthIdToVal;
	private Long tthSrfc1Id;
	private Long tthSrfc2Id;
	private Long tthSrfc3Id;
	private Long tthSrfc4Id;
	private Long tthSrfc5Id;
	private Long tthSrfc6Id;
	private Long areaOfOralCvty1Id;
	private Long areaOfOralCvty2Id;
	private Long areaOfOralCvty3Id;
	private BigDecimal homOxgnTrpyInitMoCnt;
	private BigDecimal homOxgnTrpyRenMoCnt;
	private BigDecimal homOxgnTrpyRvsMoCnt;
	private BigDecimal artryBlodGasCnt;
	private BigDecimal oxgnStrtnCnt;
	private Long oxgnTstCond1Id;
	private Long oxgnTstCond2Id;
	private Long oxgnTstCond3Id;
	private BigDecimal oxgnFlowRt;
	private String univPrdctNbr;
	private String srvcLnPrcInd;
	private BigDecimal srvcBilChrgAmt;
	private BigDecimal pchsSrvcChrgLnAmt;
	private BigDecimal bilRtLnAmt;
	private BigDecimal sbmtNonCovChrgLnAmt;
	private BigDecimal bilChrgLnAmt;
	private BigDecimal saleTaxLnAmt;
	private BigDecimal pstgClmLnAmt;
	private BigDecimal allwLnAmt;
	private BigDecimal eligAmt;
	private BigDecimal benCoinsLnAmt;
	private BigDecimal benCopayLnAmt;
	private BigDecimal benLmtAmt;
	private BigDecimal benPayLnAmt;
	private BigDecimal mbrRespLnAmt;
	private BigDecimal dedLnAmt;
	private BigDecimal provContrAmt;
	private BigDecimal aprvLnAmt;
	private BigDecimal covAmt;
	private BigDecimal contrWthldCntngyLnAmt;
	private BigDecimal cptnPayLnAmt;
	private BigDecimal cptnAdjLnAmt;
	private BigDecimal dupChrgLnAmt;
	private BigDecimal nonDupChrgLnAmt;
	private BigDecimal enctrPrcLnAmt;
	private BigDecimal provSnctnLnAmt;
	private BigDecimal cobRducLnAmt;
	private BigDecimal cobSvLnAmt;
	private BigDecimal rducLnAmt;
	private BigDecimal promptPayDscntLnAmt;
	private BigDecimal dscntLnAmt;
	private BigDecimal spclNegotDscntLnAmt;
	private BigDecimal suplPayLnAmt;
	private BigDecimal prcAllocPct;
	private BigDecimal netPdLnAmt;
	private BigDecimal othrPayrSrvcPdAmt;
	private BigDecimal ncLnAmt;
	private BigDecimal medcrPdLnAmt;
	private BigDecimal medcrCoinsLnAmt;
	private BigDecimal medcrDedLnAmt;
	private Long surchrgTaxId;
	private BigDecimal surchrgTaxLnLnAmt;
	private String nrsHomInd;
	private String clmLvlSumInd;
	private Long clmAdjRsnId;
	private Long authTypId;
	private String refInd;
	private String authNbr;
	private String delInd;
	private String specialFields;

	public String getClmId() {
		return clmId;
	}

	public void setClmId(String clmId) {
		this.clmId = clmId;
	}

	public Integer getClmVerNbr() {
		return clmVerNbr;
	}

	public void setClmVerNbr(Integer clmVerNbr) {
		this.clmVerNbr = clmVerNbr;
	}

	public Long getSrcSysId() {
		return srcSysId;
	}

	public void setSrcSysId(Long srcSysId) {
		this.srcSysId = srcSysId;
	}

	public Integer getClmSrvcLnNbr() {
		return clmSrvcLnNbr;
	}

	public void setClmSrvcLnNbr(Integer clmSrvcLnNbr) {
		this.clmSrvcLnNbr = clmSrvcLnNbr;
	}

	public String getCreatUserId() {
		return creatUserId;
	}

	public void setCreatUserId(String creatUserId) {
		this.creatUserId = creatUserId;
	}

	public Timestamp getCreatTmstmp() {
		return creatTmstmp;
	}

	public void setCreatTmstmp(Timestamp creatTmstmp) {
		this.creatTmstmp = creatTmstmp;
	}

	public String getUpdtUserId() {
		return updtUserId;
	}

	public void setUpdtUserId(String updtUserId) {
		this.updtUserId = updtUserId;
	}

	public Timestamp getUpdtTmstmp() {
		return updtTmstmp;
	}

	public void setUpdtTmstmp(Timestamp updtTmstmp) {
		this.updtTmstmp = updtTmstmp;
	}

	public Long getAudId() {
		return audId;
	}

	public void setAudId(Long audId) {
		this.audId = audId;
	}

	public String getSrcClmVerNbr() {
		return srcClmVerNbr;
	}

	public void setSrcClmVerNbr(String srcClmVerNbr) {
		this.srcClmVerNbr = srcClmVerNbr;
	}

	public String getSrcClmVerAdjNbr() {
		return srcClmVerAdjNbr;
	}

	public void setSrcClmVerAdjNbr(String srcClmVerAdjNbr) {
		this.srcClmVerAdjNbr = srcClmVerAdjNbr;
	}

	public Integer getSrvcAdjdGrpId() {
		return srvcAdjdGrpId;
	}

	public void setSrvcAdjdGrpId(Integer srvcAdjdGrpId) {
		this.srvcAdjdGrpId = srvcAdjdGrpId;
	}

	public Long getSrvcLnStsId() {
		return srvcLnStsId;
	}

	public void setSrvcLnStsId(Long srvcLnStsId) {
		this.srvcLnStsId = srvcLnStsId;
	}

	public Long getSrvcProcId() {
		return srvcProcId;
	}

	public void setSrvcProcId(Long srvcProcId) {
		this.srvcProcId = srvcProcId;
	}

	public String getSrvcProcLvlCd() {
		return srvcProcLvlCd;
	}

	public void setSrvcProcLvlCd(String srvcProcLvlCd) {
		this.srvcProcLvlCd = srvcProcLvlCd;
	}

	public String getSrvcProcCd() {
		return srvcProcCd;
	}

	public void setSrvcProcCd(String srvcProcCd) {
		this.srvcProcCd = srvcProcCd;
	}

	public Long getRvnuId() {
		return rvnuId;
	}

	public void setRvnuId(Long rvnuId) {
		this.rvnuId = rvnuId;
	}

	public String getRvnuCd() {
		return rvnuCd;
	}

	public void setRvnuCd(String rvnuCd) {
		this.rvnuCd = rvnuCd;
	}

	public String getProfDiag1PtNbr() {
		return profDiag1PtNbr;
	}

	public void setProfDiag1PtNbr(String profDiag1PtNbr) {
		this.profDiag1PtNbr = profDiag1PtNbr;
	}

	public String getProfDiag2PtNbr() {
		return profDiag2PtNbr;
	}

	public void setProfDiag2PtNbr(String profDiag2PtNbr) {
		this.profDiag2PtNbr = profDiag2PtNbr;
	}

	public String getProfDiag3PtNbr() {
		return profDiag3PtNbr;
	}

	public void setProfDiag3PtNbr(String profDiag3PtNbr) {
		this.profDiag3PtNbr = profDiag3PtNbr;
	}

	public String getProfDiag4PtNbr() {
		return profDiag4PtNbr;
	}

	public void setProfDiag4PtNbr(String profDiag4PtNbr) {
		this.profDiag4PtNbr = profDiag4PtNbr;
	}

	public String getProfEmrgInd() {
		return profEmrgInd;
	}

	public void setProfEmrgInd(String profEmrgInd) {
		this.profEmrgInd = profEmrgInd;
	}

	public String getProfEpsdtInd() {
		return profEpsdtInd;
	}

	public void setProfEpsdtInd(String profEpsdtInd) {
		this.profEpsdtInd = profEpsdtInd;
	}

	public String getProfFamPlnInd() {
		return profFamPlnInd;
	}

	public void setProfFamPlnInd(String profFamPlnInd) {
		this.profFamPlnInd = profFamPlnInd;
	}

	public String getProfCopayStsInd() {
		return profCopayStsInd;
	}

	public void setProfCopayStsInd(String profCopayStsInd) {
		this.profCopayStsInd = profCopayStsInd;
	}

	public Long getSrvcCovTypId() {
		return srvcCovTypId;
	}

	public void setSrvcCovTypId(Long srvcCovTypId) {
		this.srvcCovTypId = srvcCovTypId;
	}

	public Long getPlsrvId() {
		return plsrvId;
	}

	public void setPlsrvId(Long plsrvId) {
		this.plsrvId = plsrvId;
	}

	public String getOrdrProvId() {
		return ordrProvId;
	}

	public void setOrdrProvId(String ordrProvId) {
		this.ordrProvId = ordrProvId;
	}

	public Long getOrdrProvSrcSysId() {
		return ordrProvSrcSysId;
	}

	public void setOrdrProvSrcSysId(Long ordrProvSrcSysId) {
		this.ordrProvSrcSysId = ordrProvSrcSysId;
	}

	public Date getOrdrProvEffDtlDt() {
		return ordrProvEffDtlDt;
	}

	public void setOrdrProvEffDtlDt(Date ordrProvEffDtlDt) {
		this.ordrProvEffDtlDt = ordrProvEffDtlDt;
	}

	public String getRndrProvId() {
		return rndrProvId;
	}

	public void setRndrProvId(String rndrProvId) {
		this.rndrProvId = rndrProvId;
	}

	public Long getRndrProvSrcSysId() {
		return rndrProvSrcSysId;
	}

	public void setRndrProvSrcSysId(Long rndrProvSrcSysId) {
		this.rndrProvSrcSysId = rndrProvSrcSysId;
	}

	public Date getRndrProvEffDtlDt() {
		return rndrProvEffDtlDt;
	}

	public void setRndrProvEffDtlDt(Date rndrProvEffDtlDt) {
		this.rndrProvEffDtlDt = rndrProvEffDtlDt;
	}

	public Integer getRndrNpi() {
		return rndrNpi;
	}

	public void setRndrNpi(Integer rndrNpi) {
		this.rndrNpi = rndrNpi;
	}

	public Long getRndrProvTypId() {
		return rndrProvTypId;
	}

	public void setRndrProvTypId(Long rndrProvTypId) {
		this.rndrProvTypId = rndrProvTypId;
	}

	public Long getRndrProvClssTypId() {
		return rndrProvClssTypId;
	}

	public void setRndrProvClssTypId(Long rndrProvClssTypId) {
		this.rndrProvClssTypId = rndrProvClssTypId;
	}

	public Long getRndrProvSpclTypId() {
		return rndrProvSpclTypId;
	}

	public void setRndrProvSpclTypId(Long rndrProvSpclTypId) {
		this.rndrProvSpclTypId = rndrProvSpclTypId;
	}

	public String getPchsSrvcProvId() {
		return pchsSrvcProvId;
	}

	public void setPchsSrvcProvId(String pchsSrvcProvId) {
		this.pchsSrvcProvId = pchsSrvcProvId;
	}

	public Long getPchsSrvcProvSrcSysId() {
		return pchsSrvcProvSrcSysId;
	}

	public void setPchsSrvcProvSrcSysId(Long pchsSrvcProvSrcSysId) {
		this.pchsSrvcProvSrcSysId = pchsSrvcProvSrcSysId;
	}

	public Date getPchsSrvcProvEffDtlDt() {
		return pchsSrvcProvEffDtlDt;
	}

	public void setPchsSrvcProvEffDtlDt(Date pchsSrvcProvEffDtlDt) {
		this.pchsSrvcProvEffDtlDt = pchsSrvcProvEffDtlDt;
	}

	public String getOperProvId() {
		return operProvId;
	}

	public void setOperProvId(String operProvId) {
		this.operProvId = operProvId;
	}

	public Long getOperProvSrcSysId() {
		return operProvSrcSysId;
	}

	public void setOperProvSrcSysId(Long operProvSrcSysId) {
		this.operProvSrcSysId = operProvSrcSysId;
	}

	public Date getOperProvEffDtlDt() {
		return operProvEffDtlDt;
	}

	public void setOperProvEffDtlDt(Date operProvEffDtlDt) {
		this.operProvEffDtlDt = operProvEffDtlDt;
	}

	public String getOthrOperProvSrcSysId() {
		return othrOperProvSrcSysId;
	}

	public void setOthrOperProvSrcSysId(String othrOperProvSrcSysId) {
		this.othrOperProvSrcSysId = othrOperProvSrcSysId;
	}

	public Integer getOthrOperProvId() {
		return othrOperProvId;
	}

	public void setOthrOperProvId(Integer othrOperProvId) {
		this.othrOperProvId = othrOperProvId;
	}

	public Date getOthrOperProvEffDtlDt() {
		return othrOperProvEffDtlDt;
	}

	public void setOthrOperProvEffDtlDt(Date othrOperProvEffDtlDt) {
		this.othrOperProvEffDtlDt = othrOperProvEffDtlDt;
	}

	public String getSupvProvId() {
		return supvProvId;
	}

	public void setSupvProvId(String supvProvId) {
		this.supvProvId = supvProvId;
	}

	public Long getSupvProvSrcSysId() {
		return supvProvSrcSysId;
	}

	public void setSupvProvSrcSysId(Long supvProvSrcSysId) {
		this.supvProvSrcSysId = supvProvSrcSysId;
	}

	public Date getSupvProvEffDtlDt() {
		return supvProvEffDtlDt;
	}

	public void setSupvProvEffDtlDt(Date supvProvEffDtlDt) {
		this.supvProvEffDtlDt = supvProvEffDtlDt;
	}

	public String getRefProvId() {
		return refProvId;
	}

	public void setRefProvId(String refProvId) {
		this.refProvId = refProvId;
	}

	public Long getRefProvSrcSysId() {
		return refProvSrcSysId;
	}

	public void setRefProvSrcSysId(Long refProvSrcSysId) {
		this.refProvSrcSysId = refProvSrcSysId;
	}

	public Date getRefProvEffDtlDt() {
		return refProvEffDtlDt;
	}

	public void setRefProvEffDtlDt(Date refProvEffDtlDt) {
		this.refProvEffDtlDt = refProvEffDtlDt;
	}

	public String getSrvcLocProvId() {
		return srvcLocProvId;
	}

	public void setSrvcLocProvId(String srvcLocProvId) {
		this.srvcLocProvId = srvcLocProvId;
	}

	public Long getSrvcLocProvSrcSysId() {
		return srvcLocProvSrcSysId;
	}

	public void setSrvcLocProvSrcSysId(Long srvcLocProvSrcSysId) {
		this.srvcLocProvSrcSysId = srvcLocProvSrcSysId;
	}

	public Date getSrvcLocProvEffDtlDt() {
		return srvcLocProvEffDtlDt;
	}

	public void setSrvcLocProvEffDtlDt(Date srvcLocProvEffDtlDt) {
		this.srvcLocProvEffDtlDt = srvcLocProvEffDtlDt;
	}

	public Long getSrvcLocProvAdrTypId() {
		return srvcLocProvAdrTypId;
	}

	public void setSrvcLocProvAdrTypId(Long srvcLocProvAdrTypId) {
		this.srvcLocProvAdrTypId = srvcLocProvAdrTypId;
	}

	public String getSrvcLocProvLocId() {
		return srvcLocProvLocId;
	}

	public void setSrvcLocProvLocId(String srvcLocProvLocId) {
		this.srvcLocProvLocId = srvcLocProvLocId;
	}

	public Date getSrvcLocProvPracLocEffDtlDt() {
		return srvcLocProvPracLocEffDtlDt;
	}

	public void setSrvcLocProvPracLocEffDtlDt(Date srvcLocProvPracLocEffDtlDt) {
		this.srvcLocProvPracLocEffDtlDt = srvcLocProvPracLocEffDtlDt;
	}

	public Long getPrcMethTypId() {
		return prcMethTypId;
	}

	public void setPrcMethTypId(Long prcMethTypId) {
		this.prcMethTypId = prcMethTypId;
	}

	public Long getSrvcUnitMsrId() {
		return srvcUnitMsrId;
	}

	public void setSrvcUnitMsrId(Long srvcUnitMsrId) {
		this.srvcUnitMsrId = srvcUnitMsrId;
	}

	public BigDecimal getSrvcUnitCnt() {
		return srvcUnitCnt;
	}

	public void setSrvcUnitCnt(BigDecimal srvcUnitCnt) {
		this.srvcUnitCnt = srvcUnitCnt;
	}

	public BigDecimal getAprvSrvcUnitCnt() {
		return aprvSrvcUnitCnt;
	}

	public void setAprvSrvcUnitCnt(BigDecimal aprvSrvcUnitCnt) {
		this.aprvSrvcUnitCnt = aprvSrvcUnitCnt;
	}

	public Long getAprvSrvcUnitMsrId() {
		return aprvSrvcUnitMsrId;
	}

	public void setAprvSrvcUnitMsrId(Long aprvSrvcUnitMsrId) {
		this.aprvSrvcUnitMsrId = aprvSrvcUnitMsrId;
	}

	public Long getNdcId() {
		return ndcId;
	}

	public void setNdcId(Long ndcId) {
		this.ndcId = ndcId;
	}

	public String getDrgPrscNbr() {
		return drgPrscNbr;
	}

	public void setDrgPrscNbr(String drgPrscNbr) {
		this.drgPrscNbr = drgPrscNbr;
	}

	public String getPrscDeaNbr() {
		return prscDeaNbr;
	}

	public void setPrscDeaNbr(String prscDeaNbr) {
		this.prscDeaNbr = prscDeaNbr;
	}

	public Long getDrgUomId() {
		return drgUomId;
	}

	public void setDrgUomId(Long drgUomId) {
		this.drgUomId = drgUomId;
	}

	public BigDecimal getDrgUnitCnt() {
		return drgUnitCnt;
	}

	public void setDrgUnitCnt(BigDecimal drgUnitCnt) {
		this.drgUnitCnt = drgUnitCnt;
	}

	public Integer getRflNbr() {
		return rflNbr;
	}

	public void setRflNbr(Integer rflNbr) {
		this.rflNbr = rflNbr;
	}

	public Integer getPayrFrmlryId() {
		return payrFrmlryId;
	}

	public void setPayrFrmlryId(Integer payrFrmlryId) {
		this.payrFrmlryId = payrFrmlryId;
	}

	public Long getProcMod1Id() {
		return procMod1Id;
	}

	public void setProcMod1Id(Long procMod1Id) {
		this.procMod1Id = procMod1Id;
	}

	public String getProcMod1Cd() {
		return procMod1Cd;
	}

	public void setProcMod1Cd(String procMod1Cd) {
		this.procMod1Cd = procMod1Cd;
	}

	public Long getProcMod2Id() {
		return procMod2Id;
	}

	public void setProcMod2Id(Long procMod2Id) {
		this.procMod2Id = procMod2Id;
	}

	public String getProcMod2Cd() {
		return procMod2Cd;
	}

	public void setProcMod2Cd(String procMod2Cd) {
		this.procMod2Cd = procMod2Cd;
	}

	public Long getProcMod3Id() {
		return procMod3Id;
	}

	public void setProcMod3Id(Long procMod3Id) {
		this.procMod3Id = procMod3Id;
	}

	public String getProcMod3Cd() {
		return procMod3Cd;
	}

	public void setProcMod3Cd(String procMod3Cd) {
		this.procMod3Cd = procMod3Cd;
	}

	public Long getProcMod4Id() {
		return procMod4Id;
	}

	public void setProcMod4Id(Long procMod4Id) {
		this.procMod4Id = procMod4Id;
	}

	public String getProcMod4Cd() {
		return procMod4Cd;
	}

	public void setProcMod4Cd(String procMod4Cd) {
		this.procMod4Cd = procMod4Cd;
	}

	public Integer getSrvcSpltGrpId() {
		return srvcSpltGrpId;
	}

	public void setSrvcSpltGrpId(Integer srvcSpltGrpId) {
		this.srvcSpltGrpId = srvcSpltGrpId;
	}

	public String getOonSrvcInd() {
		return oonSrvcInd;
	}

	public void setOonSrvcInd(String oonSrvcInd) {
		this.oonSrvcInd = oonSrvcInd;
	}

	public String getOonSrvcRndrProvInd() {
		return oonSrvcRndrProvInd;
	}

	public void setOonSrvcRndrProvInd(String oonSrvcRndrProvInd) {
		this.oonSrvcRndrProvInd = oonSrvcRndrProvInd;
	}

	public String getCptnInd() {
		return cptnInd;
	}

	public void setCptnInd(String cptnInd) {
		this.cptnInd = cptnInd;
	}

	public BigDecimal getObstAnesAddUnitCnt() {
		return obstAnesAddUnitCnt;
	}

	public void setObstAnesAddUnitCnt(BigDecimal obstAnesAddUnitCnt) {
		this.obstAnesAddUnitCnt = obstAnesAddUnitCnt;
	}

	public String getSrvcLnCommtTxt() {
		return srvcLnCommtTxt;
	}

	public void setSrvcLnCommtTxt(String srvcLnCommtTxt) {
		this.srvcLnCommtTxt = srvcLnCommtTxt;
	}

	public String getSrvcLnDenyInd() {
		return srvcLnDenyInd;
	}

	public void setSrvcLnDenyInd(String srvcLnDenyInd) {
		this.srvcLnDenyInd = srvcLnDenyInd;
	}

	public String getHspcEeInd() {
		return hspcEeInd;
	}

	public void setHspcEeInd(String hspcEeInd) {
		this.hspcEeInd = hspcEeInd;
	}

	public Long getDmeRntUomId() {
		return dmeRntUomId;
	}

	public void setDmeRntUomId(Long dmeRntUomId) {
		this.dmeRntUomId = dmeRntUomId;
	}

	public BigDecimal getDmeInitDurMoCnt() {
		return dmeInitDurMoCnt;
	}

	public void setDmeInitDurMoCnt(BigDecimal dmeInitDurMoCnt) {
		this.dmeInitDurMoCnt = dmeInitDurMoCnt;
	}

	public BigDecimal getDmeRenDurMoCnt() {
		return dmeRenDurMoCnt;
	}

	public void setDmeRenDurMoCnt(BigDecimal dmeRenDurMoCnt) {
		this.dmeRenDurMoCnt = dmeRenDurMoCnt;
	}

	public BigDecimal getDmeRvsDurMoCnt() {
		return dmeRvsDurMoCnt;
	}

	public void setDmeRvsDurMoCnt(BigDecimal dmeRvsDurMoCnt) {
		this.dmeRvsDurMoCnt = dmeRvsDurMoCnt;
	}

	public BigDecimal getDmePchsPrcAmt() {
		return dmePchsPrcAmt;
	}

	public void setDmePchsPrcAmt(BigDecimal dmePchsPrcAmt) {
		this.dmePchsPrcAmt = dmePchsPrcAmt;
	}

	public Date getSrvcDt() {
		return srvcDt;
	}

	public void setSrvcDt(Date srvcDt) {
		this.srvcDt = srvcDt;
	}

	public Date getSrvcEndDt() {
		return srvcEndDt;
	}

	public void setSrvcEndDt(Date srvcEndDt) {
		this.srvcEndDt = srvcEndDt;
	}

	public Date getClaDt() {
		return claDt;
	}

	public void setClaDt(Date claDt) {
		this.claDt = claDt;
	}

	public BigDecimal getClaTm() {
		return claTm;
	}

	public void setClaTm(BigDecimal claTm) {
		this.claTm = claTm;
	}

	public Date getCertRvsDt() {
		return certRvsDt;
	}

	public void setCertRvsDt(Date certRvsDt) {
		this.certRvsDt = certRvsDt;
	}

	public Date getLstCertDt() {
		return lstCertDt;
	}

	public void setLstCertDt(Date lstCertDt) {
		this.lstCertDt = lstCertDt;
	}

	public Date getTrpyStrtDt() {
		return trpyStrtDt;
	}

	public void setTrpyStrtDt(Date trpyStrtDt) {
		this.trpyStrtDt = trpyStrtDt;
	}

	public Date getPtntLstSeen1Dt() {
		return ptntLstSeen1Dt;
	}

	public void setPtntLstSeen1Dt(Date ptntLstSeen1Dt) {
		this.ptntLstSeen1Dt = ptntLstSeen1Dt;
	}

	public Date getPtntLstSeen2Dt() {
		return ptntLstSeen2Dt;
	}

	public void setPtntLstSeen2Dt(Date ptntLstSeen2Dt) {
		this.ptntLstSeen2Dt = ptntLstSeen2Dt;
	}

	public Date getHmglbnTstDt() {
		return hmglbnTstDt;
	}

	public void setHmglbnTstDt(Date hmglbnTstDt) {
		this.hmglbnTstDt = hmglbnTstDt;
	}

	public Date getSrmCrtinTstDt() {
		return srmCrtinTstDt;
	}

	public void setSrmCrtinTstDt(Date srmCrtinTstDt) {
		this.srmCrtinTstDt = srmCrtinTstDt;
	}

	public Date getOxgnTstDt() {
		return oxgnTstDt;
	}

	public void setOxgnTstDt(Date oxgnTstDt) {
		this.oxgnTstDt = oxgnTstDt;
	}

	public Date getPrdctShipDt() {
		return prdctShipDt;
	}

	public void setPrdctShipDt(Date prdctShipDt) {
		this.prdctShipDt = prdctShipDt;
	}

	public Date getSympDt() {
		return sympDt;
	}

	public void setSympDt(Date sympDt) {
		this.sympDt = sympDt;
	}

	public Date getLstXrayDt() {
		return lstXrayDt;
	}

	public void setLstXrayDt(Date lstXrayDt) {
		this.lstXrayDt = lstXrayDt;
	}

	public Date getPtntMnfstDt() {
		return ptntMnfstDt;
	}

	public void setPtntMnfstDt(Date ptntMnfstDt) {
		this.ptntMnfstDt = ptntMnfstDt;
	}

	public Date getInitTrtDt() {
		return initTrtDt;
	}

	public void setInitTrtDt(Date initTrtDt) {
		this.initTrtDt = initTrtDt;
	}

	public Date getSimIllDt() {
		return simIllDt;
	}

	public void setSimIllDt(Date simIllDt) {
		this.simIllDt = simIllDt;
	}

	public Date getClmPdDt() {
		return clmPdDt;
	}

	public void setClmPdDt(Date clmPdDt) {
		this.clmPdDt = clmPdDt;
	}

	public String getChkNbr() {
		return chkNbr;
	}

	public void setChkNbr(String chkNbr) {
		this.chkNbr = chkNbr;
	}

	public Long getTthSysId() {
		return tthSysId;
	}

	public void setTthSysId(Long tthSysId) {
		this.tthSysId = tthSysId;
	}

	public String getTthIdVal() {
		return tthIdVal;
	}

	public void setTthIdVal(String tthIdVal) {
		this.tthIdVal = tthIdVal;
	}

	public String getTthIdFromVal() {
		return tthIdFromVal;
	}

	public void setTthIdFromVal(String tthIdFromVal) {
		this.tthIdFromVal = tthIdFromVal;
	}

	public String getTthIdToVal() {
		return tthIdToVal;
	}

	public void setTthIdToVal(String tthIdToVal) {
		this.tthIdToVal = tthIdToVal;
	}

	public Long getTthSrfc1Id() {
		return tthSrfc1Id;
	}

	public void setTthSrfc1Id(Long tthSrfc1Id) {
		this.tthSrfc1Id = tthSrfc1Id;
	}

	public Long getTthSrfc2Id() {
		return tthSrfc2Id;
	}

	public void setTthSrfc2Id(Long tthSrfc2Id) {
		this.tthSrfc2Id = tthSrfc2Id;
	}

	public Long getTthSrfc3Id() {
		return tthSrfc3Id;
	}

	public void setTthSrfc3Id(Long tthSrfc3Id) {
		this.tthSrfc3Id = tthSrfc3Id;
	}

	public Long getTthSrfc4Id() {
		return tthSrfc4Id;
	}

	public void setTthSrfc4Id(Long tthSrfc4Id) {
		this.tthSrfc4Id = tthSrfc4Id;
	}

	public Long getTthSrfc5Id() {
		return tthSrfc5Id;
	}

	public void setTthSrfc5Id(Long tthSrfc5Id) {
		this.tthSrfc5Id = tthSrfc5Id;
	}

	public Long getTthSrfc6Id() {
		return tthSrfc6Id;
	}

	public void setTthSrfc6Id(Long tthSrfc6Id) {
		this.tthSrfc6Id = tthSrfc6Id;
	}

	public Long getAreaOfOralCvty1Id() {
		return areaOfOralCvty1Id;
	}

	public void setAreaOfOralCvty1Id(Long areaOfOralCvty1Id) {
		this.areaOfOralCvty1Id = areaOfOralCvty1Id;
	}

	public Long getAreaOfOralCvty2Id() {
		return areaOfOralCvty2Id;
	}

	public void setAreaOfOralCvty2Id(Long areaOfOralCvty2Id) {
		this.areaOfOralCvty2Id = areaOfOralCvty2Id;
	}

	public Long getAreaOfOralCvty3Id() {
		return areaOfOralCvty3Id;
	}

	public void setAreaOfOralCvty3Id(Long areaOfOralCvty3Id) {
		this.areaOfOralCvty3Id = areaOfOralCvty3Id;
	}

	public BigDecimal getHomOxgnTrpyInitMoCnt() {
		return homOxgnTrpyInitMoCnt;
	}

	public void setHomOxgnTrpyInitMoCnt(BigDecimal homOxgnTrpyInitMoCnt) {
		this.homOxgnTrpyInitMoCnt = homOxgnTrpyInitMoCnt;
	}

	public BigDecimal getHomOxgnTrpyRenMoCnt() {
		return homOxgnTrpyRenMoCnt;
	}

	public void setHomOxgnTrpyRenMoCnt(BigDecimal homOxgnTrpyRenMoCnt) {
		this.homOxgnTrpyRenMoCnt = homOxgnTrpyRenMoCnt;
	}

	public BigDecimal getHomOxgnTrpyRvsMoCnt() {
		return homOxgnTrpyRvsMoCnt;
	}

	public void setHomOxgnTrpyRvsMoCnt(BigDecimal homOxgnTrpyRvsMoCnt) {
		this.homOxgnTrpyRvsMoCnt = homOxgnTrpyRvsMoCnt;
	}

	public BigDecimal getArtryBlodGasCnt() {
		return artryBlodGasCnt;
	}

	public void setArtryBlodGasCnt(BigDecimal artryBlodGasCnt) {
		this.artryBlodGasCnt = artryBlodGasCnt;
	}

	public BigDecimal getOxgnStrtnCnt() {
		return oxgnStrtnCnt;
	}

	public void setOxgnStrtnCnt(BigDecimal oxgnStrtnCnt) {
		this.oxgnStrtnCnt = oxgnStrtnCnt;
	}

	public Long getOxgnTstCond1Id() {
		return oxgnTstCond1Id;
	}

	public void setOxgnTstCond1Id(Long oxgnTstCond1Id) {
		this.oxgnTstCond1Id = oxgnTstCond1Id;
	}

	public Long getOxgnTstCond2Id() {
		return oxgnTstCond2Id;
	}

	public void setOxgnTstCond2Id(Long oxgnTstCond2Id) {
		this.oxgnTstCond2Id = oxgnTstCond2Id;
	}

	public Long getOxgnTstCond3Id() {
		return oxgnTstCond3Id;
	}

	public void setOxgnTstCond3Id(Long oxgnTstCond3Id) {
		this.oxgnTstCond3Id = oxgnTstCond3Id;
	}

	public BigDecimal getOxgnFlowRt() {
		return oxgnFlowRt;
	}

	public void setOxgnFlowRt(BigDecimal oxgnFlowRt) {
		this.oxgnFlowRt = oxgnFlowRt;
	}

	public String getUnivPrdctNbr() {
		return univPrdctNbr;
	}

	public void setUnivPrdctNbr(String univPrdctNbr) {
		this.univPrdctNbr = univPrdctNbr;
	}

	public String getSrvcLnPrcInd() {
		return srvcLnPrcInd;
	}

	public void setSrvcLnPrcInd(String srvcLnPrcInd) {
		this.srvcLnPrcInd = srvcLnPrcInd;
	}

	public BigDecimal getSrvcBilChrgAmt() {
		return srvcBilChrgAmt;
	}

	public void setSrvcBilChrgAmt(BigDecimal srvcBilChrgAmt) {
		this.srvcBilChrgAmt = srvcBilChrgAmt;
	}

	public BigDecimal getPchsSrvcChrgLnAmt() {
		return pchsSrvcChrgLnAmt;
	}

	public void setPchsSrvcChrgLnAmt(BigDecimal pchsSrvcChrgLnAmt) {
		this.pchsSrvcChrgLnAmt = pchsSrvcChrgLnAmt;
	}

	public BigDecimal getBilRtLnAmt() {
		return bilRtLnAmt;
	}

	public void setBilRtLnAmt(BigDecimal bilRtLnAmt) {
		this.bilRtLnAmt = bilRtLnAmt;
	}

	public BigDecimal getSbmtNonCovChrgLnAmt() {
		return sbmtNonCovChrgLnAmt;
	}

	public void setSbmtNonCovChrgLnAmt(BigDecimal sbmtNonCovChrgLnAmt) {
		this.sbmtNonCovChrgLnAmt = sbmtNonCovChrgLnAmt;
	}

	public BigDecimal getBilChrgLnAmt() {
		return bilChrgLnAmt;
	}

	public void setBilChrgLnAmt(BigDecimal bilChrgLnAmt) {
		this.bilChrgLnAmt = bilChrgLnAmt;
	}

	public BigDecimal getSaleTaxLnAmt() {
		return saleTaxLnAmt;
	}

	public void setSaleTaxLnAmt(BigDecimal saleTaxLnAmt) {
		this.saleTaxLnAmt = saleTaxLnAmt;
	}

	public BigDecimal getPstgClmLnAmt() {
		return pstgClmLnAmt;
	}

	public void setPstgClmLnAmt(BigDecimal pstgClmLnAmt) {
		this.pstgClmLnAmt = pstgClmLnAmt;
	}

	public BigDecimal getAllwLnAmt() {
		return allwLnAmt;
	}

	public void setAllwLnAmt(BigDecimal allwLnAmt) {
		this.allwLnAmt = allwLnAmt;
	}

	public BigDecimal getEligAmt() {
		return eligAmt;
	}

	public void setEligAmt(BigDecimal eligAmt) {
		this.eligAmt = eligAmt;
	}

	public BigDecimal getBenCoinsLnAmt() {
		return benCoinsLnAmt;
	}

	public void setBenCoinsLnAmt(BigDecimal benCoinsLnAmt) {
		this.benCoinsLnAmt = benCoinsLnAmt;
	}

	public BigDecimal getBenCopayLnAmt() {
		return benCopayLnAmt;
	}

	public void setBenCopayLnAmt(BigDecimal benCopayLnAmt) {
		this.benCopayLnAmt = benCopayLnAmt;
	}

	public BigDecimal getBenLmtAmt() {
		return benLmtAmt;
	}

	public void setBenLmtAmt(BigDecimal benLmtAmt) {
		this.benLmtAmt = benLmtAmt;
	}

	public BigDecimal getBenPayLnAmt() {
		return benPayLnAmt;
	}

	public void setBenPayLnAmt(BigDecimal benPayLnAmt) {
		this.benPayLnAmt = benPayLnAmt;
	}

	public BigDecimal getMbrRespLnAmt() {
		return mbrRespLnAmt;
	}

	public void setMbrRespLnAmt(BigDecimal mbrRespLnAmt) {
		this.mbrRespLnAmt = mbrRespLnAmt;
	}

	public BigDecimal getDedLnAmt() {
		return dedLnAmt;
	}

	public void setDedLnAmt(BigDecimal dedLnAmt) {
		this.dedLnAmt = dedLnAmt;
	}

	public BigDecimal getProvContrAmt() {
		return provContrAmt;
	}

	public void setProvContrAmt(BigDecimal provContrAmt) {
		this.provContrAmt = provContrAmt;
	}

	public BigDecimal getAprvLnAmt() {
		return aprvLnAmt;
	}

	public void setAprvLnAmt(BigDecimal aprvLnAmt) {
		this.aprvLnAmt = aprvLnAmt;
	}

	public BigDecimal getCovAmt() {
		return covAmt;
	}

	public void setCovAmt(BigDecimal covAmt) {
		this.covAmt = covAmt;
	}

	public BigDecimal getContrWthldCntngyLnAmt() {
		return contrWthldCntngyLnAmt;
	}

	public void setContrWthldCntngyLnAmt(BigDecimal contrWthldCntngyLnAmt) {
		this.contrWthldCntngyLnAmt = contrWthldCntngyLnAmt;
	}

	public BigDecimal getCptnPayLnAmt() {
		return cptnPayLnAmt;
	}

	public void setCptnPayLnAmt(BigDecimal cptnPayLnAmt) {
		this.cptnPayLnAmt = cptnPayLnAmt;
	}

	public BigDecimal getCptnAdjLnAmt() {
		return cptnAdjLnAmt;
	}

	public void setCptnAdjLnAmt(BigDecimal cptnAdjLnAmt) {
		this.cptnAdjLnAmt = cptnAdjLnAmt;
	}

	public BigDecimal getDupChrgLnAmt() {
		return dupChrgLnAmt;
	}

	public void setDupChrgLnAmt(BigDecimal dupChrgLnAmt) {
		this.dupChrgLnAmt = dupChrgLnAmt;
	}

	public BigDecimal getNonDupChrgLnAmt() {
		return nonDupChrgLnAmt;
	}

	public void setNonDupChrgLnAmt(BigDecimal nonDupChrgLnAmt) {
		this.nonDupChrgLnAmt = nonDupChrgLnAmt;
	}

	public BigDecimal getEnctrPrcLnAmt() {
		return enctrPrcLnAmt;
	}

	public void setEnctrPrcLnAmt(BigDecimal enctrPrcLnAmt) {
		this.enctrPrcLnAmt = enctrPrcLnAmt;
	}

	public BigDecimal getProvSnctnLnAmt() {
		return provSnctnLnAmt;
	}

	public void setProvSnctnLnAmt(BigDecimal provSnctnLnAmt) {
		this.provSnctnLnAmt = provSnctnLnAmt;
	}

	public BigDecimal getCobRducLnAmt() {
		return cobRducLnAmt;
	}

	public void setCobRducLnAmt(BigDecimal cobRducLnAmt) {
		this.cobRducLnAmt = cobRducLnAmt;
	}

	public BigDecimal getCobSvLnAmt() {
		return cobSvLnAmt;
	}

	public void setCobSvLnAmt(BigDecimal cobSvLnAmt) {
		this.cobSvLnAmt = cobSvLnAmt;
	}

	public BigDecimal getRducLnAmt() {
		return rducLnAmt;
	}

	public void setRducLnAmt(BigDecimal rducLnAmt) {
		this.rducLnAmt = rducLnAmt;
	}

	public BigDecimal getPromptPayDscntLnAmt() {
		return promptPayDscntLnAmt;
	}

	public void setPromptPayDscntLnAmt(BigDecimal promptPayDscntLnAmt) {
		this.promptPayDscntLnAmt = promptPayDscntLnAmt;
	}

	public BigDecimal getDscntLnAmt() {
		return dscntLnAmt;
	}

	public void setDscntLnAmt(BigDecimal dscntLnAmt) {
		this.dscntLnAmt = dscntLnAmt;
	}

	public BigDecimal getSpclNegotDscntLnAmt() {
		return spclNegotDscntLnAmt;
	}

	public void setSpclNegotDscntLnAmt(BigDecimal spclNegotDscntLnAmt) {
		this.spclNegotDscntLnAmt = spclNegotDscntLnAmt;
	}

	public BigDecimal getSuplPayLnAmt() {
		return suplPayLnAmt;
	}

	public void setSuplPayLnAmt(BigDecimal suplPayLnAmt) {
		this.suplPayLnAmt = suplPayLnAmt;
	}

	public BigDecimal getPrcAllocPct() {
		return prcAllocPct;
	}

	public void setPrcAllocPct(BigDecimal prcAllocPct) {
		this.prcAllocPct = prcAllocPct;
	}

	public BigDecimal getNetPdLnAmt() {
		return netPdLnAmt;
	}

	public void setNetPdLnAmt(BigDecimal netPdLnAmt) {
		this.netPdLnAmt = netPdLnAmt;
	}

	public BigDecimal getOthrPayrSrvcPdAmt() {
		return othrPayrSrvcPdAmt;
	}

	public void setOthrPayrSrvcPdAmt(BigDecimal othrPayrSrvcPdAmt) {
		this.othrPayrSrvcPdAmt = othrPayrSrvcPdAmt;
	}

	public BigDecimal getNcLnAmt() {
		return ncLnAmt;
	}

	public void setNcLnAmt(BigDecimal ncLnAmt) {
		this.ncLnAmt = ncLnAmt;
	}

	public BigDecimal getMedcrPdLnAmt() {
		return medcrPdLnAmt;
	}

	public void setMedcrPdLnAmt(BigDecimal medcrPdLnAmt) {
		this.medcrPdLnAmt = medcrPdLnAmt;
	}

	public BigDecimal getMedcrCoinsLnAmt() {
		return medcrCoinsLnAmt;
	}

	public void setMedcrCoinsLnAmt(BigDecimal medcrCoinsLnAmt) {
		this.medcrCoinsLnAmt = medcrCoinsLnAmt;
	}

	public BigDecimal getMedcrDedLnAmt() {
		return medcrDedLnAmt;
	}

	public void setMedcrDedLnAmt(BigDecimal medcrDedLnAmt) {
		this.medcrDedLnAmt = medcrDedLnAmt;
	}

	public Long getSurchrgTaxId() {
		return surchrgTaxId;
	}

	public void setSurchrgTaxId(Long surchrgTaxId) {
		this.surchrgTaxId = surchrgTaxId;
	}

	public BigDecimal getSurchrgTaxLnLnAmt() {
		return surchrgTaxLnLnAmt;
	}

	public void setSurchrgTaxLnLnAmt(BigDecimal surchrgTaxLnLnAmt) {
		this.surchrgTaxLnLnAmt = surchrgTaxLnLnAmt;
	}

	public String getNrsHomInd() {
		return nrsHomInd;
	}

	public void setNrsHomInd(String nrsHomInd) {
		this.nrsHomInd = nrsHomInd;
	}

	public String getClmLvlSumInd() {
		return clmLvlSumInd;
	}

	public void setClmLvlSumInd(String clmLvlSumInd) {
		this.clmLvlSumInd = clmLvlSumInd;
	}

	public Long getClmAdjRsnId() {
		return clmAdjRsnId;
	}

	public void setClmAdjRsnId(Long clmAdjRsnId) {
		this.clmAdjRsnId = clmAdjRsnId;
	}

	public Long getAuthTypId() {
		return authTypId;
	}

	public void setAuthTypId(Long authTypId) {
		this.authTypId = authTypId;
	}

	public String getRefInd() {
		return refInd;
	}

	public void setRefInd(String refInd) {
		this.refInd = refInd;
	}

	public String getAuthNbr() {
		return authNbr;
	}

	public void setAuthNbr(String authNbr) {
		this.authNbr = authNbr;
	}

	public String getDelInd() {
		return delInd;
	}

	public void setDelInd(String delInd) {
		this.delInd = delInd;
	}

	public String getSpecialFields() {
		return specialFields;
	}

	public void setSpecialFields(String specialFields) {
		this.specialFields = specialFields;
	}


}