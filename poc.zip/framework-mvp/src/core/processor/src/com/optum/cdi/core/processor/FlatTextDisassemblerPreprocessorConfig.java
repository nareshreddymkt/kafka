package com.optum.cdi.core.processor;

import org.apache.kafka.common.config.AbstractConfig;
import org.apache.kafka.common.config.ConfigDef;

import java.util.Map;

import static com.optum.cdi.core.shared.CommonValues.*;

public class FlatTextDisassemblerPreprocessorConfig extends AbstractConfig {
	public FlatTextDisassemblerPreprocessorConfig(ConfigDef config, Map<?, ?> parsedConfig) {
		super(config, parsedConfig);
	}

	public FlatTextDisassemblerPreprocessorConfig(Map<?, ?> parsedConfig) {
		this(conf(), parsedConfig);
	}

	public static ConfigDef conf() {
		return CONFIG_DEF;
	}

	protected String getProcessorMetadataFileUri() {
		return this.getString(PROCESSOR_METADATA_FILE_URI_CONFIG);
	}

	protected String getLogicalFileSystemTag() {
		return this.getString(LFS_TAG_CONFIG);
	}

	protected String getFlatTextFormatTag() {
		return this.getString(FTF_TAG_CONFIG);
	}

	private static final ConfigDef CONFIG_DEF = new ConfigDef()
			.define("recordcountmodulo", ConfigDef.Type.INT, ConfigDef.Importance.HIGH, "")
			.define(LFS_TAG_CONFIG, ConfigDef.Type.STRING, ConfigDef.Importance.HIGH, "Logical file system tag used to interpret the processor metadata URI.")
			.define(FTF_TAG_CONFIG, ConfigDef.Type.STRING, ConfigDef.Importance.HIGH, "Flat text format tag used to load the metadata and determine reader/parser.")
			.define(PROCESSOR_METADATA_FILE_URI_CONFIG, ConfigDef.Type.STRING, ConfigDef.Importance.HIGH, "Processor metadata logical file URI.");

	public int getRecordCountModulo() {
		return this.getInt("recordcountmodulo");
	}
}
