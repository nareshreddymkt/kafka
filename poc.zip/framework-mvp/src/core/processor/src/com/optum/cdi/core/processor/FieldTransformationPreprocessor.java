package com.optum.cdi.core.processor;

import com.optum.cdi.core.shared.ProcessorRecordImpl;
import com.optum.cdi.core.shared.abstractions.ProcessorRecord;
import com.optum.cdi.core.shared.abstractions.ScriptExecutionEnvironment;
import com.optum.cdi.core.shared.lifecycle.FieldTransformationProcessorLifecycle;
import org.apache.kafka.streams.processor.AbstractProcessor;
import org.apache.kafka.streams.processor.ProcessorContext;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.Map;

public class FieldTransformationPreprocessor extends AbstractProcessor<Map<String, ?>, Map<String, ?>> {

    public FieldTransformationPreprocessor() {
        getLogger().info("pre-processor::.ctor()");
    }

    private static final Logger logger = Logger.getLogger(FieldTransformationPreprocessor.class);
    private FieldTransformationPreprocessorConfig processorConfig;
    private FieldTransformationProcessorLifecycle fieldTransformationProcessorLifecycle;

    private static Logger getLogger() {
        return logger;
    }

    @Override
    public void init(ProcessorContext context) {
        super.init(context);

        getLogger().info("pre-processor::init()");

        this.setProcessorConfig(new FieldTransformationPreprocessorConfig(this.context().appConfigs()));
        this.setFieldTransformationProcessorLifecycle(FieldTransformationProcessorLifecycle.create(
                this.getProcessorConfig().getLogicalFileSystemTag(),
                this.getProcessorConfig().getScriptTypeTag(),
                this.getProcessorConfig().getScriptFileUri()));

        ScriptExecutionEnvironment environment = this.getFieldTransformationProcessorLifecycle().getScriptExecutionEnvironment();
    }

    @Override
    public void punctuate(long timestamp) {
        super.punctuate(timestamp);

        getLogger().info("pre-processor::punctuate()");
    }

    @Override
    public void close() {
        super.close();

        getLogger().info("pre-processor::close()");
        this.ensureLifecycleDisposed();
        System.out.printf("Pre-process complete... TotalCycleCount: %s | TotalRecordCount: %s | TotalLifecycleSeconds %s.\n",
                this.getFieldTransformationProcessorLifecycle().getTotalBatchCount(),
                this.getFieldTransformationProcessorLifecycle().getTotalRecordCount(),
                this.getFieldTransformationProcessorLifecycle().getTotalLifecycleSeconds());
    }

    @Override
    public void process(Map<String, ?> key, Map<String, ?> value) {
        ProcessorRecord record = new ProcessorRecordImpl(key, value);
        this.getFieldTransformationProcessorLifecycle().getScriptExecutionEnvironment().evaluate(record);

        context().forward(record.getOriginalKey(), record.getModifiedValue());
    }

    private void ensureLifecycleDisposed() {
        synchronized (this) {
            try {
                if (this.getFieldTransformationProcessorLifecycle() != null) {
                    this.getFieldTransformationProcessorLifecycle().close();
                }
            } catch (IOException ioex) {
                getLogger().warn(ioex);
            }
        }
    }

    private FieldTransformationPreprocessorConfig getProcessorConfig() {
        return processorConfig;
    }

    private void setProcessorConfig(FieldTransformationPreprocessorConfig processorConfig) {
        this.processorConfig = processorConfig;
    }

    private FieldTransformationProcessorLifecycle getFieldTransformationProcessorLifecycle() {
        return fieldTransformationProcessorLifecycle;
    }

    private void setFieldTransformationProcessorLifecycle(FieldTransformationProcessorLifecycle fieldTransformationProcessorLifecycle) {
        this.fieldTransformationProcessorLifecycle = fieldTransformationProcessorLifecycle;
    }
}
