package com.optum.cdi.core.processor;

        import org.apache.kafka.common.config.AbstractConfig;
        import org.apache.kafka.common.config.ConfigDef;

        import java.util.Map;

        import static com.optum.cdi.core.shared.CommonValues.*;

public class FieldMappingPreprocessorConfig extends AbstractConfig {
    public FieldMappingPreprocessorConfig(ConfigDef config, Map<?, ?> parsedConfig) {
        super(config, parsedConfig);
    }

    public FieldMappingPreprocessorConfig(Map<?, ?> parsedConfig) {
        this(conf(), parsedConfig);
    }

    public static ConfigDef conf() {
        return CONFIG_DEF;
    }

    protected String getLogicalFileSystemTag() {
        return this.getString(LFS_TAG_CONFIG);
    }

    protected String getProcessorMetadataFileUri() {
        return this.getString(PROCESSOR_METADATA_FILE_URI_CONFIG);
    }



    private static final ConfigDef CONFIG_DEF = new ConfigDef()
            .define(LFS_TAG_CONFIG, ConfigDef.Type.STRING, ConfigDef.Importance.HIGH, "Logical file system tag used to interpret the processor metadata URI.")
            .define(PROCESSOR_METADATA_FILE_URI_CONFIG, ConfigDef.Type.STRING, ConfigDef.Importance.HIGH, "Processor metadata logical file URI.");
}
