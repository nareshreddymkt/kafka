package com.optum.cdi.core.processor;

import com.optum.cdi.core.shared.abstractions.FlatTextRecord;
import com.optum.cdi.core.shared.lifecycle.FlatTextProcessorLifecycle;
import org.apache.kafka.streams.processor.AbstractProcessor;
import org.apache.kafka.streams.processor.ProcessorContext;
import org.apache.log4j.Logger;

import java.io.IOException;

public class FlatTextDisassemblerPreprocessor extends AbstractProcessor<String, String> {
	public FlatTextDisassemblerPreprocessor() {
		getLogger().info("pre-processor::.ctor()");
	}

	private static final Logger logger = Logger.getLogger(FlatTextDisassemblerPreprocessor.class);
	private FlatTextDisassemblerPreprocessorConfig processorConfig;
	private FlatTextProcessorLifecycle flatTextProcessorLifecycle;

	private static Logger getLogger() {
		return logger;
	}

	@Override
	public void init(ProcessorContext context) {
		super.init(context);

		getLogger().info("pre-processor::init()");

		this.setProcessorConfig(new FlatTextDisassemblerPreprocessorConfig(this.context().appConfigs()));

		this.setFlatTextProcessorLifecycle(FlatTextProcessorLifecycle.create(
				this.getProcessorConfig().getLogicalFileSystemTag(),
				this.getProcessorConfig().getFlatTextFormatTag(),
				this.getProcessorConfig().getProcessorMetadataFileUri()));
	}

	@Override
	public void punctuate(long timestamp) {
		super.punctuate(timestamp);

		getLogger().info("pre-processor::punctuate()");
	}

	@Override
	public void close() {
		super.close();

		getLogger().info("pre-processor::close()");
		this.ensureLifecycleDisposed();
		System.out.printf("Pre-process complete... TotalCycleCount: %s | TotalRecordCount: %s | TotalLifecycleSeconds %s.\n", this.getFlatTextProcessorLifecycle().getTotalBatchCount(), this.getFlatTextProcessorLifecycle().getTotalRecordCount(), this.getFlatTextProcessorLifecycle().getTotalLifecycleSeconds());
	}

	@Override
	public void process(String key, String value) {
		FlatTextRecord flatTextRecord;

		getLogger().info("pre-processor::process()");

		flatTextRecord = this.getFlatTextProcessorLifecycle().getFlatTextParser().parseLine(value);

		if (flatTextRecord == null)
			return;

		context().forward(flatTextRecord.getTypedKey(), flatTextRecord.getTypedValue());
		//context().commit(); /* DO NOT CALL COMMIT OR THROUGHPUT GOES DOWN THE TOILET */

		// not sure how "stateful" these processors are...? i.e. would this instance be reused?
		this.getFlatTextProcessorLifecycle().incrementTotalRecordCount();

		if (this.getProcessorConfig().getRecordCountModulo() > 0 &&
				(this.getFlatTextProcessorLifecycle().getTotalRecordCount() % this.getProcessorConfig().getRecordCountModulo()) == 0)
			System.out.printf("pre-processor:: (running) TotalRecordCount=%s\n", this.getFlatTextProcessorLifecycle().getTotalRecordCount());
	}

	private void ensureLifecycleDisposed() {
		synchronized (this) {
			try {
				if (this.getFlatTextProcessorLifecycle() != null) {
					this.getFlatTextProcessorLifecycle().close();
				}
			}
			catch (IOException ioex) {
				getLogger().warn(ioex);
			}
		}
	}

	private FlatTextDisassemblerPreprocessorConfig getProcessorConfig() {
		return processorConfig;
	}

	private void setProcessorConfig(FlatTextDisassemblerPreprocessorConfig processorConfig) {
		this.processorConfig = processorConfig;
	}

	private FlatTextProcessorLifecycle getFlatTextProcessorLifecycle() {
		return flatTextProcessorLifecycle;
	}

	private void setFlatTextProcessorLifecycle(FlatTextProcessorLifecycle flatTextProcessorLifecycle) {
		this.flatTextProcessorLifecycle = flatTextProcessorLifecycle;
	}
}
