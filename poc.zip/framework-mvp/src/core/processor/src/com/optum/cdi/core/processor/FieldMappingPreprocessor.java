package com.optum.cdi.core.processor;

import com.optum.cdi.core.shared.lifecycle.FieldMappingPreprocessorLifecycle;


import org.apache.kafka.streams.processor.AbstractProcessor;
import org.apache.kafka.streams.processor.ProcessorContext;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.Map;


public class FieldMappingPreprocessor extends AbstractProcessor<Map<String, ?>, Map<String, ?>> {

    public FieldMappingPreprocessor() {
        getLogger().info("pre-processor::.ctor()");
    }

    private static final Logger logger = Logger.getLogger(FieldMappingPreprocessor.class);
    private FieldMappingPreprocessorConfig processorConfig;
    private FieldMappingPreprocessorLifecycle fieldMappingProcessorLifecycle;


    private static Logger getLogger() {
        return logger;
    }

    @Override
    public void init(ProcessorContext context) {
        super.init(context);

        getLogger().info("pre-processor::init()");

        this.setProcessorConfig(new FieldMappingPreprocessorConfig(this.context().appConfigs()));
        this.setFieldMappingProcessorLifecycle(FieldMappingPreprocessorLifecycle.create(
                this.getProcessorConfig().getLogicalFileSystemTag(),
                this.getProcessorConfig().getProcessorMetadataFileUri()));
    }

    @Override
    public void punctuate(long timestamp) {
        super.punctuate(timestamp);

        getLogger().info("pre-processor::punctuate()");
    }

    @Override
    public void close() {
        super.close();

        getLogger().info("pre-processor::close()");
        this.ensureLifecycleDisposed();
        System.out.printf("Pre-process complete... TotalCycleCount: %s | TotalRecordCount: %s | TotalLifecycleSeconds %s.\n",
                this.getFieldMappingProcessorLifecycle().getTotalBatchCount(),
                this.getFieldMappingProcessorLifecycle().getTotalRecordCount(),
                this.getFieldMappingProcessorLifecycle().getTotalLifecycleSeconds());
    }

    @Override
    public void process(Map<String, ?> key, Map<String, ?> value) {
       //Insert Field Mapper here
    }

    private void ensureLifecycleDisposed() {
        synchronized (this) {
            try {
                if (this.getFieldMappingProcessorLifecycle() != null) {
                    this.getFieldMappingProcessorLifecycle().close();
                }
            } catch (IOException ioex) {
                getLogger().warn(ioex);
            }
        }
    }

    private FieldMappingPreprocessorConfig getProcessorConfig() {
        return processorConfig;
    }

    private void setProcessorConfig(FieldMappingPreprocessorConfig processorConfig) {
        this.processorConfig = processorConfig;
    }

    private FieldMappingPreprocessorLifecycle getFieldMappingProcessorLifecycle() {
        return fieldMappingProcessorLifecycle;
    }

    private void setFieldMappingProcessorLifecycle(FieldMappingPreprocessorLifecycle fieldMappingProcessorLifecycle) {
        this.fieldMappingProcessorLifecycle= fieldMappingProcessorLifecycle;
    }
}

