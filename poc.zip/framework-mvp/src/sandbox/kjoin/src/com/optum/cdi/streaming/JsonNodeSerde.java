package com.optum.cdi.streaming;

import com.fasterxml.jackson.databind.JsonNode;
import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serializer;
import org.apache.kafka.connect.json.JsonDeserializer;
import org.apache.kafka.connect.json.JsonSerializer;

import java.util.Map;

public class JsonNodeSerde implements Serde<JsonNode> {
	final private JsonSerializer serializer = new JsonSerializer();
	final private JsonDeserializer deserializer = new JsonDeserializer();

	@Override
	public void configure(Map<String, ?> configs, boolean isKey) {
		serializer.configure(configs, isKey);
		deserializer.configure(configs, isKey);
	}

	@Override
	public void close() {
		serializer.close();
		deserializer.close();
	}

	@Override
	public Serializer<JsonNode> serializer() {
		return serializer;
	}

	@Override
	public Deserializer<JsonNode> deserializer() {
		return deserializer;
	}
}
