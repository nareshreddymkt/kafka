package com.optum.cdi.streaming;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.common.serialization.Serializer;
import org.apache.kafka.connect.json.JsonDeserializer;
import org.apache.kafka.connect.json.JsonSerializer;
import org.apache.kafka.streams.*;
import org.apache.kafka.streams.kstream.*;
import org.rocksdb.ColumnFamilyOptions;
import org.rocksdb.DBOptions;

import java.util.Map;
import java.util.Properties;


public class StreamsDSLTest {

	public static void main(String[] args) throws Exception {
		//Create StreamBuilder
		StreamsBuilder builder = new StreamsBuilder();

		//Join Keys for Streams
		String eligKey = "medical_plan_key";
		String detailKey = "plan_key";

		//Serialization info
		final Serializer<JsonNode> jsonSerializer = new JsonSerializer();
		final Deserializer<JsonNode> jsonDeserializer = new JsonDeserializer();
		//final Serde<JsonNode> jsonSerde = Serdes.serdeFrom(jsonSerializer, jsonDeserializer);
		final Serde<JsonNode> jsonSerde = new JsonNodeSerde();

		//Configure initial properties
		Properties props = new Properties();
		props.put(StreamsConfig.APPLICATION_ID_CONFIG, "opi-kstreams-dsl-test");
		props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
		props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, JsonNodeSerde.class);
		props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, JsonNodeSerde.class);
		props.put(StreamsConfig.CACHE_MAX_BYTES_BUFFERING_CONFIG, 0);

		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");

		final Consumed<JsonNode, JsonNode> consumed = Consumed.with(jsonSerde, jsonSerde);
		final Serialized<JsonNode, JsonNode> serialized = Serialized.with(jsonSerde, jsonSerde);

		//Create KStream from Eligibility topic
		KStream<JsonNode, JsonNode> eligSource =
				builder.stream("opi-bcbs-la-1010-eligibility", consumed)
						.map((key, value) -> new KeyValue<>(value.get("payload").get(eligKey), value));

		//Create KTable from PlanDetailCode topic
		KTable<JsonNode, JsonNode> planDetailSource =
				builder.table("opi-bcbs-la-1010-plandetailcode", consumed)
						//Select plan_key as key for KTable
						.groupBy((key, value) -> new KeyValue<>(value.get("payload").get(detailKey), value), serialized)
						//Dummy Reduce from KGroupedTable to KTable, since we needed to create new key for the table
						.reduce((value1, value2) -> value1,
								(value1, value2) -> value1);

		//KStream(eligSource)-KTable(planDetailSource) Join
		KStream<JsonNode, JsonNode> eligToPlanDetailJoinedSink =
				eligSource.leftJoin(planDetailSource, new ValueJoiner<JsonNode, JsonNode, JsonNode>() {
					@Override
					public JsonNode apply(JsonNode eligibility, JsonNode planDetailCode) {
						ObjectNode result;
						result = JsonNodeFactory.instance.objectNode();
						result.set("planDetailCode", planDetailCode);
						result.set("eligibility", eligibility);
						return result;
					}
				});

		eligSource.print(Printed.toFile("C:\\kio\\bcbs-la-1010\\out\\kstream-opi-bcbs-la-1010-eligibility.txt"));
		planDetailSource.toStream().print(Printed.toFile("C:\\kio\\bcbs-la-1010\\out\\ktable-opi-bcbs-la-1010-plandetailcode.txt"));
		eligToPlanDetailJoinedSink.print(Printed.toFile("C:\\kio\\bcbs-la-1010\\out\\kstream-opi-bcbs-la-1010-mergedresult.txt"));

		eligToPlanDetailJoinedSink.to("opi-bcbs-la-1010-mergedresult", Produced.with(jsonSerde, jsonSerde));

		final KafkaStreams streams = new KafkaStreams(builder.build(), props);

		try {
			streams.start();

			Thread.sleep(10000L);
		} catch (Throwable e) {
			System.out.println(e);
			System.exit(1);
		} finally {
			streams.close();
			streams.cleanUp();
		}
		System.exit(0);
	}

}



