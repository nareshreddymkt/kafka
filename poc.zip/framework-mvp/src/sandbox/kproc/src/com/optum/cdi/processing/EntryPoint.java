package com.optum.cdi.processing;

import com.optum.cdi.core.common.kcore.MapSerializer;
import com.optum.cdi.core.processor.FlatTextDisassemblerPreprocessor;
import com.optum.cdi.core.shared.CommonValues;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.Topology;

import java.util.Properties;

public class EntryPoint {

	private final static boolean __use_eligibility = false;

	public static void main(String[] args) throws Exception {

		StreamsConfig streamingConfig = new StreamsConfig(getProperties());

		StringDeserializer stringDeserializer = new StringDeserializer();
		//StringSerializer stringSerializer = new StringSerializer();
		MapSerializer mapSerializer = new MapSerializer();

		Topology topology = new Topology();

		if (!__use_eligibility) {
			topology.addSource("tx_plandetailcode_unbundled_raw", stringDeserializer, stringDeserializer, "opi-bcbs-la-1010-plandetailcode-raw")
					.addProcessor("tx_plandetailcode_preprocess_parser", FlatTextDisassemblerPreprocessor::new, "tx_plandetailcode_unbundled_raw")
					.addSink("tx_plandetailcode_unbundled_cooked", "opi-bcbs-la-1010-plandetailcode-cooked", mapSerializer, mapSerializer, "tx_plandetailcode_preprocess_parser");
		}
		else {
			topology.addSource("tx_eligibility_unbundled_raw", stringDeserializer, stringDeserializer, "opi-bcbs-la-1010-eligibility-raw")
					.addProcessor("tx_eligibility_preprocess_parser", FlatTextDisassemblerPreprocessor::new, "tx_eligibility_unbundled_raw")
					.addSink("tx_eligibility_unbundled_cooked", "opi-bcbs-la-1010-eligibility-cooked", mapSerializer, mapSerializer, "tx_eligibility_preprocess_parser");
		}

		KafkaStreams streaming = new KafkaStreams(topology, streamingConfig);

		try {
			streaming.start();

			System.out.println(">>");
			System.in.read();
		}
		catch (Throwable e) {
			System.out.println(e);
			System.exit(1);
		}
		finally {
			streaming.close();
			streaming.cleanUp();
		}
		System.exit(0);
	}

	private static Properties getProperties() {
		Properties props = new Properties();
		props.put(StreamsConfig.CLIENT_ID_CONFIG, "opi-kprocessors-api-test-job");
		props.put("group.id", "test-consumer-group");
		props.put(StreamsConfig.APPLICATION_ID_CONFIG, "opi-kprocessors-api-test");
		props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
		props.put(StreamsConfig.ZOOKEEPER_CONNECT_CONFIG, "localhost:2181");
		props.put(StreamsConfig.REPLICATION_FACTOR_CONFIG, 1);
		//props.put(StreamsConfig.TIMESTAMP_EXTRACTOR_CLASS_CONFIG, WallclockTimestampExtractor.class);

		props.put(CommonValues.LFS_TAG_CONFIG, CommonValues.CDI_LOGICAL_FILE_SYSTEM_TAG_LOCAL);
		props.put(CommonValues.FTF_TAG_CONFIG, CommonValues.CDI_FLAT_TEXT_FORMAT_TAG_FIXEDLEN);

		if (!__use_eligibility) {
			props.put(CommonValues.PROCESSOR_METADATA_FILE_URI_CONFIG, "C:\\kio\\bcbs-la-1010\\meta\\plan_detail_cd_metadata.json");
			props.put("recordcountmodulo", 1000);
		} else {
			props.put(CommonValues.PROCESSOR_METADATA_FILE_URI_CONFIG, "C:\\kio\\bcbs-la-1010\\meta\\eligibility_metadata.json");
			props.put("recordcountmodulo", 100000);
		}

		return props;
	}
}



